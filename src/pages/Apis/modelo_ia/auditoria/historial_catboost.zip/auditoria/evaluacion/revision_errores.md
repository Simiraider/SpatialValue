# Revisión de los mayores errores de CatBoost

Diagnóstico de la evaluación actual. No se elimina ningún registro por el tamaño de su error. Los ajustes previos se registran en ajustes_datos.csv; las nuevas pistas requieren contrastar los anuncios originales.

- Registros de prueba: 675.
- Casos distintos entre ambos top 20: 36.
- Casos presentes en ambos: 4.
- Los 20 mayores errores en USD concentran el 53.56% del error absoluto acumulado y el 96.51% del error cuadrático acumulado. Las sumas de contribuciones no son nuevas métricas de precisión.

## Los 20 mayores errores en dólares

| ID | Tipo | Observado USD | Predicho USD | Error USD | Error % | Dirección |
|---|---|---:|---:|---:|---:|---|
| zp-60083803 | casa | 12,000,000 | 2,148,907 | 9,851,093 | 82.09 | subestima |
| zp-59748319 | casa | 10,000,000 | 1,774,790 | 8,225,210 | 82.25 | subestima |
| zp-59798371 | casa | 8,500,000 | 3,361,264 | 5,138,736 | 60.46 | subestima |
| zp-59753704 | casa | 5,500,000 | 1,549,512 | 3,950,488 | 71.83 | subestima |
| zp-60396281 | casa | 215,000 | 3,474,064 | 3,259,064 | 1515.84 | sobreestima |
| zp-59772424 | casa | 3,900,000 | 986,115 | 2,913,885 | 74.71 | subestima |
| zp-58320270 | casa | 4,300,000 | 1,856,765 | 2,443,235 | 56.82 | subestima |
| zp-59768669 | casa | 3,900,000 | 1,477,114 | 2,422,886 | 62.13 | subestima |
| zp-58894887 | casa | 4,300,000 | 2,476,035 | 1,823,965 | 42.42 | subestima |
| zp-60027570 | casa | 4,300,000 | 2,862,645 | 1,437,355 | 33.43 | subestima |
| zp-57718089 | casa | 2,000,000 | 832,955 | 1,167,045 | 58.35 | subestima |
| zp-60020564 | casa | 2,600,000 | 3,743,053 | 1,143,053 | 43.96 | sobreestima |
| zp-54021207 | casa | 2,000,000 | 1,033,362 | 966,638 | 48.33 | subestima |
| zp-59694959 | casa | 2,000,000 | 1,058,733 | 941,267 | 47.06 | subestima |
| zp-59042118 | casa | 2,000,000 | 1,099,398 | 900,602 | 45.03 | subestima |
| zp-59460530 | departamento | 1,780,000 | 909,740 | 870,260 | 48.89 | subestima |
| zp-53202868 | departamento | 1,600,000 | 731,080 | 868,920 | 54.31 | subestima |
| zp-60280500 | casa | 1,400,000 | 618,601 | 781,399 | 55.81 | subestima |
| zp-60453092 | casa | 2,000,000 | 1,226,797 | 773,203 | 38.66 | subestima |
| zp-59319487 | casa | 800,000 | 1,573,057 | 773,057 | 96.63 | sobreestima |

## Los 20 mayores errores porcentuales

| ID | Tipo | Observado USD | Predicho USD | Error USD | Error % | Dirección |
|---|---|---:|---:|---:|---:|---|
| zp-60396281 | casa | 215,000 | 3,474,064 | 3,259,064 | 1515.84 | sobreestima |
| zp-59538298 | departamento | 57,000 | 160,460 | 103,460 | 181.51 | sobreestima |
| zp-55721444 | casa | 265,000 | 654,784 | 389,784 | 147.09 | sobreestima |
| zp-59576966 | casa | 198,000 | 463,119 | 265,119 | 133.90 | sobreestima |
| zp-58491831 | ph | 85,000 | 189,631 | 104,631 | 123.10 | sobreestima |
| zp-60249850 | departamento | 161,000 | 342,326 | 181,326 | 112.62 | sobreestima |
| zp-60062828 | casa | 195,000 | 397,864 | 202,864 | 104.03 | sobreestima |
| zp-59844849 | casa | 715,000 | 1,454,681 | 739,681 | 103.45 | sobreestima |
| zp-59282342 | departamento | 550,000 | 1,112,373 | 562,373 | 102.25 | sobreestima |
| zp-60358950 | ph | 55,000 | 108,472 | 53,472 | 97.22 | sobreestima |
| zp-59319487 | casa | 800,000 | 1,573,057 | 773,057 | 96.63 | sobreestima |
| zp-60416444 | casa | 190,000 | 363,228 | 173,228 | 91.17 | sobreestima |
| zp-59912888 | casa | 240,000 | 457,920 | 217,920 | 90.80 | sobreestima |
| zp-60112451 | departamento | 234,095 | 443,897 | 209,802 | 89.62 | sobreestima |
| zp-59748319 | casa | 10,000,000 | 1,774,790 | 8,225,210 | 82.25 | subestima |
| zp-60083803 | casa | 12,000,000 | 2,148,907 | 9,851,093 | 82.09 | subestima |
| zp-60105933 | ph | 86,000 | 155,648 | 69,648 | 80.99 | sobreestima |
| zp-58699295 | departamento | 570,000 | 1,027,238 | 457,238 | 80.22 | sobreestima |
| zp-60515175 | casa | 298,000 | 524,224 | 226,224 | 75.91 | sobreestima |
| zp-59971989 | casa | 192,000 | 337,624 | 145,624 | 75.85 | sobreestima |

## Coincidencias entre las dos listas

zp-59319487, zp-59748319, zp-60083803, zp-60396281

## Distribución por tipo en las listas

Top USD: {'casa': 18, 'departamento': 2}. Top porcentual: {'casa': 12, 'departamento': 5, 'ph': 3}.

## Qué comprobar

1. Comparar precio, moneda, operación, superficies y características con el anuncio original. Un error alto por sí solo no justifica eliminarlo.
2. Verificar inmuebles de lujo y casos grandes: pueden ser legítimos y estar poco representados.
3. Revisar faltantes y ubicaciones genéricas.
4. Investigar republicaciones antes de crear nuevas particiones.
5. Usar validación interna para comparar log(precio), MAE y parámetros. Este test ya se está usando para diagnóstico; no debe presentarse luego como validación independiente de las mejoras elegidas.

Las URLs y las características para revisar cada caso están en `mayores_errores.csv`. Este diagnóstico no modifica el CSV original ni el modelo.
