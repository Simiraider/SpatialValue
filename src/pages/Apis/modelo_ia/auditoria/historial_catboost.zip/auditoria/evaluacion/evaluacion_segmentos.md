# Evaluación del modelo por segmentos

**Informe histórico anterior a la revisión de las cuatro propuestas.** La evaluación actual está en [mejoras por segmento](../mejoras_segmentos/RESULTADOS.md) y sus [tablas actualizadas](../mejoras_segmentos/evaluacion_segmentos.md). El cambio de población se explica por separado de las mejoras del modelo.

Se analizan las mismas 675 predicciones de prueba, con 2701 publicaciones de entrenamiento. No se modifica CatBoost.

MAPE es error porcentual absoluto medio; mediana y P90 describen su distribución. Sesgo positivo significa sobreestimación y negativo subestimación. Error ≤20% es la proporción de ejemplos que cumplen ese margen, no una probabilidad individual.

* indica menos de 30 grupos de prueba (o filas si no se dispone de grupos). Se omiten métricas con menos de 5 publicaciones. Estos umbrales son operativos y no prueban estabilidad estadística.

MAE, RMSE, R², percentiles completos y márgenes de 10/20/30% están en `metricas_modelo.json`, sección `evaluacion_segmentos`.

## Tipo de propiedad

| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Casa | 928 | 249 | 202 | 31.40% | 19.85% | 55.35% | +6.80% | 50.20% |
| Departamento | 1309 | 280 | 262 | 19.60% | 14.26% | 42.62% | +5.36% | 64.29% |
| PH | 464 | 146 | 136 | 18.39% | 13.96% | 38.68% | +3.28% | 66.44% |

## Precio observado (USD)

| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ≤100k | 251 | 87 | 84 | 26.67% | 19.50% | 53.47% | +23.78% | 51.72% |
| 100k–250k | 1174 | 277 | 260 | 23.18% | 12.40% | 38.77% | +10.93% | 70.76% |
| 250k–500k | 772 | 191 | 174 | 19.43% | 16.48% | 38.51% | -0.87% | 59.69% |
| 500k–1M | 317 | 80 | 70 | 26.77% | 22.60% | 52.56% | -2.05% | 40.00% |
| >1M * | 187 | 40 | 26 | 34.92% | 36.04% | 63.10% | -27.32% | 37.50% |

## Etiqueta de barrio

| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Agronomia * | 9 | 3 | 3 | — | — | — | — | — |
| Almagro * | 78 | 11 | 11 | 12.59% | 8.73% | 23.80% | -5.24% | 81.82% |
| Almagro Norte | 1 | 0 | 0 | — | — | — | — | — |
| Antonio J. De * | 0 | 1 | 1 | — | — | — | — | — |
| Avda. 3867. Entre Estomba Y Tronador | 1 | 0 | 0 | — | — | — | — | — |
| B. Y Avenida Eva Peron | 1 | 0 | 0 | — | — | — | — | — |
| Balvanera * | 58 | 17 | 16 | 29.24% | 18.97% | 72.18% | +19.90% | 58.82% |
| Barracas * | 43 | 13 | 12 | 24.44% | 18.72% | 51.13% | +16.17% | 61.54% |
| Barrio Norte | 1 | 0 | 0 | — | — | — | — | — |
| Barrio Parque * | 4 | 5 | 4 | 31.34% | 11.72% | 69.68% | -28.09% | 60.00% |
| Belgrano | 152 | 38 | 33 | 57.61% | 11.89% | 43.17% | +35.86% | 65.79% |
| Belgrano C | 1 | 0 | 0 | — | — | — | — | — |
| Belgrano Chico | 6 | 0 | 0 | — | — | — | — | — |
| Belgrano R * | 29 | 10 | 8 | 58.71% | 58.64% | 97.31% | +2.12% | 10.00% |
| Boedo * | 31 | 3 | 3 | — | — | — | — | — |
| Botanico | 1 | 0 | 0 | — | — | — | — | — |
| Caba | 1 | 0 | 0 | — | — | — | — | — |
| Caballito | 121 | 30 | 30 | 17.61% | 13.84% | 37.15% | +4.18% | 66.67% |
| Caballito Norte * | 3 | 2 | 1 | — | — | — | — | — |
| Capital Federal | 404 | 87 | 86 | 29.85% | 24.36% | 56.29% | +9.06% | 44.83% |
| Centro / Microcentro | 1 | 0 | 0 | — | — | — | — | — |
| Chacarita * | 22 | 5 | 5 | 19.99% | 13.24% | 40.90% | +14.69% | 80.00% |
| Ciudad Autonoma De Buenos Aires | 1 | 0 | 0 | — | — | — | — | — |
| Coghlan * | 25 | 10 | 8 | 9.14% | 8.76% | 16.63% | +0.95% | 100.00% |
| Colegiales * | 69 | 14 | 13 | 12.63% | 9.37% | 24.56% | +5.93% | 78.57% |
| Congreso | 1 | 0 | 0 | — | — | — | — | — |
| Constitucion * | 11 | 6 | 6 | 42.04% | 30.24% | 78.06% | +37.12% | 16.67% |
| Devoto * | 1 | 2 | 2 | — | — | — | — | — |
| E/ Castanares Y Zelarrayan * | 0 | 1 | 1 | — | — | — | — | — |
| Entre Miller Y Valdenegro * | 0 | 1 | 1 | — | — | — | — | — |
| Flores * | 68 | 12 | 12 | 12.60% | 11.71% | 24.38% | +1.43% | 83.33% |
| Flores Norte | 1 | 0 | 0 | — | — | — | — | — |
| Floresta * | 20 | 7 | 7 | 10.79% | 6.50% | 22.50% | +10.36% | 71.43% |
| Horacio | 1 | 0 | 0 | — | — | — | — | — |
| Jose G. De | 2 | 0 | 0 | — | — | — | — | — |
| Juan B. | 1 | 0 | 0 | — | — | — | — | — |
| La Boca | 11 | 0 | 0 | — | — | — | — | — |
| La Paternal * | 13 | 1 | 1 | — | — | — | — | — |
| Las Canitas * | 2 | 4 | 2 | — | — | — | — | — |
| Liniers * | 29 | 7 | 7 | 19.24% | 17.90% | 35.21% | +1.52% | 57.14% |
| Lomas De Nunez | 2 | 0 | 0 | — | — | — | — | — |
| Mataderos * | 36 | 7 | 6 | 19.66% | 21.17% | 30.41% | +3.44% | 42.86% |
| Monserrat * | 29 | 8 | 7 | 17.17% | 14.21% | 38.06% | -16.04% | 50.00% |
| Monte Castro * | 24 | 8 | 7 | 19.73% | 16.83% | 35.64% | -2.58% | 50.00% |
| Naon * | 0 | 1 | 1 | — | — | — | — | — |
| No Especificada | 1 | 0 | 0 | — | — | — | — | — |
| Norberto | 1 | 0 | 0 | — | — | — | — | — |
| Nueva Pompeya * | 11 | 4 | 4 | — | — | — | — | — |
| Nunez * | 74 | 22 | 20 | 17.03% | 12.31% | 37.87% | -8.18% | 63.64% |
| Palermo | 313 | 68 | 57 | 20.24% | 17.98% | 38.67% | +5.76% | 58.82% |
| Palermo Chico * | 5 | 2 | 2 | — | — | — | — | — |
| Palermo Hollywood * | 3 | 1 | 1 | — | — | — | — | — |
| Palermo Soho | 7 | 0 | 0 | — | — | — | — | — |
| Parque Avellaneda * | 23 | 6 | 5 | 22.51% | 13.16% | 47.39% | +9.08% | 66.67% |
| Parque Centenario | 1 | 0 | 0 | — | — | — | — | — |
| Parque Chacabuco * | 26 | 12 | 11 | 26.75% | 20.38% | 52.17% | +15.75% | 50.00% |
| Parque Chas * | 25 | 2 | 2 | — | — | — | — | — |
| Parque Patricios | 17 | 0 | 0 | — | — | — | — | — |
| Paternal | 1 | 0 | 0 | — | — | — | — | — |
| Plaza San Martin * | 0 | 1 | 1 | — | — | — | — | — |
| Pompeya * | 5 | 1 | 1 | — | — | — | — | — |
| Puerto Madero * | 35 | 9 | 9 | 23.79% | 20.29% | 52.13% | -17.38% | 44.44% |
| Ramon Y Zapiola | 1 | 0 | 0 | — | — | — | — | — |
| Recoleta * | 126 | 24 | 23 | 22.99% | 15.96% | 51.98% | +5.63% | 58.33% |
| Retiro * | 34 | 6 | 5 | 27.79% | 13.17% | 63.38% | +15.08% | 66.67% |
| Saavedra * | 58 | 17 | 16 | 13.67% | 10.47% | 27.48% | -1.30% | 82.35% |
| San Cristobal * | 23 | 10 | 8 | 9.90% | 8.18% | 17.45% | -0.51% | 100.00% |
| San Nicolas * | 18 | 6 | 6 | 20.82% | 19.95% | 35.05% | -17.32% | 50.00% |
| San Telmo * | 17 | 6 | 5 | 35.30% | 35.11% | 46.53% | +3.57% | 0.00% |
| Severo Garcia Gde.De * | 0 | 1 | 1 | — | — | — | — | — |
| Severo Garcia Gde.De 5800. Entre Pola Y Fonrouge | 1 | 0 | 0 | — | — | — | — | — |
| Severo Garcia Gde.De 6000. Entre Larrazabal | 1 | 0 | 0 | — | — | — | — | — |
| Severo Garcia Gde.De Y Zelada * | 0 | 1 | 1 | — | — | — | — | — |
| Velez Sarsfield * | 20 | 5 | 4 | 13.31% | 16.32% | 25.53% | -0.70% | 80.00% |
| Versalles * | 7 | 4 | 4 | — | — | — | — | — |
| Villa Crespo * | 56 | 14 | 13 | 15.18% | 14.41% | 28.15% | +1.68% | 64.29% |
| Villa Del Parque * | 58 | 21 | 19 | 14.14% | 7.67% | 34.72% | +2.09% | 76.19% |
| Villa Devoto | 112 | 41 | 34 | 22.33% | 19.50% | 41.74% | +7.28% | 51.22% |
| Villa General Mitre * | 21 | 8 | 8 | 14.34% | 10.84% | 22.85% | -4.95% | 87.50% |
| Villa Lugano * | 24 | 8 | 6 | 20.57% | 17.38% | 35.38% | +3.14% | 50.00% |
| Villa Luro * | 24 | 8 | 8 | 19.14% | 15.11% | 36.80% | +3.49% | 62.50% |
| Villa Ortuzar * | 21 | 6 | 6 | 13.60% | 12.83% | 23.14% | +2.50% | 83.33% |
| Villa Pueyrredon * | 67 | 17 | 16 | 9.77% | 8.66% | 21.85% | +1.17% | 82.35% |
| Villa Real | 4 | 0 | 0 | — | — | — | — | — |
| Villa Riachuelo * | 5 | 1 | 1 | — | — | — | — | — |
| Villa Santa Rita * | 19 | 5 | 5 | 22.84% | 24.81% | 28.83% | +16.52% | 40.00% |
| Villa Soldati * | 2 | 1 | 1 | — | — | — | — | — |
| Villa Urquiza * | 119 | 23 | 23 | 12.19% | 6.67% | 25.44% | -0.61% | 73.91% |

Las etiquetas se conservan como entraron al modelo. Capital Federal no identifica un barrio específico; algunas etiquetas parecen calles. No se unifican nombres o subzonas automáticamente.

## Tipo y precio

### Casa

| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ≤100k * | 7 | 3 | 3 | — | — | — | — | — |
| 100k–250k | 230 | 49 | 43 | 59.22% | 19.40% | 78.84% | +50.43% | 53.06% |
| 250k–500k | 388 | 106 | 91 | 20.34% | 17.52% | 38.54% | +2.03% | 55.66% |
| 500k–1M | 186 | 55 | 47 | 25.59% | 20.78% | 47.88% | -1.93% | 43.64% |
| >1M * | 117 | 36 | 22 | 34.54% | 36.04% | 66.98% | -27.74% | 41.67% |

### Departamento

| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ≤100k | 194 | 64 | 62 | 22.20% | 16.04% | 45.16% | +18.63% | 60.94% |
| 100k–250k | 642 | 135 | 131 | 16.23% | 11.90% | 35.94% | +3.23% | 75.56% |
| 250k–500k | 279 | 53 | 52 | 19.78% | 16.88% | 40.97% | -0.64% | 58.49% |
| 500k–1M * | 125 | 24 | 22 | 28.12% | 24.34% | 53.82% | +0.04% | 33.33% |
| >1M * | 69 | 4 | 4 | — | — | — | — | — |

### PH

| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ≤100k * | 50 | 20 | 19 | 39.44% | 31.59% | 82.61% | +38.27% | 25.00% |
| 100k–250k | 302 | 93 | 86 | 14.29% | 11.57% | 30.40% | +1.29% | 73.12% |
| 250k–500k | 105 | 32 | 31 | 15.87% | 15.14% | 32.78% | -10.85% | 75.00% |
| 500k–1M * | 6 | 1 | 1 | — | — | — | — | — |
| >1M | 1 | 0 | 0 | — | — | — | — | — |

## Limitaciones

- Análisis descriptivo del mismo test: no cambia modelos ni usa segmentos para seleccionar parámetros.
- Cinco y treinta son umbrales operativos; superarlos no certifica estabilidad estadística.
- Precio observado define el rango de diagnóstico; ese precio no se conoce al tasar una vivienda nueva.
- Se conservan las etiquetas de barrio del modelo; no se unifican barrios, alias ni subzonas.
- Un grupo puede aparecer en varios rangos o barrios si sus anuncios tienen precios o etiquetas distintos; no sumar grupos entre segmentos.
- R² en rangos estrechos puede ser negativo y no equivale a porcentaje de aciertos.
