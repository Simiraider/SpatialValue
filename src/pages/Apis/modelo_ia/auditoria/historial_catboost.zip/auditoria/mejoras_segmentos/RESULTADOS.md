# Cuatro mejoras: resultados separados

Elegida por validación interna: **base_revisada**. Configuración activada localmente: True.

Prueba común: 674 publicaciones / 600 grupos; entrenamiento: 2701; grupos compartidos: 0.

## 1. Caso extremo

[Revisión y evidencia](01_caso_extremo.md). Se excluye una oferta de dos casas linderas; no se modifica su precio ni el CSV.
MAPE histórico de 675 filas: 23.69%. Misma predicción histórica sobre las 674 filas comunes: 21.48%. Esta diferencia es población, NO ganancia del modelo.

## 2. Ubicación

Límites oficiales locales de [BA Data](https://data.buenosaires.gob.ar/dataset/barrios); atribución GCBA, licencia CC-BY-2.5-AR. No hay llamadas de red al entrenar ni al tasar.
Estados: {'coincide': 2441, 'sin barrio': 488, 'solo texto': 198, 'conflicto': 150, 'solo gps': 98}. Coordenada central genérica: 170 filas.
Se calculan barrio por GPS, barrio principal, subzona y consistencia con el texto. Las discrepancias quedan registradas; pertenecer a un polígono no certifica que el GPS del scraper sea correcto. No se atribuye barrio a coordenadas genéricas, fuera de CABA o ambiguas en límites.
[Detalle por publicación](02_auditoria_ubicacion.csv). [Gráfico de ubicación](02_ubicacion.png).

## 3. Superficies

[Revisión de semántica y fuentes](03_revision_superficies.md). Se comparan nueve variables derivadas de metrajes y faltantes. Sin eliminar extremos por precio o error.
[37 casas que requieren distinguir terreno de construido](03_cubierta_mayor_total.csv). [Alertas observables](03_auditoria_superficies.csv). [Gráfico de superficies](03_superficies.png).

## 4. General frente a especialistas por tipo

Se prueban tres especialistas (casa/departamento/PH) con los mismos parámetros. Cada uno solo ve las filas de su tipo en el entrenamiento de su fold. Tipos nuevos o con menos de 100 filas usan el modelo general de respaldo. Se enruta por tipo conocido, nunca por el precio objetivo.
La comparación incluye cada cambio aislado y la combinación de ubicación/superficies, con y sin especialistas. No se fuerza adoptar una variante si no mejora validación.

## Comparación controlada

Menor MAPE medio CV, mejora >=0,20 puntos, gana >=3/5 folds; MAE/RMSE CV no empeoran >5%; MAPE OOF por tipo no empeora >10%. Si nadie cumple, conservar base.

| Variante | CV MAPE media ± desvío | Prueba MAPE | MAE USD | RMSE USD | R² |
|---|---:|---:|---:|---:|---:|
| base_revisada | 21.89% ± 0.50 | 21.48% | 135,473 | 609,222 | 0.508 |
| solo_ubicacion | 21.97% ± 0.60 | 22.10% | 142,813 | 634,991 | 0.466 |
| solo_superficies | 21.95% ± 0.44 | 21.93% | 141,012 | 627,942 | 0.477 |
| ubicacion_y_superficies | 22.05% ± 0.47 | 21.47% | 139,001 | 627,900 | 0.477 |
| solo_modelos_por_tipo | 22.60% ± 0.88 | 22.17% | 144,795 | 628,350 | 0.477 |
| ubicacion_superficies_y_tipo | 22.45% ± 0.69 | 22.35% | 148,950 | 645,712 | 0.447 |

El desvío entre folds no es un intervalo de confianza. Los resultados de prueba no participan en la selección; este conjunto ya fue explorado. Se necesita una extracción futura verificada para confirmar generalización.

## Tipos en prueba común

| Variante | Casa MAPE | Departamento MAPE | PH MAPE |
|---|---:|---:|---:|
| base_revisada | 25.41% | 19.60% | 18.39% |
| solo_ubicacion | 27.31% | 19.68% | 17.91% |
| solo_superficies | 26.99% | 19.52% | 17.95% |
| ubicacion_y_superficies | 26.43% | 19.24% | 17.32% |
| solo_modelos_por_tipo | 26.51% | 19.82% | 19.29% |
| ubicacion_superficies_y_tipo | 26.83% | 19.85% | 19.51% |

[Gráfico de comparación](04_comparacion_mejoras.png). [Segmentos del modelo elegido](evaluacion_segmentos.md).

La referencia histórica mínima se conserva en `referencia_historica.json` y `predicciones_historicas.csv`. Los resultados anteriores de `../evaluacion/` no se sobrescriben durante esta comparación. Estos archivos son la referencia actual de esta comparación. La configuración local se aplicará al próximo entrenamiento; no se reinicia ni despliega la API.
