# 1. Revisión del caso extremo

Registro: `zp-60396281`, Virrey del Pino al 3500. CSV: USD 215.000, total 2.179 m², cubierta 1.276 m².

Se contrastó el anuncio el 2026-10-28: [fuente original](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-imponente-casa-con-el-mejor-jardin-de-belgrano-r-60396281.html).
La descripción ofrece dos casas linderas y el precio actual se consulta al anunciante. La ficha muestra 15 ambientes, 7 dormitorios y 107 años. La publicación no permite validar USD 215.000 ni asignar un precio individual.

Decisión: excluir este ID y URL del entrenamiento y evaluación de viviendas individuales, por su alcance verificado. No se corrige precio ni metraje, no se modifica el CSV ni se excluyen otras propiedades grandes por semejanza. Que el anuncio hoy no muestre precio no prueba cuál fue su precio histórico.

La comparación conserva los IDs/grupos del reparto anterior. La base y todas las variantes usan la misma prueba común, sin este registro. La caída respecto al 23,69% histórico por quitarlo es cambio de población y NO mejora predictiva.
