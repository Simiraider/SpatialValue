# 3. Semántica y variables de superficie

Se detectaron 37 casas con cubierta mayor que total en el CSV original. No se asume que todas sean incorrectas: en varios anuncios total puede representar el lote y cubierta sumar varias plantas.

- [zp-55391782](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-oppel-casa-en-venta-belgrano-r-capital-federal-55391782.html): ficha 265 m² totales y 388 m² cubiertos; descripción en dos plantas. La desigualdad existe en la fuente y no demuestra un error de extracción.
- [zp-56984563](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-imperdible-oportunidad-casa-sobre-lote-propio-56984563.html): ficha 250 y 320 m²; describe planta baja y primer piso. Evidencia indexada de 2025, no actualización certificada del anuncio.
- No pudo recuperarse `zp-55701759`; queda sin verificar.

Se conserva por ahora la restricción cubierta ≤ total del contrato actual de entrada: el dataset no separa superficie de terreno de superficie total construida, y la API también rechaza esa desigualdad. Reincorporar las 37 filas sin distinguir las medidas crearía un contrato diferente entre entrenamiento y uso. No se cambia la API ni el scraper.

Se implementan y comparan proporción cubierta/total, diferencia total−cubierta, cubierta por ambiente/dormitorio e indicadores de faltantes. La diferencia no se denomina patio ni terreno, y no se rellenan ceros ni metrajes inventados. Las alertas de proporciones extremas solo generan revisión, sin eliminar filas.

Trabajo de datos pendiente para el equipo: exportar terreno_m2 y total_construida_m2 separados, además de cubierta_m2 y su fuente. La implementación de las variables y su comparación quedan completas con el contrato disponible.
