"""Cuatro mejoras separadas. Ejecutar: python -m modelo_ia.comparar_mejoras.

Preserva la prueba histórica por ID/grupo; elige alternativas solo en desarrollo.
Los resultados nuevos se guardan aparte, sin sobrescribir la evaluación histórica.
"""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from .modelo import (DATASET_CSV,CONFIGURACION_MODELO,cargar_dataset_csv,limpiar_registros,
                     _preparar_features,COLUMNAS_TEXTO,COLUMNAS_NUMERICAS,agrupar_inmuebles,
                     dividir_datos,crear_modelo,calcular_metricas,evaluar_segmentos)
from .mejoras_segmentos import preparar_mejoras,MAPA_BARRIOS

RAIZ = Path(__file__).resolve().parent
SALIDA = RAIZ/'auditoria'/'mejoras_segmentos'
VARIANTES = {
    'base_revisada':{},
    'solo_ubicacion':{'ubicacion':True},
    'solo_superficies':{'superficies':True},
    'ubicacion_y_superficies':{'ubicacion':True,'superficies':True},
    'solo_modelos_por_tipo':{'por_tipo':True},
    'ubicacion_superficies_y_tipo':{'ubicacion':True,'superficies':True,'por_tipo':True},
}
ETIQUETAS = {'base_revisada':'Base revisada','solo_ubicacion':'Ubicación',
             'solo_superficies':'Superficies','ubicacion_y_superficies':'Ubicación + superficies',
             'solo_modelos_por_tipo':'Modelos por tipo',
             'ubicacion_superficies_y_tipo':'Ubicación + superficies + tipo'}


def huellas_codigo():
    return {nombre:hashlib.sha256((RAIZ/nombre).read_bytes()).hexdigest()
            for nombre in ('modelo.py','mejoras_segmentos.py')}


def elegir_mejora(resultados):
    """Regla fijada antes de medir prueba; MAPE con resguardos en dólares y por tipo."""
    base = resultados['base_revisada']
    candidatos = ['base_revisada']
    for nombre,r in resultados.items():
        if nombre=='base_revisada':
            continue
        mejora = base['resumen_cv']['mape_porcentaje']['media']-r['resumen_cv']['mape_porcentaje']['media']
        victorias = sum(a['metricas']['mape_porcentaje']<b['metricas']['mape_porcentaje'] for a,b in zip(r['folds'],base['folds']))
        dolares = all(r['resumen_cv'][k]['media']<=base['resumen_cv'][k]['media']*1.05 for k in ('mae_usd','rmse_usd'))
        tipos = all(r['oof_por_tipo'][t]['mape_porcentaje']<=m['mape_porcentaje']*1.10 for t,m in base['oof_por_tipo'].items())
        r['seleccion'] = {'mejora_mape_puntos':mejora,'folds_con_menor_mape':victorias,
                          'resguardo_dolares':dolares,'resguardo_tipos':tipos,
                          'admisible':bool(mejora>=.20 and victorias>=3 and dolares and tipos)}
        if r['seleccion']['admisible']:
            candidatos.append(nombre)
    return min(candidatos,key=lambda n:resultados[n]['resumen_cv']['mape_porcentaje']['media'])


def cargar_comparacion(ruta):
    originales = cargar_dataset_csv(ruta)
    filas = sorted(originales.to_dict('records'),key=lambda f:str(f.get('id_propiedad') or ''))
    # Reconstruir exactamente la población previa al paso 1. No redividir al quitar una fila.
    anteriores,_ = limpiar_registros(filas,aplicar_revision_segmentos=False)
    anteriores = _preparar_features(pd.DataFrame(anteriores))
    grupos_anteriores = agrupar_inmuebles(anteriores)
    a,b = dividir_datos(len(anteriores),grupos_anteriores,random_state=20261028)
    referencia = SALIDA/'referencia_historica.json'
    historico = json.loads((referencia if referencia.exists() else RAIZ/'auditoria'/'evaluacion'/'metricas_modelo.json').read_text())
    pred_csv = SALIDA/'predicciones_historicas.csv'
    pred_ant = pd.read_csv(pred_csv if pred_csv.exists() else RAIZ/'auditoria'/'evaluacion'/'predicciones_prueba.csv').set_index('id_propiedad')
    if historico['archivo_sha256']!=hashlib.sha256(ruta.read_bytes()).hexdigest():
        raise ValueError('El CSV cambió: revisar población y particiones antes de comparar con la evaluación histórica.')
    if set(pred_ant.index)!=set(anteriores.iloc[b].id_propiedad):
        raise ValueError('La prueba histórica no coincide; no se pueden comparar poblaciones distintas.')
    huella = hashlib.sha256(anteriores.to_json(orient='records',double_precision=15).encode()).hexdigest()
    if historico.get('huella_dataset_sha256')!=huella:
        raise ValueError('La preparación histórica cambió: revisar el experimento antes de reutilizar sus particiones.')
    np.testing.assert_allclose(anteriores.iloc[b].precio_usd,pred_ant.loc[anteriores.iloc[b].id_propiedad,'precio_observado_usd'],rtol=0,atol=1e-6)
    nuevos,limpieza = limpiar_registros(filas)
    d = _preparar_features(pd.DataFrame(nuevos))
    ids_train,ids_test = set(anteriores.iloc[a].id_propiedad),set(anteriores.iloc[b].id_propiedad)
    train = np.flatnonzero(d.id_propiedad.isin(ids_train))
    test = np.flatnonzero(d.id_propiedad.isin(ids_test))
    if len(train)+len(test)!=len(d):
        raise ValueError('Existen filas nuevas sin partición: definir su grupo antes de evaluar.')
    grupos = d.id_propiedad.map(dict(zip(anteriores.id_propiedad,grupos_anteriores))).to_numpy()
    if set(grupos[train])&set(grupos[test]):
        raise ValueError('Hay grupos compartidos entre entrenamiento y prueba.')
    return originales,d,grupos,train,test,historico,pred_ant,limpieza


def auditar(originales,d):
    SALIDA.mkdir(parents=True,exist_ok=True)
    X = d[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]
    geo = preparar_mejoras(X,ubicacion=True)
    auditoria = pd.DataFrame({'id_propiedad':d.id_propiedad,'barrio_declarado':d.barrio_zona,
                             'latitud_original':d.latitud,'longitud_original':d.longitud})
    for c in ('barrio_zona','barrio_segun_gps','subzona_declarada','ubicacion_consistencia','gps_central_generico','gps_no_utilizable'):
        auditoria[c] = geo[c]
    auditoria.to_csv(SALIDA/'02_auditoria_ubicacion.csv',index=False)
    problema = originales[(originales.superficie_cubierta_m2>originales.superficie_total_m2)].copy()
    problema[['id_propiedad','url','tipo_propiedad','superficie_total_m2','superficie_cubierta_m2']].to_csv(SALIDA/'03_cubierta_mayor_total.csv',index=False)
    ratios = preparar_mejoras(X,superficies=True)
    revision = d[['id_propiedad','url','tipo_propiedad','superficie_total_m2','superficie_cubierta_m2','ambientes']].copy()
    for c in ('proporcion_cubierta_total','diferencia_total_cubierta_m2','cubierta_por_ambiente_m2'):
        revision[c] = ratios[c]
    # Alertas observables, no filtros aprendidos del precio ni del error.
    revision['alerta_proporcion_menor_5pct'] = ratios.proporcion_cubierta_total<.05
    revision['alerta_menos_5m2_por_ambiente'] = ratios.cubierta_por_ambiente_m2<5
    revision['alerta_mas_150m2_por_ambiente'] = ratios.cubierta_por_ambiente_m2>150
    revision.to_csv(SALIDA/'03_auditoria_superficies.csv',index=False)
    graficar_datos(originales,d,geo,ratios)
    (SALIDA/'01_caso_extremo.md').write_text('''# 1. Revisión del caso extremo

Registro: `zp-60396281`, Virrey del Pino al 3500. CSV: USD 215.000, total 2.179 m², cubierta 1.276 m².

Se contrastó el anuncio el 2026-10-28: [fuente original](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-imponente-casa-con-el-mejor-jardin-de-belgrano-r-60396281.html).
La descripción ofrece dos casas linderas y el precio actual se consulta al anunciante. La ficha muestra 15 ambientes, 7 dormitorios y 107 años. La publicación no permite validar USD 215.000 ni asignar un precio individual.

Decisión: excluir este ID y URL del entrenamiento y evaluación de viviendas individuales, por su alcance verificado. No se corrige precio ni metraje, no se modifica el CSV ni se excluyen otras propiedades grandes por semejanza. Que el anuncio hoy no muestre precio no prueba cuál fue su precio histórico.

La comparación conserva los IDs/grupos del reparto anterior. La base y todas las variantes usan la misma prueba común, sin este registro. La caída respecto al 23,69% histórico por quitarlo es cambio de población y NO mejora predictiva.
''',encoding='utf-8')
    (SALIDA/'03_revision_superficies.md').write_text('''# 3. Semántica y variables de superficie

Se detectaron 37 casas con cubierta mayor que total en el CSV original. No se asume que todas sean incorrectas: en varios anuncios total puede representar el lote y cubierta sumar varias plantas.

- [zp-55391782](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-oppel-casa-en-venta-belgrano-r-capital-federal-55391782.html): ficha 265 m² totales y 388 m² cubiertos; descripción en dos plantas. La desigualdad existe en la fuente y no demuestra un error de extracción.
- [zp-56984563](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-imperdible-oportunidad-casa-sobre-lote-propio-56984563.html): ficha 250 y 320 m²; describe planta baja y primer piso. Evidencia indexada de 2025, no actualización certificada del anuncio.
- No pudo recuperarse `zp-55701759`; queda sin verificar.

Se conserva por ahora la restricción cubierta ≤ total del contrato actual de entrada: el dataset no separa superficie de terreno de superficie total construida, y la API también rechaza esa desigualdad. Reincorporar las 37 filas sin distinguir las medidas crearía un contrato diferente entre entrenamiento y uso. No se cambia la API ni el scraper.

Se implementan y comparan proporción cubierta/total, diferencia total−cubierta, cubierta por ambiente/dormitorio e indicadores de faltantes. La diferencia no se denomina patio ni terreno, y no se rellenan ceros ni metrajes inventados. Las alertas de proporciones extremas solo generan revisión, sin eliminar filas.

Trabajo de datos pendiente para el equipo: exportar terreno_m2 y total_construida_m2 separados, además de cubierta_m2 y su fuente. La implementación de las variables y su comparación quedan completas con el contrato disponible.
''',encoding='utf-8')
    return {'estados':geo.ubicacion_consistencia.value_counts().to_dict(),
            'gps_central_generico':int(geo.gps_central_generico.sum()),
            'cubierta_mayor_total_original':len(problema),
            'alertas_superficie':{c:int(revision[c].sum()) for c in revision if c.startswith('alerta_')}}


def graficar_datos(originales,d,geo,ratios):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator
    from .mejoras_segmentos import poligonos_barrios
    fig,axes=plt.subplots(1,2,figsize=(14,6))
    estados=geo.ubicacion_consistencia.value_counts()
    axes[0].barh(estados.index,estados.values,color='#2b8cbe')
    for i,v in enumerate(estados.values):axes[0].text(v+20,i,str(v),va='center')
    axes[0].set_xlim(0,max(estados.values)*1.15);axes[0].set_title('Calidad de ubicación · publicaciones válidas')
    for _,_,_,anillos in poligonos_barrios():
        for a in anillos:axes[1].plot(a[:,0],a[:,1],color='#bdbdbd',lw=.5)
    for estado,color in [('coincide','#2b8cbe'),('solo gps','#41ab5d'),('conflicto','#e6550d')]:
        mask=geo.ubicacion_consistencia==estado
        axes[1].scatter(d.loc[mask,'longitud'],d.loc[mask,'latitud'],s=7,alpha=.5,label=estado,c=color)
    axes[1].scatter([-58.3816],[-34.6037],marker='x',s=90,c='red',label=f'GPS central genérico ({int(geo.gps_central_generico.sum())})')
    axes[1].set_title('GPS frente al barrio declarado');axes[1].set_xlabel('Longitud');axes[1].set_ylabel('Latitud');axes[1].legend(fontsize=8)
    axes[1].xaxis.set_major_locator(MaxNLocator(5))
    axes[1].set_aspect(1/np.cos(np.deg2rad(-34.6)))
    fig.text(.5,.01,'Límites: GCBA / BA Data, CC-BY-2.5-AR. Un GPS dentro del polígono no verifica la dirección real.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,1));fig.savefig(SALIDA/'02_ubicacion.png',dpi=150);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(14,6))
    validos=(originales.superficie_total_m2>0)&(originales.superficie_cubierta_m2>0)
    crudo=originales.loc[validos];inversas=crudo.superficie_cubierta_m2>crudo.superficie_total_m2
    axes[0].scatter(crudo.loc[~inversas,'superficie_total_m2'],crudo.loc[~inversas,'superficie_cubierta_m2'],s=9,alpha=.4,label='Cubierta ≤ total')
    axes[0].scatter(crudo.loc[inversas,'superficie_total_m2'],crudo.loc[inversas,'superficie_cubierta_m2'],s=20,c='#e6550d',label=f'Cubierta > total ({int(inversas.sum())})')
    limites=[min(crudo.superficie_total_m2.min(),crudo.superficie_cubierta_m2.min()),max(crudo.superficie_total_m2.max(),crudo.superficie_cubierta_m2.max())]
    axes[0].plot(limites,limites,'k--',lw=1,label='Cubierta = total');axes[0].set_xscale('log');axes[0].set_yscale('log')
    axes[0].set_xlabel('Total declarado (m², log)');axes[0].set_ylabel('Cubierta declarada (m², log)');axes[0].set_title('CSV original · medidas positivas sin recortar extremos');axes[0].legend(fontsize=8)
    for tipo in ('casa','departamento','ph'):
        mask=d.tipo_propiedad==tipo
        axes[1].hist(ratios.loc[mask,'proporcion_cubierta_total'],bins=np.linspace(0,1,21),histtype='step',linewidth=2,label=f'{tipo} (n={int(mask.sum())})')
    axes[1].set_title('Cubierta / total · población válida actual');axes[1].set_xlabel('Proporción cubierta / total');axes[1].set_ylabel('Publicaciones');axes[1].legend()
    fig.text(.5,.01,'Total no siempre significa terreno. No se inventan superficies ni se eliminan filas según su precio o error.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,1));fig.savefig(SALIDA/'03_superficies.png',dpi=150);plt.close(fig)


def ejecutar(ruta=DATASET_CSV,*,activar=True):
    ruta = Path(ruta).resolve()
    originales,d,grupos,train,test,historico,pred_ant,limpieza = cargar_comparacion(ruta)
    auditorias = auditar(originales,d)
    if not (SALIDA/'referencia_historica.json').exists():
        referencia = {k:historico[k] for k in ('configuracion_elegida','prueba','archivo_sha256','huella_dataset_sha256','random_state')}
        (SALIDA/'referencia_historica.json').write_text(json.dumps(referencia,ensure_ascii=False,indent=2)+'\n')
        pred_ant[['precio_observado_usd','precio_predicho_usd']].to_csv(SALIDA/'predicciones_historicas.csv')
    base = deepcopy(historico['configuracion_elegida'])
    base.pop('mejoras_segmentos',None)
    X,y = d[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS],d.precio_usd.to_numpy()
    particiones = [(train[a],train[b]) for a,b in GroupKFold(n_splits=5,shuffle=True,random_state=20261101).split(train,groups=grupos[train])]
    particion = pd.DataFrame({'id_propiedad':d.id_propiedad,'grupo':grupos,'particion':'entrenamiento','fold_validacion':-1})
    particion.loc[test,'particion'] = 'prueba'
    for i,(_,b) in enumerate(particiones,1):
        particion.loc[b,'fold_validacion'] = i
    particion.to_csv(SALIDA/'particiones.csv',index=False)
    resultados,configs = {},{}
    for nombre,opciones in VARIANTES.items():
        conf = deepcopy(base)
        if opciones:
            conf['mejoras_segmentos'] = opciones
        configs[nombre] = conf
        folds,oof = [],np.full(len(X),np.nan)
        for i,(a,b) in enumerate(particiones,1):
            assert not set(grupos[a])&set(grupos[b])
            print(f'{nombre}: validación {i}/5 ({len(a)} / {len(b)})',flush=True)
            m = crear_modelo(conf).fit(X.iloc[a],y[a])
            oof[b] = m.predict(X.iloc[b])
            folds.append({'fold':i,'n_entrena':len(a),'n_valida':len(b),'metricas':calcular_metricas(y[b],oof[b])})
        tipos = X.tipo_propiedad.to_numpy()
        resultados[nombre] = {'configuracion':conf,'folds':folds,
            'resumen_cv':{k:{'media':float(np.mean([f['metricas'][k] for f in folds])),
                             'desvio':float(np.std([f['metricas'][k] for f in folds],ddof=1))} for k in ('mape_porcentaje','mae_usd','rmse_usd')},
            'oof_por_tipo':{t:calcular_metricas(y[train][tipos[train]==t],oof[train][tipos[train]==t]) for t in sorted(set(tipos[train]))}}
        pd.DataFrame({'id_propiedad':d.iloc[train].id_propiedad,'observado':y[train],'predicho':oof[train]}).to_csv(SALIDA/f'oof_{nombre}.csv',index=False)
    elegido = elegir_mejora(resultados)
    # Persistir decisión ANTES de mirar holdout; nunca elegir según prueba.
    (SALIDA/'seleccion_interna.json').write_text(json.dumps({'elegido':elegido,'resultados':resultados},ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    informe = {'fecha_utc':datetime.now(timezone.utc).isoformat(),'archivo_sha256':hashlib.sha256(ruta.read_bytes()).hexdigest(),
               'huella_dataset_sha256':hashlib.sha256(d.to_json(orient='records',double_precision=15).encode()).hexdigest(),
               'huellas_codigo':huellas_codigo(),
               'mapa_sha256':hashlib.sha256(MAPA_BARRIOS.read_bytes()).hexdigest(),
               'fuente_mapa':'https://cdn.buenosaires.gob.ar/datosabiertos/datasets/barrios/barrios.geojson',
               'licencia_mapa':'CC-BY-2.5-AR; Gobierno de la Ciudad Autónoma de Buenos Aires / BA Data',
               'n_entrenamiento':len(train),'n_prueba':len(test),'grupos_prueba':len(set(grupos[test])),
               'grupos_compartidos':len(set(grupos[train])&set(grupos[test])),
               'limpieza':limpieza,'auditorias':auditorias,'elegido':elegido,
               'configuracion_elegida':configs[elegido],'activada':False,
               'regla_seleccion':'Menor MAPE medio CV, mejora >=0,20 puntos, gana >=3/5 folds; MAE/RMSE CV no empeoran >5%; MAPE OOF por tipo no empeora >10%. Si nadie cumple, conservar base.',
               'nota':'Validación interna de desarrollo; prueba común histórica ya explorada. No es validación externa. Especialistas entrenados solo en cada fold y enrutados por tipo, nunca por precio.',
               'resultados':resultados}
    predicciones = pd.DataFrame({'id_propiedad':d.iloc[test].id_propiedad.to_numpy(),'grupo_inmueble':grupos[test],
                                 'tipo_propiedad':X.iloc[test].tipo_propiedad.to_numpy(),'precio_observado_usd':y[test]})
    modelos = {}
    for nombre,conf in configs.items():
        print(f'{nombre}: diagnóstico de prueba común (no selecciona)',flush=True)
        modelo = crear_modelo(conf).fit(X.iloc[train],y[train])
        pred = modelo.predict(X.iloc[test])
        resultados[nombre]['prueba'] = calcular_metricas(y[test],pred)
        resultados[nombre]['segmentos'] = evaluar_segmentos(X,y,pred,train,test,grupos=grupos)
        predicciones[nombre] = pred
        if nombre in (elegido,'base_revisada'):
            modelos[nombre] = modelo
    anteriores = pred_ant.loc[predicciones.id_propiedad,'precio_predicho_usd'].to_numpy()
    # Caso excluido estaba en test: la base se debe reproducir exactamente.
    np.testing.assert_allclose(predicciones.base_revisada,anteriores,rtol=1e-10,atol=1e-5)
    informe['prueba_historica_675'] = historico['prueba']
    informe['prueba_historica_en_cohorte_comun'] = calcular_metricas(y[test],anteriores)
    if activar:
        CONFIGURACION_MODELO.write_text(json.dumps(configs[elegido],ensure_ascii=False,indent=2)+'\n')
        informe['activada'] = True
    predicciones.to_csv(SALIDA/'predicciones_prueba_comun.csv',index=False)
    (SALIDA/'metricas_mejoras.json').write_text(json.dumps(informe,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    generar_salidas(informe)
    elegido_segmentos = resultados[elegido]['segmentos']
    from .evaluar_dataset import guardar_analisis_segmentos
    guardar_analisis_segmentos(elegido_segmentos,SALIDA)
    generar_shap(modelos[elegido],X.iloc[test],configs[elegido])
    print(json.dumps({'elegido':elegido,'activada':activar,'prueba':resultados[elegido]['prueba']},ensure_ascii=False,indent=2),flush=True)
    return informe


def generar_shap(modelo,X,configuracion):
    if hasattr(modelo,'aportes_shap'):
        d,valores = modelo.aportes_shap(X)
        reconstruida = np.exp(valores.sum(axis=1)) if configuracion['transformacion_objetivo']=='log' else valores.sum(axis=1)
        np.testing.assert_allclose(reconstruida,modelo.predict(X),rtol=1e-9,atol=1e-5)
        import matplotlib.pyplot as plt
        importancia = np.abs(valores[:,:-1]).mean(axis=0)
        orden = np.argsort(importancia)[-15:]
        fig,ax=plt.subplots(figsize=(11,7))
        ax.barh(np.asarray(d.columns)[orden],importancia[orden]);ax.set_xlabel('Media de |SHAP| en log(precio USD)')
        ax.set_title('Modelo elegido · SHAP de cada modelo realmente utilizado')
        fig.tight_layout();fig.savefig(SALIDA/'08_shap_modelo_elegido.png',dpi=150);plt.close(fig)
    else:
        from .evaluar_dataset import graficar_shap
        graficar_shap(modelo,X,SALIDA,configuracion)


def evaluar_vigente(ruta=DATASET_CSV,*,solo_segmentos=False,solo_shap=False):
    """Regenera diagnósticos elegidos sin repetir búsqueda ni cambiar parámetros."""
    _,d,grupos,train,test,_,_,_ = cargar_comparacion(Path(ruta))
    informe=json.loads((SALIDA/'metricas_mejoras.json').read_text())
    conf=json.loads(CONFIGURACION_MODELO.read_text())
    huella=hashlib.sha256(d.to_json(orient='records',double_precision=15).encode()).hexdigest()
    if (conf!=informe['configuracion_elegida'] or huella!=informe['huella_dataset_sha256']
            or huellas_codigo()!=informe['huellas_codigo']
            or hashlib.sha256(MAPA_BARRIOS.read_bytes()).hexdigest()!=informe['mapa_sha256']):
        raise ValueError('Configuración, variables o mapa cambiaron: revisar y repetir la comparación antes de reutilizar sus resultados.')
    X=d[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]
    guardadas=pd.read_csv(SALIDA/'predicciones_prueba_comun.csv').set_index('id_propiedad')
    ids=d.iloc[test].id_propiedad
    if set(ids)!=set(guardadas.index):
        raise ValueError('Los IDs de prueba no coinciden con las predicciones guardadas.')
    np.testing.assert_allclose(d.precio_usd.iloc[test],guardadas.loc[ids,'precio_observado_usd'],rtol=0,atol=1e-6)
    np.testing.assert_array_equal(grupos[test],guardadas.loc[ids,'grupo_inmueble'])
    pred=guardadas.loc[ids,informe['elegido']].to_numpy()
    if not solo_segmentos:
        modelo=crear_modelo(conf).fit(X.iloc[train],d.precio_usd.iloc[train])
        np.testing.assert_allclose(modelo.predict(X.iloc[test]),pred,rtol=1e-10,atol=1e-5)
        generar_shap(modelo,X.iloc[test],conf)
    if not solo_shap:
        from .evaluar_dataset import guardar_analisis_segmentos
        guardar_analisis_segmentos(evaluar_segmentos(X,d.precio_usd,pred,train,test,grupos=grupos),SALIDA)
        generar_salidas(informe)
    print(json.dumps({'elegido':informe['elegido'],'n_prueba':len(test),'mape_porcentaje':calcular_metricas(d.precio_usd.iloc[test],pred)['mape_porcentaje'],
                      'salida':str(SALIDA),'configuracion_modificada':False},ensure_ascii=False,indent=2))


def generar_salidas(informe):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    rs = informe['resultados']; nombres = list(rs)
    fig,axes=plt.subplots(1,2,figsize=(15,6))
    for ax,campo,titulo in zip(axes,('resumen_cv','prueba'),('Validación interna · media y desvío entre 5 folds','Prueba común · diagnóstico posterior a selección')):
        vals = [rs[n][campo]['mape_porcentaje']['media'] if campo=='resumen_cv' else rs[n][campo]['mape_porcentaje'] for n in nombres]
        err = [rs[n][campo]['mape_porcentaje']['desvio'] for n in nombres] if campo=='resumen_cv' else None
        ax.barh([ETIQUETAS[n] for n in nombres],vals,xerr=err,color=['#2b8cbe' if n==informe['elegido'] else '#a6bddb' for n in nombres])
        ax.set_xlabel('MAPE (%)');ax.set_title(titulo);ax.invert_yaxis()
        for i,v in enumerate(vals):ax.text(v+(err[i] if err else 0)+.2,i,f'{v:.2f}%',va='center')
        ax.set_xlim(0,max(vals)*1.25)
    fig.suptitle('Cuatro mejoras separadas · misma población y particiones')
    fig.tight_layout();fig.savefig(SALIDA/'04_comparacion_mejoras.png',dpi=150);plt.close(fig)
    texto=['# Cuatro mejoras: resultados separados','',
           f"Elegida por validación interna: **{informe['elegido']}**. Configuración activada localmente: {informe['activada']}.",'',
           f"Prueba común: {informe['n_prueba']} publicaciones / {informe['grupos_prueba']} grupos; entrenamiento: {informe['n_entrenamiento']}; grupos compartidos: {informe['grupos_compartidos']}.",'',
           '## 1. Caso extremo','',
           '[Revisión y evidencia](01_caso_extremo.md). Se excluye una oferta de dos casas linderas; no se modifica su precio ni el CSV.',
           f"MAPE histórico de 675 filas: {informe['prueba_historica_675']['mape_porcentaje']:.2f}%. Misma predicción histórica sobre las {informe['n_prueba']} filas comunes: {informe['prueba_historica_en_cohorte_comun']['mape_porcentaje']:.2f}%. Esta diferencia es población, NO ganancia del modelo.",'',
           '## 2. Ubicación','',
           'Límites oficiales locales de [BA Data](https://data.buenosaires.gob.ar/dataset/barrios); atribución GCBA, licencia CC-BY-2.5-AR. No hay llamadas de red al entrenar ni al tasar.',
           f"Estados: {informe['auditorias']['estados']}. Coordenada central genérica: {informe['auditorias']['gps_central_generico']} filas.",
           'Se calculan barrio por GPS, barrio principal, subzona y consistencia con el texto. Las discrepancias quedan registradas; pertenecer a un polígono no certifica que el GPS del scraper sea correcto. No se atribuye barrio a coordenadas genéricas, fuera de CABA o ambiguas en límites.',
           '[Detalle por publicación](02_auditoria_ubicacion.csv). [Gráfico de ubicación](02_ubicacion.png).','',
           '## 3. Superficies','',
           '[Revisión de semántica y fuentes](03_revision_superficies.md). Se comparan nueve variables derivadas de metrajes y faltantes. Sin eliminar extremos por precio o error.',
           '[37 casas que requieren distinguir terreno de construido](03_cubierta_mayor_total.csv). [Alertas observables](03_auditoria_superficies.csv). [Gráfico de superficies](03_superficies.png).','',
           '## 4. General frente a especialistas por tipo','',
           'Se prueban tres especialistas (casa/departamento/PH) con los mismos parámetros. Cada uno solo ve las filas de su tipo en el entrenamiento de su fold. Tipos nuevos o con menos de 100 filas usan el modelo general de respaldo. Se enruta por tipo conocido, nunca por el precio objetivo.',
           'La comparación incluye cada cambio aislado y la combinación de ubicación/superficies, con y sin especialistas. No se fuerza adoptar una variante si no mejora validación.','',
           '## Comparación controlada','',informe['regla_seleccion'],'',
           '| Variante | CV MAPE media ± desvío | Prueba MAPE | MAE USD | RMSE USD | R² |',
           '|---|---:|---:|---:|---:|---:|']
    for n,r in rs.items():
        cv,p = r['resumen_cv']['mape_porcentaje'],r['prueba']
        texto.append(f"| {n} | {cv['media']:.2f}% ± {cv['desvio']:.2f} | {p['mape_porcentaje']:.2f}% | {p['mae_usd']:,.0f} | {p['rmse_usd']:,.0f} | {p['r2']:.3f} |")
    texto+=['','El desvío entre folds no es un intervalo de confianza. Los resultados de prueba no participan en la selección; este conjunto ya fue explorado. Se necesita una extracción futura verificada para confirmar generalización.',
            '','## Tipos en prueba común','', '| Variante | Casa MAPE | Departamento MAPE | PH MAPE |','|---|---:|---:|---:|']
    for n,r in rs.items():
        v=r['segmentos']['por_tipo'];texto.append('| '+n+' | '+' | '.join(f"{v[t]['metricas']['mape_porcentaje']:.2f}%" for t in ('casa','departamento','ph'))+' |')
    texto+=['','[Gráfico de comparación](04_comparacion_mejoras.png). [Segmentos del modelo elegido](evaluacion_segmentos.md).',
            '','La referencia histórica mínima se conserva en `referencia_historica.json` y `predicciones_historicas.csv`. Los resultados anteriores de `../evaluacion/` no se sobrescriben durante esta comparación. Estos archivos son la referencia actual de esta comparación. La configuración local se aplicará al próximo entrenamiento; no se reinicia ni despliega la API.']
    (SALIDA/'RESULTADOS.md').write_text('\n'.join(texto)+'\n',encoding='utf-8')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv',type=Path,default=DATASET_CSV)
    p.add_argument('--no-activar',action='store_true',help='Evalúa sin guardar la configuración elegida.')
    p.add_argument('--evaluar-vigente',action='store_true',help='Regenera solo el diagnóstico elegido, sin seleccionar alternativas.')
    args=p.parse_args()
    if args.evaluar_vigente:
        evaluar_vigente(args.csv)
    else:
        ejecutar(args.csv,activar=not args.no_activar)


if __name__=='__main__':
    main()
