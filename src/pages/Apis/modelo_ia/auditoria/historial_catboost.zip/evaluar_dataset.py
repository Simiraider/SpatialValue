"""Ejecutar desde la raíz: PYTHONPATH=src/pages/Apis python -m modelo_ia.evaluar_dataset.

Lee el CSV del usuario; no importa FastAPI, no publica ni cambia el modelo activo.
"""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import numpy as np
from .modelo import (
    cargar_dataset_csv, DATASET_CSV, COLUMNAS_TEXTO, COLUMNAS_NUMERICAS,
    limpiar_registros, _preparar_features, crear_modelo, evaluar_modelo,
    agrupar_inmuebles, dividir_datos, catboost_ajustado, CONFIGURACION_BASE,
    CONFIGURACION_MODELO, leer_configuracion,
    detectar_republicaciones, leer_revision_republicaciones,
    calcular_metricas,
    evaluar_segmentos, RANGOS_PRECIO,
)


def main():
    parser = argparse.ArgumentParser(description="Evalúa CatBoost con el CSV de propiedades, sin conexión a Neon.")
    parser.add_argument("--csv", type=Path, help="CSV alternativo; por defecto usa la copia incluida con el modelo.")
    parser.add_argument("--optimizar", action="store_true", help="Ajusta 25 configuraciones de árboles manteniendo el objetivo actual, solo en validación interna agrupada.")
    parser.add_argument("--comparar-precio", action="store_true", help="Compara solo objetivo directo/log y pérdidas RMSE/MAE/Huber, con los mismos árboles.")
    parser.add_argument("--depurar-republicaciones", action="store_true", help="Quita copias verificadas del CSV, con respaldo y registro, antes de evaluar.")
    parser.add_argument("--solo-shap", action="store_true", help="Genera SHAP del modelo vigente sobre la prueba guardada, sin repetir CV ni seleccionar parámetros.")
    parser.add_argument("--solo-segmentos", action="store_true", help="Evalúa segmentos usando las predicciones guardadas, sin entrenar ni cambiar CatBoost.")
    args = parser.parse_args()
    if args.optimizar and args.comparar_precio:
        parser.error('Elegí --comparar-precio o --optimizar para separar el efecto del precio del ajuste de árboles.')
    if (args.solo_shap or args.solo_segmentos) and (args.optimizar or args.comparar_precio or args.depurar_republicaciones or (args.solo_shap and args.solo_segmentos)):
        parser.error('Usá --solo-shap o --solo-segmentos por separado, sin cambios de datos o selección.')
    ruta_csv = (args.csv or Path(os.environ.get("MODELO_DATASET_CSV") or DATASET_CSV)).expanduser().resolve()
    # La comparación de mejoras tiene población revisada y referencias propias.
    # Evita sobrescribir la evaluación histórica o analizar sus predicciones viejas.
    from .comparar_mejoras import SALIDA as salida_mejoras, evaluar_vigente
    if (salida_mejoras/'metricas_mejoras.json').exists() and not (args.optimizar or args.comparar_precio or args.depurar_republicaciones):
        evaluar_vigente(ruta_csv,solo_segmentos=args.solo_segmentos,solo_shap=args.solo_shap)
        return
    if leer_configuracion().get('mejoras_segmentos') and (args.optimizar or args.comparar_precio):
        parser.error('Las variantes de variables/especialistas se comparan con python -m modelo_ia.comparar_mejoras; no usar el diagnóstico de un único CatBoost para un conjunto de especialistas.')
    if args.depurar_republicaciones:
        print(json.dumps(depurar_csv_republicaciones(ruta_csv), ensure_ascii=False, indent=2), flush=True)
    datos = cargar_dataset_csv(ruta_csv)
    filas = datos.to_dict(orient="records")
    # Orden estable para que la misma extracción produzca las mismas particiones.
    filas.sort(key=lambda r: str(r.get('id_propiedad') or ''))
    registros, limpieza = limpiar_registros(filas)
    df = _preparar_features(pd.DataFrame(registros))
    X = df[COLUMNAS_TEXTO + COLUMNAS_NUMERICAS]
    grupos = agrupar_inmuebles(pd.DataFrame(registros))
    seleccion = None
    configuracion = leer_configuracion()
    configuracion_anterior = configuracion
    salida = Path(__file__).resolve().parent / 'auditoria' / 'evaluacion'
    if args.solo_shap or args.solo_segmentos:
        ruta_informe = salida/'metricas_modelo.json'
        informe = json.loads(ruta_informe.read_text())
        huella = hashlib.sha256(df.to_json(orient='records',double_precision=15).encode()).hexdigest()
        if (informe['archivo_sha256'] != hashlib.sha256(ruta_csv.read_bytes()).hexdigest()
                or informe['huella_dataset_sha256'] != huella
                or informe['configuracion_elegida'] != configuracion):
            raise ValueError('La fuente, la limpieza o la configuración cambió. Generá una evaluación completa antes de analizar sus predicciones guardadas.')
        train, test = dividir_datos(len(X), grupos, random_state=informe['random_state'])
        referencia = pd.read_csv(salida/'predicciones_prueba.csv').set_index('id_propiedad')
        ids = df.iloc[test].id_propiedad.astype(str).tolist()
        if set(ids) != set(referencia.index):
            raise ValueError('Las propiedades de prueba no coinciden con la evaluación guardada.')
        np.testing.assert_allclose(df.precio_usd.iloc[test],referencia.loc[ids,'precio_observado_usd'],rtol=0,atol=1e-6)
        if args.solo_segmentos:
            pred = referencia.loc[ids,'precio_predicho_usd'].to_numpy()
            informe['evaluacion_segmentos'] = evaluar_segmentos(X,df.precio_usd,pred,train,test,grupos=grupos)
            for campo in ('mae_usd','rmse_usd','mape_porcentaje'):
                np.testing.assert_allclose(informe['evaluacion_segmentos']['metricas_globales'][campo],informe['prueba'][campo])
            guardar_analisis_segmentos(informe['evaluacion_segmentos'],salida)
            ruta_informe.write_text(json.dumps(informe,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
            print(json.dumps({'archivo':'evaluacion_segmentos.md','n_prueba':len(test),
                              'tipos':{k:{'n':v['n_prueba'],'metricas':v['metricas']} for k,v in informe['evaluacion_segmentos'].get('por_tipo',{}).items()}},ensure_ascii=False,indent=2))
            return
        modelo = crear_modelo(configuracion).fit(X.iloc[train],df.precio_usd.iloc[train])
        diferencia = float(np.max(np.abs(modelo.predict(X.iloc[test])-referencia.loc[ids,'precio_predicho_usd'].to_numpy())))
        if diferencia > 1e-5:
            raise ValueError('El modelo reproducido no coincide con las predicciones guardadas; regenerá la evaluación.')
        informe['shap'] = graficar_shap(modelo,X.iloc[test],salida,configuracion)
        informe['shap']['error_maximo_vs_predicciones_guardadas_usd'] = diferencia
        ruta_informe.write_text(json.dumps(informe,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
        print(json.dumps(informe['shap'],ensure_ascii=False,indent=2))
        return
    if args.optimizar:
        configuracion, seleccion = seleccionar_configuracion(X, df.precio_usd, grupos, configuracion_actual=configuracion_anterior)
    elif args.comparar_precio:
        candidata, seleccion = seleccionar_configuracion(X, df.precio_usd, grupos, solo_precio=True)
    print("Evaluando configuración elegida y referencia en particiones agrupadas...", flush=True)
    modelo, informe, detalle = evaluar_modelo(crear_modelo(configuracion), X, df.precio_usd, grupos=grupos, random_state=20261028)
    _, referencia, _ = evaluar_modelo(crear_modelo(CONFIGURACION_BASE), X, df.precio_usd, grupos=grupos, random_state=20261028)
    informe['referencia_catboost_directo'] = referencia
    if seleccion:
        informe['seleccion_interna'] = seleccion
    informe['configuracion_elegida'] = configuracion
    if args.optimizar:
        if configuracion == configuracion_anterior:
            anterior = informe
        else:
            _, anterior, _ = evaluar_modelo(crear_modelo(configuracion_anterior),X,df.precio_usd,grupos=grupos,random_state=20261028)
        informe['comparacion_ajuste'] = {
            'configuracion_anterior':configuracion_anterior,'configuracion_ajustada':configuracion,
            'prueba_anterior':anterior['prueba'],'prueba_ajustada':informe['prueba'],
            'cv_anterior':anterior['cross_validation'],'cv_ajustada':informe['cross_validation'],
            'prueba_por_tipo_anterior':anterior['prueba_por_tipo'],
            'prueba_por_rango_precio_anterior':anterior['prueba_por_rango_precio'],
            'nota':'Mismo CSV, limpieza, variables, escala de precio, grupos y particiones. Parámetros elegidos solo en CV interna; el test ya fue explorado y no sustituye validación futura.',
        }
    if args.comparar_precio:
        train, test = dividir_datos(len(X), grupos, random_state=20261028)
        if candidata == configuracion:
            prueba_candidata = informe['prueba']
        else:
            propuesta = crear_modelo(candidata).fit(X.iloc[train], df.precio_usd.iloc[train])
            prueba_candidata = calcular_metricas(df.precio_usd.iloc[test], propuesta.predict(X.iloc[test]))
        informe['comparacion_precio'] = {
            'configuracion_vigente':configuracion, 'candidata_por_validacion_interna':candidata,
            'prueba_vigente':informe['prueba'], 'prueba_candidata':prueba_candidata,
            'configuracion_modificada':False,
            'nota':'Comparación diagnóstica: la candidata se elige antes de medir prueba. Este comando conserva la configuración vigente; una diferencia pequeña en CV no demuestra una mejora. El CSV ya fue explorado y requiere validación futura.',
        }
    base = catboost_ajustado(modelo)
    informe['importancia_variables'] = dict(zip(base.feature_names_, base.get_feature_importance().tolist()))
    train, _ = dividir_datos(len(X), grupos, random_state=20261028)
    from sklearn.model_selection import GroupShuffleSplit
    a, b = next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42).split(X.iloc[train],groups=grupos[train]))
    a, b = train[a], train[b]
    # Modelo diagnóstico separado; eval_set solo interno, sin seleccionar árboles.
    configuracion_directa = {**configuracion, 'transformacion_objetivo':'directo'}
    diagnostico = crear_modelo(configuracion_directa)
    objetivo_log = configuracion['transformacion_objetivo'] == 'log'
    y_train = np.log(df.precio_usd.iloc[a]) if objetivo_log else df.precio_usd.iloc[a]
    y_valid = np.log(df.precio_usd.iloc[b]) if objetivo_log else df.precio_usd.iloc[b]
    centro_log = float(y_train.mean()) if objetivo_log and configuracion.get('centrar_log',False) else 0.
    y_train, y_valid = y_train-centro_log, y_valid-centro_log
    diagnostico.fit(X.iloc[a], y_train, eval_set=(X.iloc[b], y_valid), use_best_model=False)
    curva_train, curva_valid, iteraciones = [], [], []
    for i, (p_train,p_valid) in enumerate(zip(diagnostico.staged_predict(X.iloc[a],eval_period=10), diagnostico.staged_predict(X.iloc[b],eval_period=10)),1):
        if objetivo_log:
            p_train,p_valid=np.exp(p_train+centro_log),np.exp(p_valid+centro_log)
        curva_train.append(float(np.sqrt(np.mean((df.precio_usd.iloc[a]-p_train)**2))))
        curva_valid.append(float(np.sqrt(np.mean((df.precio_usd.iloc[b]-p_valid)**2))))
        iteraciones.append(min(i*10,diagnostico.tree_count_))
    informe['curva_validacion_interna'] = {
        'n_entrenamiento':len(a),'n_validacion':len(b),'iteraciones':iteraciones,
        'centro_log_aprendido_solo_en_entrenamiento_interno':centro_log,
        'descripcion':'Modelo diagnóstico por grupos; RMSE calculado en dólares incluso si se entrena en logaritmos. No selecciona iteraciones.',
        'rmse_entrenamiento':curva_train,'rmse_validacion':curva_valid,
    }
    informe.update({
        'fecha_utc': datetime.now(timezone.utc).isoformat(),
        'fuente': 'CSV propiedades: misma carga, limpieza, features y CatBoost de la API; ordenado por ID',
        'archivo_fuente': ruta_csv.name,
        'archivo_sha256': hashlib.sha256(ruta_csv.read_bytes()).hexdigest(),
        'limpieza': limpieza,
        'huella_revision_republicaciones_sha256':hashlib.sha256(json.dumps(leer_revision_republicaciones(),sort_keys=True,ensure_ascii=False).encode()).hexdigest(),
        'huella_dataset_sha256': hashlib.sha256(df.to_json(orient='records', double_precision=15).encode()).hexdigest(),
        'versiones': {p: importlib.metadata.version(p) for p in ['catboost', 'scikit-learn', 'pandas', 'numpy']},
        'modelo': {'algoritmo':'CatBoostRegressor','hiperparametros':base.get_params(),'parametros_efectivos':base.get_all_params(),'transformacion_objetivo':configuracion['transformacion_objetivo']},
    })
    detalle['id_propiedad'] = [registros[int(i)].get('id_propiedad') for i in detalle.indice_fila]
    detalle['tipo_propiedad'] = [df.iloc[int(i)].tipo_propiedad for i in detalle.indice_fila]
    salida.mkdir(parents=True, exist_ok=True)
    informe['shap'] = graficar_shap(modelo,X.iloc[detalle.indice_fila.to_numpy(dtype=int)],salida,configuracion)
    (salida / 'metricas_modelo.json').write_text(json.dumps(informe, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    if args.optimizar:
        CONFIGURACION_MODELO.write_text(json.dumps(configuracion,ensure_ascii=False,indent=2)+'\n')
    detalle['grupo_inmueble'] = [grupos[int(i)] for i in detalle.indice_fila]
    detalle.to_csv(salida / 'predicciones_prueba.csv', index=False)
    guardar_auditoria_datos(datos, registros, grupos, salida)
    graficar(detalle, informe, salida)
    analizar_errores(detalle, datos, informe, salida)
    if args.comparar_precio:
        graficar_tratamiento_precio(df.precio_usd, informe, salida)
    else:
        (salida/'07_tratamiento_precio.png').unlink(missing_ok=True)
    if args.optimizar:
        graficar_ajuste_catboost(informe,salida)
    else:
        (salida/'09_ajuste_catboost.png').unlink(missing_ok=True)
    print(json.dumps({k:informe[k] for k in ['limpieza','n_entrenamiento','n_prueba','prueba','referencia_mediana_prueba','cross_validation','cobertura_tipo_propiedad']},ensure_ascii=False,indent=2))


def graficar_shap(modelo, X_prueba, salida, configuracion):
    """Tree SHAP nativo de CatBoost; explica la salida original de sus árboles.

    En log(precio), los aportes son aditivos en logaritmos, no en dólares.
    No usa etiquetas de prueba, no reajusta el modelo y no interpreta categorías
    como números ordinales. Categóricas y faltantes se muestran en gris.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    from matplotlib.cm import ScalarMappable
    from catboost import Pool
    from sklearn.compose import TransformedTargetRegressor

    base = catboost_ajustado(modelo)
    pool = Pool(X_prueba,cat_features=base.get_cat_feature_indices())
    matriz = np.asarray(base.get_feature_importance(pool,type='ShapValues',thread_count=4))
    aportes, esperado = matriz[:,:-1], matriz[:,-1]
    salida_raw = np.asarray(base.predict(pool,prediction_type='RawFormulaVal'))
    reconstruida = esperado+aportes.sum(axis=1)
    np.testing.assert_allclose(reconstruida,salida_raw,rtol=1e-10,atol=1e-10)
    pred_usd = (modelo.transformer_.inverse_transform(reconstruida.reshape(-1,1)).ravel()
                if isinstance(modelo,TransformedTargetRegressor) else reconstruida)
    np.testing.assert_allclose(pred_usd,modelo.predict(X_prueba),rtol=1e-10,atol=1e-6)
    medias = np.abs(aportes).mean(axis=0)
    orden = np.argsort(-medias,kind='stable')
    elegidas = orden[:min(15,len(orden))]
    etiquetas = {
        'superficie_total_m2':'Superficie total (m²)', 'superficie_cubierta_m2':'Superficie cubierta (m²)',
        'barrio_zona':'Barrio', 'tipo_propiedad':'Tipo de propiedad', 'anios_de_antiguedad':'Antigüedad (años)',
        'latitud':'Latitud', 'longitud':'Longitud', 'ambientes':'Ambientes', 'dormitorios':'Dormitorios',
        'banos':'Baños', 'expensas_ars':'Expensas (ARS)', 'piso':'Piso', 'estado':'Estado',
        'orientacion':'Orientación', 'disposicion':'Disposición', 'seguridad_tipo':'Tipo de seguridad',
    }
    log = configuracion['transformacion_objetivo'] == 'log'
    escala = 'log(precio en USD)' if log else 'precio en USD'
    if log and configuracion.get('centrar_log',False):
        escala += ' centrado'
    nombres = [X_prueba.columns[i] for i in elegidas]
    fig,(ax_barras,ax_puntos) = plt.subplots(1,2,figsize=(16,10),sharey=True,
                                           gridspec_kw={'width_ratios':[1,1.8]})
    posiciones = np.arange(len(elegidas))
    barras = ax_barras.barh(posiciones,medias[elegidas],color='#247BA0',height=.65)
    ax_barras.bar_label(barras,fmt='%.3f',padding=5,fontsize=9)
    ax_barras.set(yticks=posiciones,yticklabels=[etiquetas.get(n,n.replace('_',' ').capitalize()) for n in nombres],
                  xlabel=f'Media de |SHAP| · {escala}',title='Influencia media en las propiedades de prueba')
    ax_barras.invert_yaxis()
    ax_barras.set_xlim(0,float(medias[elegidas].max())*1.3 or 1)
    rng = np.random.default_rng(42)
    mapa = plt.get_cmap('coolwarm')
    categorias = set(base.get_cat_feature_indices())
    for y,col in enumerate(elegidas):
        colores = np.tile(np.array([.56,.56,.56,.65]),(len(X_prueba),1))
        if col not in categorias:
            valores = pd.to_numeric(X_prueba.iloc[:,col],errors='coerce').to_numpy(dtype=float)
            conocidos = np.isfinite(valores)
            if conocidos.any():
                bajo,alto = np.quantile(valores[conocidos],[.05,.95])
                if bajo == alto:
                    bajo,alto = valores[conocidos].min(),valores[conocidos].max()
                intensidad = (np.clip((valores[conocidos]-bajo)/(alto-bajo),0,1)
                              if alto > bajo else np.full(conocidos.sum(),.5))
                colores[conocidos] = mapa(intensidad)
        jitter = rng.uniform(-.30,.30,len(X_prueba))
        ax_puntos.scatter(aportes[:,col],y+jitter,c=colores,s=13,alpha=.6,linewidths=0,rasterized=True)
    ax_puntos.axvline(0,color='#555555',linewidth=1)
    ax_puntos.set(xlabel=f'Aporte SHAP a {escala} · negativo baja / positivo sube',
                  title='Cada punto es una propiedad: dirección y dispersión del aporte')
    for ax in (ax_barras,ax_puntos):
        ax.grid(axis='x',alpha=.15)
        ax.set_axisbelow(True)
        for lado in ('top','right'):
            ax.spines[lado].set_visible(False)
    colorbar = fig.colorbar(ScalarMappable(norm=Normalize(0,1),cmap=mapa),ax=ax_puntos,pad=.025,fraction=.025)
    colorbar.set_ticks([0,1],labels=['Bajo','Alto'])
    colorbar.set_label('Valor numérico relativo dentro de cada variable')
    fig.suptitle(f'SHAP · CatBoost actual · {configuracion.get("nombre",configuracion["transformacion_objetivo"])}',fontsize=17,y=.98)
    fig.text(.5,.94,f'{len(X_prueba):,} propiedades de prueba · 15 variables principales · sin usar estas propiedades para entrenar',ha='center',fontsize=11)
    fig.text(.5,.035,'Gris: categorías o valores faltantes. El color numérico se limita visualmente a percentiles 5–95; los datos no se modifican.',ha='center',fontsize=10)
    fig.text(.5,.015,'SHAP describe cómo predice este modelo; no demuestra causalidad ni precisión. Los aportes de variables correlacionadas pueden repartirse.',ha='center',fontsize=10)
    fig.subplots_adjust(left=.18,right=.94,bottom=.12,top=.88,wspace=.14)
    salida = Path(salida)
    salida.mkdir(parents=True,exist_ok=True)
    fig.savefig(salida/'08_shap.png',dpi=170)
    plt.close(fig)
    return {
        'fecha_utc':datetime.now(timezone.utc).isoformat(),'archivo':'08_shap.png',
        'metodo':'CatBoost Tree SHAP nativo (ShapValues), sin reference_data externo; usa la estructura y pesos de hojas del modelo entrenado.',
        'n_propiedades_prueba':len(X_prueba),'n_variables':len(X_prueba.columns),'escala_aditiva':escala,
        'error_maximo_aditividad':float(np.max(np.abs(reconstruida-salida_raw))),
        'error_maximo_reconstruccion_usd':float(np.max(np.abs(pred_usd-modelo.predict(X_prueba)))),
        'importancia_media_absoluta':{str(X_prueba.columns[i]):float(medias[i]) for i in orden},
        'notas':['Las categorías no tienen un orden numérico y se muestran en gris.',
                 'No es un porcentaje del precio, una prueba de causalidad ni una métrica de precisión.',
                 'Las variables correlacionadas pueden repartirse la atribución; el ranking depende del modelo y de esta muestra.'],
    }


def guardar_analisis_segmentos(segmentos,salida):
    """Gráficos y tablas del mismo test; no ajusta modelos ni modifica datos."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    salida = Path(salida)
    salida.mkdir(parents=True,exist_ok=True)
    precios = {'hasta_100k':'≤100k','100k_250k':'100k–250k','250k_500k':'250k–500k',
               '500k_1m':'500k–1M','mas_1m':'>1M'}
    etiqueta = lambda k: 'PH' if k=='ph' else precios.get(k,k.replace('_',' ').title())
    tipos = segmentos.get('por_tipo',{})
    rangos = segmentos['por_precio']
    global_mape = segmentos['metricas_globales']['mape_porcentaje'] if segmentos['metricas_globales'] else None
    fig,axes = plt.subplots(2,2,figsize=(15,11))
    for ax,datos,titulo in [(axes[0,0],tipos,'Error por tipo de propiedad'),(axes[0,1],rangos,'Error por precio observado (USD)')]:
        filas = [(k,v) for k,v in datos.items() if v['metricas'] is not None]
        x = np.arange(len(filas))
        for offset,campo,color,nombre in [(-.18,'mape_porcentaje','#247BA0','MAPE: media'),
                                         (.18,'mediana','#E09F3E','Mediana')]:
            valores = [v['metricas']['percentiles_error_porcentual']['p50'] if campo=='mediana' else v['metricas'][campo] for _,v in filas]
            bars = ax.bar(x+offset,valores,width=.36,color=color,label=nombre)
            ax.bar_label(bars,fmt='%.1f',padding=3,fontsize=9)
        ax.set(xticks=x,xticklabels=[f"{etiqueta(k)}{' *' if v['muestra_pequena'] else ''}\nn={v['n_prueba']}, g={v['grupos_prueba']}" for k,v in filas],
               ylabel='Error absoluto (%)',title=titulo)
        ax.margins(y=.23)
        ax.legend(fontsize=9)
    filas_tipo = [(k,v) for k,v in tipos.items() if v['metricas'] is not None]
    x = np.arange(len(filas_tipo))
    for offset,campo,color,nombre in [(-.18,'sesgo_porcentual_medio','#247BA0','Sesgo medio'),
                                     (.18,'sesgo_porcentual_mediano','#E09F3E','Sesgo mediano')]:
        bars = axes[1,0].bar(x+offset,[v['metricas'][campo] for _,v in filas_tipo],width=.36,color=color,label=nombre)
        axes[1,0].bar_label(bars,fmt='%.1f',padding=3)
    axes[1,0].axhline(0,color='#555555',linewidth=1)
    axes[1,0].set(xticks=x,xticklabels=[etiqueta(k) for k,_ in filas_tipo],ylabel='Error con signo (%)',
                  title='Sesgo: positivo sobreestima / negativo subestima')
    axes[1,0].margins(y=.25)
    axes[1,0].legend(fontsize=9)
    filas_cobertura = [(f'{etiqueta(k)}',v) for d in (tipos,rangos) for k,v in d.items() if v['metricas'] is not None]
    bars = axes[1,1].barh(np.arange(len(filas_cobertura)),[v['metricas']['dentro_del_error_porcentual']['hasta_20'] for _,v in filas_cobertura],color='#247BA0')
    axes[1,1].bar_label(bars,fmt='%.1f%%',padding=4)
    axes[1,1].set(yticks=np.arange(len(filas_cobertura)),yticklabels=[k for k,_ in filas_cobertura],xlim=(0,110),
                  xlabel='Porcentaje de propiedades con error ≤20%',title='Cuántas predicciones quedan dentro de ±20%')
    axes[1,1].invert_yaxis()
    fig.suptitle(f"Evaluación por segmentos · mismas {segmentos['n_prueba']} predicciones de prueba",fontsize=15)
    fig.text(.5,.015,'n: publicaciones; g: grupos heurísticos; * menos de 30 grupos. Media y mediana muestran la influencia de errores extremos. No se entrena otro modelo.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,.96))
    fig.savefig(salida/'06_segmentos.png',dpi=170)
    plt.close(fig)

    barrios = sorted([(k,v) for k,v in segmentos.get('por_barrio',{}).items() if v['metricas'] is not None],
                     key=lambda item:item[1]['metricas']['mape_porcentaje'],reverse=True)
    fig,(ax_error,ax_cantidad) = plt.subplots(1,2,figsize=(17,max(6,len(barrios)*.32+2.8)),sharey=True,
                                            gridspec_kw={'width_ratios':[1.3,1]})
    y = np.arange(len(barrios))
    colores = ['#E09F3E' if v['muestra_pequena'] else '#247BA0' for _,v in barrios]
    bars = ax_error.barh(y,[v['metricas']['mape_porcentaje'] for _,v in barrios],color=colores)
    ax_error.bar_label(bars,fmt='%.1f',padding=4,fontsize=9)
    ax_error.scatter([v['metricas']['percentiles_error_porcentual']['p50'] for _,v in barrios],y,c='#222222',marker='D',s=18,zorder=3)
    if global_mape is not None:
        ax_error.axvline(global_mape,color='#777777',linestyle='--',linewidth=1)
    ax_error.set(yticks=y,yticklabels=[f"{etiqueta(k)} (n={v['n_prueba']}, g={v['grupos_prueba']})" for k,v in barrios],
                 xlabel='Error absoluto (%)',title='Barra: MAPE · rombo: mediana · línea: MAPE global')
    ax_error.invert_yaxis()
    ax_error.margins(x=.16)
    for offset,campo,color,nombre in [(-.18,'n_entrenamiento','#999999','Entrenamiento'),(.18,'n_prueba','#247BA0','Prueba')]:
        ax_cantidad.barh(y+offset,[v[campo] for _,v in barrios],height=.36,color=color,label=nombre)
    ax_cantidad.set(xlabel='Publicaciones',title='Cobertura del mismo barrio en ambos conjuntos')
    ax_cantidad.legend(loc='lower right')
    fig.suptitle('Diagnóstico por etiqueta de barrio · no se fusionan alias ni subzonas',fontsize=14,y=.985)
    fig.legend(handles=[Patch(color='#E09F3E',label='Menos de 30 grupos de prueba'),Patch(color='#247BA0',label='30 grupos o más; no certifica estabilidad'),
                        Line2D([0],[0],marker='D',color='#222222',linestyle='',label='Mediana')],loc='upper center',bbox_to_anchor=(.62,.955),ncol=3,fontsize=9)
    omitidos = sum(v['metricas'] is None for v in segmentos.get('por_barrio',{}).values())
    fig.text(.5,.015,f'Se grafican todas las etiquetas con al menos 5 publicaciones de prueba. Otras {omitidos} etiquetas sin métricas están en la tabla completa. Naranja: interpretar con cautela.',ha='center',fontsize=9)
    fig.subplots_adjust(left=.31,right=.97,top=.91,bottom=.07,wspace=.15)
    fig.savefig(salida/'10_segmentos_barrios.png',dpi=150)
    plt.close(fig)

    cruzados = segmentos.get('por_tipo_y_precio',{})
    tipos_cruce = list(cruzados)
    rangos_cruce = [r[0] for r in RANGOS_PRECIO]
    valores = np.array([[cruzados[t][r]['metricas']['mape_porcentaje'] if cruzados[t][r]['metricas'] else np.nan
                         for r in rangos_cruce] for t in tipos_cruce],dtype=float)
    if len(tipos_cruce):
        fig,ax = plt.subplots(figsize=(12,5.4))
        mapa = plt.get_cmap('YlOrRd').copy()
        mapa.set_bad('#dddddd')
        imagen = ax.imshow(np.ma.masked_invalid(valores),cmap=mapa,aspect='auto',vmin=0)
        for i,t in enumerate(tipos_cruce):
            for j,r in enumerate(rangos_cruce):
                v = cruzados[t][r]
                if v['metricas'] is None:
                    texto = f"Sin métrica\nn={v['n_prueba']}"
                else:
                    texto = f"{valores[i,j]:.1f}%{' *' if v['muestra_pequena'] else ''}\nn={v['n_prueba']}, g={v['grupos_prueba']}"
                alto = np.isfinite(valores[i,j]) and valores[i,j]>float(np.nanmax(valores))*.6
                ax.text(j,i,texto,ha='center',va='center',color='white' if alto else '#222222',fontsize=11)
        ax.set(xticks=np.arange(len(rangos_cruce)),xticklabels=[etiqueta(r) for r in rangos_cruce],
               yticks=np.arange(len(tipos_cruce)),yticklabels=[etiqueta(t) for t in tipos_cruce],
               xlabel='Rango de precio observado (USD)',title='MAPE por tipo y precio · menor es mejor')
        fig.colorbar(imagen,ax=ax,label='MAPE (%)')
        fig.text(.5,.02,'* Menos de 30 grupos: muestra pequeña. Gris: menos de 5 publicaciones. El precio observado solo se usa para este diagnóstico.',ha='center',fontsize=9)
        fig.tight_layout(rect=(0,.06,1,.98))
        fig.savefig(salida/'11_segmentos_tipo_precio.png',dpi=170)
        plt.close(fig)

    def tabla(datos):
        lineas = ['| Segmento | Entrena | Prueba | Grupos prueba | MAPE | Mediana | P90 | Sesgo medio | Error ≤20% |',
                  '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
        for nombre,v in datos.items():
            m = v['metricas']
            campos = ([f"{m['mape_porcentaje']:.2f}%",f"{m['percentiles_error_porcentual']['p50']:.2f}%",
                       f"{m['percentiles_error_porcentual']['p90']:.2f}%",f"{m['sesgo_porcentual_medio']:+.2f}%",
                       f"{m['dentro_del_error_porcentual']['hasta_20']:.2f}%"] if m else ['—']*5)
            nombre = etiqueta(nombre)+(' *' if v['muestra_pequena'] and v['n_prueba'] else '')
            lineas.append('| '+ ' | '.join([nombre,str(v['n_entrenamiento']),str(v['n_prueba']),str(v['grupos_prueba']),*campos])+' |')
        return '\n'.join(lineas)
    texto = ['# Evaluación del modelo por segmentos','',
             f"Se analizan las mismas {segmentos['n_prueba']} predicciones de prueba, con {segmentos['n_entrenamiento']} publicaciones de entrenamiento. No se modifica CatBoost.",'',
             'MAPE es error porcentual absoluto medio; mediana y P90 describen su distribución. Sesgo positivo significa sobreestimación y negativo subestimación. Error ≤20% es la proporción de ejemplos que cumplen ese margen, no una probabilidad individual.','',
             '* indica menos de 30 grupos de prueba (o filas si no se dispone de grupos). Se omiten métricas con menos de 5 publicaciones. Estos umbrales son operativos y no prueban estabilidad estadística.','',
             'MAE, RMSE, R², percentiles completos y márgenes de 10/20/30% están en `metricas_modelo.json`, sección `evaluacion_segmentos`.','',
             '## Tipo de propiedad','',tabla(tipos),'','## Precio observado (USD)','',tabla(rangos),'',
             '## Etiqueta de barrio','',tabla(segmentos.get('por_barrio',{})),'',
             'Las etiquetas se conservan como entraron al modelo. Capital Federal no identifica un barrio específico; algunas etiquetas parecen calles. No se unifican nombres o subzonas automáticamente.','',
             '## Tipo y precio','']
    for tipo,datos in cruzados.items():
        texto.extend([f'### {etiqueta(tipo)}','',tabla(datos),''])
    texto.extend(['## Limitaciones','',*['- '+n for n in segmentos['notas']],''])
    (salida/'evaluacion_segmentos.md').write_text('\n'.join(texto),encoding='utf-8')


def graficar(detalle, informe, salida):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    nombres = ['CatBoost vigente', 'CatBoost directo', 'Mediana']
    informes = [informe, informe['referencia_catboost_directo'], {'prueba': informe['referencia_mediana_prueba']}]
    colores = ['#247BA0', '#E09F3E', '#999999']
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, metrica, titulo in zip(axes, ['mae_usd', 'rmse_usd', 'mape_porcentaje'], ['MAE (USD)', 'RMSE (USD)', 'MAPE (%)']):
        bars = ax.bar(nombres, [r['prueba'][metrica] for r in informes], color=colores)
        ax.bar_label(bars, fmt='%.1f', padding=4)
        ax.set_title(titulo + ' · menor es mejor')
        ax.set_ylim(0, max(r['prueba'][metrica] for r in informes) * 1.18)
    fig.suptitle(f'Mismo CSV · {informe["n_entrenamiento"]} entrenamiento / {informe["n_prueba"]} prueba')
    fig.tight_layout(); fig.savefig(salida/'01_metricas_catboost.png', dpi=160); plt.close(fig)

    real, pred = detalle.precio_observado_usd, detalle.precio_predicho_usd
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    axes[0].scatter(real, pred, alpha=.6, s=16)
    limites = [min(real.min(), pred.min()), max(real.max(), pred.max())]
    axes[0].plot(limites, limites, '--', color='gray')
    axes[0].set(xscale='symlog', yscale='symlog', xlabel='Precio observado (USD)', ylabel='CatBoost (USD)', title='Prueba: observado vs. predicho · escala symlog')
    error = (pred - real) / real * 100
    axes[1].scatter(real, error, alpha=.6, s=16)
    axes[1].axhline(0, linestyle='--', color='gray')
    axes[1].set(xscale='log', xlabel='Precio observado (USD) · escala log', ylabel='Error con signo (%)', title='Arriba: sobreestima · abajo: subestima')
    percentiles = ['p50', 'p75', 'p90', 'p95', 'p99']
    x = np.arange(len(percentiles))
    vals = [informe['prueba']['percentiles_error_porcentual'][p] for p in percentiles]
    bars = axes[2].bar(x, vals, color=colores[0])
    axes[2].bar_label(bars, fmt='%.1f', padding=3)
    axes[2].set(xticks=x, xticklabels=percentiles, ylabel='Error absoluto (%)', title='CatBoost: percentiles del error en prueba')
    axes[2].set_ylim(0, max(vals) * 1.2 or 1)
    fig.suptitle('Diagnóstico por grupos · sin selección de parámetros con este test')
    fig.tight_layout(); fig.savefig(salida/'02_errores_catboost.png', dpi=160); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    items = sorted(informe['importancia_variables'].items(), key=lambda p:p[1], reverse=True)[:12]
    axes[0].barh([k for k,v in items], [v for k,v in items], color=colores[0])
    axes[0].invert_yaxis()
    axes[0].set(title='CatBoost: 12 variables de mayor importancia', xlabel='PredictionValuesChange · peso normalizado')
    curva = informe['curva_validacion_interna']
    axes[1].plot(curva['iteraciones'], curva['rmse_entrenamiento'], label='Entrenamiento interno')
    axes[1].plot(curva['iteraciones'], curva['rmse_validacion'], label='Validación interna')
    axes[1].set(title='Modelo diagnóstico: curva de aprendizaje', xlabel='Iteración / árbol', ylabel='RMSE (USD)')
    axes[1].legend()
    fig.suptitle('Importancia describe el modelo, no causalidad · curva interna sin test final')
    fig.tight_layout(); fig.savefig(salida/'03_variables_y_aprendizaje.png', dpi=160); plt.close(fig)


    if 'seleccion_interna' in informe:
        experimentos = informe['seleccion_interna']['resultados']
        fig, ax = plt.subplots(figsize=(14,max(6,len(experimentos)*.34+2)))
        nombres = [r['configuracion']['nombre'] for r in experimentos]
        valores = [r['validacion']['mape_porcentaje']['media'] for r in experimentos]
        desvios = [r['validacion']['mape_porcentaje']['desvio_estandar'] for r in experimentos]
        barras=ax.barh(nombres,valores,xerr=desvios,color=['#247BA0' if n==informe['seleccion_interna']['seleccion'] else '#999999' for n in nombres])
        ax.bar_label(barras,fmt='%.2f',padding=5,fontsize=8)
        ax.set_xlim(0,max(v+d for v,d in zip(valores,desvios))*1.18)
        ax.invert_yaxis();ax.set(xlabel='MAPE interno (%) · barras de error: desviación entre folds',title='Selección sin usar el test · menor es mejor')
        fig.tight_layout();fig.savefig(salida/'05_experimentos.png',dpi=160);plt.close(fig)
    else:
        # No dejar resultados de una selección anterior junto a otra extracción.
        (salida/'05_experimentos.png').unlink(missing_ok=True)
    guardar_analisis_segmentos(informe['evaluacion_segmentos'],salida)


def analizar_errores(detalle, datos, informe, salida):
    """Diagnóstico descriptivo del test. No modifica limpieza, features o modelo."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    salida = Path(salida)
    salida.mkdir(parents=True, exist_ok=True)
    columnas = ['id_propiedad', 'url', 'tipo_operacion', 'barrio_zona',
                'superficie_total_m2', 'superficie_cubierta_m2', 'ambientes',
                'dormitorios', 'banos', 'anios_de_antiguedad', 'estado']
    contexto = datos.reindex(columns=columnas).copy()
    contexto['id_propiedad'] = contexto.id_propiedad.astype(str)
    filas = detalle.merge(contexto, on='id_propiedad', how='left', validate='one_to_one', indicator=True)
    if not filas['_merge'].eq('both').all():
        raise ValueError('Las predicciones no corresponden a los IDs del dataset suministrado.')
    filas = filas.drop(columns='_merge')
    filas['error_con_signo_usd'] = filas.precio_predicho_usd - filas.precio_observado_usd
    filas['direccion_error'] = filas.error_con_signo_usd.map(lambda v: 'sobreestima' if v > 0 else 'subestima' if v < 0 else 'exacto')
    # Orden estable para resolver empates sin inventar diferencias de posición.
    por_usd = filas.sort_values(['error_absoluto_usd', 'id_propiedad'], ascending=[False, True]).head(20)
    por_pct = filas.sort_values(['error_porcentual', 'id_propiedad'], ascending=[False, True]).head(20)
    ids_usd, ids_pct = set(por_usd.id_propiedad), set(por_pct.id_propiedad)
    seleccion = filas[filas.id_propiedad.isin(ids_usd | ids_pct)].copy()
    posiciones_usd = dict(zip(por_usd.id_propiedad, range(1, len(por_usd) + 1)))
    posiciones_pct = dict(zip(por_pct.id_propiedad, range(1, len(por_pct) + 1)))
    seleccion['puesto_top20_usd'] = seleccion.id_propiedad.map(posiciones_usd).astype('Int64')
    seleccion['puesto_top20_porcentaje'] = seleccion.id_propiedad.map(posiciones_pct).astype('Int64')
    seleccion['en_ambos_top20'] = seleccion.id_propiedad.isin(ids_usd & ids_pct)
    seleccion['precio_observado_por_m2_cubierto'] = seleccion.precio_observado_usd / seleccion.superficie_cubierta_m2
    def pistas(fila):
        notas = []
        if pd.isna(fila.dormitorios):
            notas.append('Dormitorios desconocidos; contrastar con el anuncio')
        if fila.ambientes >= 10 and fila.banos <= 1:
            notas.append('10 o más ambientes con un baño o menos; verificar extracción')
        if fila.superficie_total_m2 > 10000:
            notas.append('Superficie total superior a 10000 m²; verificar unidad y formato')
        if str(fila.barrio_zona).casefold() == 'capital federal':
            notas.append('Ubicación genérica; falta barrio específico')
        return '; '.join(notas) or 'Sin contradicción evidente en estas reglas; requiere revisión del anuncio'
    seleccion['pistas_para_revision'] = seleccion.apply(pistas, axis=1)
    seleccion = seleccion.sort_values(['error_absoluto_usd', 'id_propiedad'], ascending=[False, True])
    seleccion.to_csv(salida / 'mayores_errores.csv', index=False)

    total_abs = filas.error_absoluto_usd.sum()
    total_cuadrado = (filas.error_absoluto_usd ** 2).sum()
    aporte_abs = por_usd.error_absoluto_usd.sum() / total_abs * 100 if total_abs else 0
    aporte_cuadrado = (por_usd.error_absoluto_usd ** 2).sum() / total_cuadrado * 100 if total_cuadrado else 0
    def tabla(grupo):
        lineas = ['| ID | Tipo | Observado USD | Predicho USD | Error USD | Error % | Dirección |',
                  '|---|---|---:|---:|---:|---:|---|']
        for _, f in grupo.iterrows():
            lineas.append(f'| {f.id_propiedad} | {f.tipo_propiedad} | {f.precio_observado_usd:,.0f} | {f.precio_predicho_usd:,.0f} | {f.error_absoluto_usd:,.0f} | {f.error_porcentual:.2f} | {f.direccion_error} |')
        return '\n'.join(lineas)
    partes = [
        '# Revisión de los mayores errores de CatBoost',
        'Diagnóstico de la evaluación actual. No se elimina ningún registro por el tamaño de su error. Los ajustes previos se registran en ajustes_datos.csv; las nuevas pistas requieren contrastar los anuncios originales.',
        f'- Registros de prueba: {len(filas)}.\n- Casos distintos entre ambos top 20: {len(seleccion)}.\n- Casos presentes en ambos: {len(ids_usd & ids_pct)}.\n- Los 20 mayores errores en USD concentran el {aporte_abs:.2f}% del error absoluto acumulado y el {aporte_cuadrado:.2f}% del error cuadrático acumulado. Las sumas de contribuciones no son nuevas métricas de precisión.',
        '## Los 20 mayores errores en dólares', tabla(por_usd),
        '## Los 20 mayores errores porcentuales', tabla(por_pct),
        '## Coincidencias entre las dos listas', ', '.join(sorted(ids_usd & ids_pct)) or 'Ninguna.',
        '## Distribución por tipo en las listas',
        f'Top USD: {por_usd.tipo_propiedad.value_counts().to_dict()}. Top porcentual: {por_pct.tipo_propiedad.value_counts().to_dict()}.',
        '## Qué comprobar',
        '1. Comparar precio, moneda, operación, superficies y características con el anuncio original. Un error alto por sí solo no justifica eliminarlo.\n2. Verificar inmuebles de lujo y casos grandes: pueden ser legítimos y estar poco representados.\n3. Revisar faltantes y ubicaciones genéricas.\n4. Investigar republicaciones antes de crear nuevas particiones.\n5. Usar validación interna para comparar log(precio), MAE y parámetros. Este test ya se está usando para diagnóstico; no debe presentarse luego como validación independiente de las mejoras elegidas.',
        'Las URLs y las características para revisar cada caso están en `mayores_errores.csv`. Este diagnóstico no modifica el CSV original ni el modelo.',
    ]
    (salida / 'revision_errores.md').write_text('\n\n'.join(partes) + '\n')
    fig, axes = plt.subplots(1, 2, figsize=(15, 10))
    for ax, grupo, campo, titulo, unidad in [
        (axes[0], por_usd, 'error_absoluto_usd', '20 mayores errores absolutos', 'Error absoluto (USD)'),
        (axes[1], por_pct, 'error_porcentual', '20 mayores errores porcentuales', 'Error absoluto relativo (%)'),
    ]:
        colores = ['#CA4A43' if v > 0 else '#247BA0' for v in grupo.error_con_signo_usd]
        ax.barh(grupo.id_propiedad, grupo[campo], color=colores)
        ax.invert_yaxis()
        ax.set(title=titulo, xlabel=unidad)
        ax.spines[['top', 'right']].set_visible(False)
    fig.suptitle(f'CatBoost · {len(ids_usd & ids_pct)} coincidencias entre listas · rojo: sobreestima / azul: subestima')
    fig.text(.5, .015, f'Top 20 en USD: {aporte_abs:.1f}% del error absoluto y {aporte_cuadrado:.1f}% del error cuadrático acumulados. Señala casos para revisar; no elimina datos.', ha='center', fontsize=9)
    fig.tight_layout(rect=(0, .04, 1, .96))
    fig.savefig(salida / '04_mayores_errores.png', dpi=160)
    plt.close(fig)
    return {'casos_distintos': len(seleccion), 'coincidencias': len(ids_usd & ids_pct),
            'aporte_error_absoluto_porcentaje': float(aporte_abs),
            'aporte_error_cuadratico_porcentaje': float(aporte_cuadrado)}


def guardar_auditoria_datos(datos, registros, grupos, salida):
    """Conserva trazabilidad de exclusiones y correcciones sin editar el CSV."""
    cambios=[]
    for original in datos.to_dict('records'):
        aceptados, resumen=limpiar_registros([original])
        if not aceptados:
            cambios.append({'id_propiedad':original.get('id_propiedad'),'accion':'excluir',
                            'motivo':next(iter(resumen['descartados_por_motivo'])),
                            'url':original.get('url')})
        elif str(aceptados[0].get('tipo_propiedad')) != str(original.get('tipo_propiedad')):
            cambios.append({'id_propiedad':original.get('id_propiedad'),'accion':'corregir_tipo',
                            'motivo':'categoria_del_anuncio_en_url', 'antes':original.get('tipo_propiedad'),
                            'despues':aceptados[0].get('tipo_propiedad'),'url':original.get('url')})
    pd.DataFrame(cambios).to_csv(salida/'ajustes_datos.csv',index=False)
    # Este descarte depende de otras filas; no aparece limpiando una sola fila.
    _, resumen = limpiar_registros(datos.to_dict('records'))
    if resumen['republicaciones_eliminadas']:
        extras = pd.DataFrame([{'id_propiedad':r['id_eliminado'], 'accion':'excluir',
                               'motivo':r['motivo'], 'id_conservado':r['id_conservado'], 'url':r['url_eliminado']}
                              for r in resumen['republicaciones_eliminadas']])
        pd.concat([pd.DataFrame(cambios), extras], ignore_index=True).to_csv(salida/'ajustes_datos.csv',index=False)
    contexto=pd.DataFrame(registros)[['id_propiedad','url','direccion','tipo_propiedad']].copy()
    contexto['grupo_inmueble']=grupos
    contexto['anuncios_en_grupo']=contexto.groupby('grupo_inmueble').id_propiedad.transform('size')
    contexto[contexto.anuncios_en_grupo>1].to_csv(salida/'grupos_republicaciones.csv',index=False)
    revision = leer_revision_republicaciones()
    candidatos = []
    for miembros in detectar_republicaciones(datos.to_dict('records')):
        ids = {str(f['id_propiedad']) for f in miembros}
        for fila in miembros:
            decisiones = [c for c in revision['casos'] if str(fila['id_propiedad']) in c['ids'] and len(ids.intersection(c['ids'])) > 1]
            caso = decisiones[0] if decisiones else {}
            candidatos.append({**{c:fila.get(c) for c in ('id_propiedad','url','direccion','tipo_propiedad','fecha_publicacion','precio_real_usd')},
                               'grupo_candidato':min(ids), 'anuncios_en_grupo':len(ids),
                               'estado_revision':caso.get('decision','pendiente'),
                               'evidencia':caso.get('evidencia','Coincidencia estructurada; identidad de unidad no confirmada.')})
    pd.DataFrame(candidatos, columns=['id_propiedad','url','direccion','tipo_propiedad','fecha_publicacion','precio_real_usd',
                                     'grupo_candidato','anuncios_en_grupo','estado_revision','evidencia']).to_csv(salida/'candidatos_republicaciones.csv',index=False)


def depurar_csv_republicaciones(ruta_csv, salida=None):
    """Eliminación explícita y reversible. Retiene celdas originales de cada fila."""
    ruta_csv = Path(ruta_csv)
    contenido = ruta_csv.read_bytes()
    datos = cargar_dataset_csv(ruta_csv)
    if datos.id_propiedad.isna().any() or datos.id_propiedad.duplicated().any():
        raise ValueError('La depuración física requiere IDs presentes y únicos; revisar esa extracción antes de borrar filas.')
    # La misma validación del entrenamiento evita conservar una copia reciente
    # inválida (por ejemplo precio cero) a costa de una publicación válida.
    _, resumen = limpiar_registros(datos.to_dict('records'))
    eliminadas = resumen['republicaciones_eliminadas']
    if not eliminadas:
        return {'eliminadas':0, 'filas_antes':len(datos), 'filas_despues':len(datos)}
    huella = hashlib.sha256(contenido).hexdigest()
    respaldo = ruta_csv.with_name(f'{ruta_csv.stem}_antes_republicaciones_{huella[:12]}.csv')
    if respaldo.exists():
        if respaldo.read_bytes() != contenido:
            raise ValueError('El respaldo existente no coincide; no se sobrescribe ni se modifica el CSV.')
    else:
        with respaldo.open('xb') as archivo:
            archivo.write(contenido)
    with ruta_csv.open(encoding='utf-8-sig', newline='') as archivo:
        lector = csv.DictReader(archivo)
        columnas, filas = lector.fieldnames, list(lector)
    ids_eliminados = {r['id_eliminado'] for r in eliminadas}
    retenidas = [f for f in filas if f['id_propiedad'].strip() not in ids_eliminados]
    assert len(filas) - len(retenidas) == len(eliminadas)
    informe = {'estado':'preparada', 'archivo':str(ruta_csv.resolve()), 'sha256_antes':huella, 'respaldo':respaldo.name,
               'filas_antes':len(filas), 'filas_despues':len(retenidas), 'eliminadas':len(eliminadas),
               'criterio':'Identidad verificada en fuentes y snapshot vigente; retener fecha más reciente, completitud y menor ID.',
               'detalle':eliminadas}
    salida = Path(salida) if salida is not None else Path(__file__).resolve().parent/'auditoria'/'republicaciones'
    salida.mkdir(parents=True, exist_ok=True)
    temporal = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='', dir=ruta_csv.parent, delete=False) as archivo:
            temporal = Path(archivo.name)
            escritor = csv.DictWriter(archivo, fieldnames=columnas, lineterminator='\n')
            escritor.writeheader()
            escritor.writerows(retenidas)
        informe['sha256_despues'] = hashlib.sha256(temporal.read_bytes()).hexdigest()
        # El registro y el respaldo se guardan antes de reemplazar el dataset.
        (salida/f'depuracion_{huella[:12]}.json').write_text(json.dumps(informe,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        pd.DataFrame(eliminadas).to_csv(salida/f'eliminadas_{huella[:12]}.csv',index=False)
        if ruta_csv.read_bytes() != contenido:
            raise ValueError('El CSV cambió durante la depuración; no se reemplaza.')
        temporal.replace(ruta_csv)
        informe['estado'] = 'aplicada'
        (salida/f'depuracion_{huella[:12]}.json').write_text(json.dumps(informe,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    finally:
        if temporal is not None and temporal.exists():
            temporal.unlink()
    return informe


def candidatos_tratamiento_precio():
    """Experimento acotado: solo cambia la escala del objetivo y la pérdida."""
    candidatos = []
    for transformacion, perdida in [('directo','RMSE'), ('directo','MAE'), ('log','RMSE'), ('log','MAE'), ('log','Huber:delta=0.2')]:
        candidatos.append({'nombre':f'{transformacion}_{perdida}', 'transformacion_objetivo':transformacion,
                           'parametros':{**CONFIGURACION_BASE['parametros'], 'loss_function':perdida}})
        if perdida.startswith('Huber'):
            candidatos[-1]['centrar_log'] = True
    return candidatos


def candidatos_ajuste_catboost(configuracion_actual):
    """24 combinaciones reproducibles y la vigente; no cambia objetivo ni datos.

    Las tres parejas tasa/iteraciones tienen recorrido parecido (~40), para
    probar pasos menores con más árboles. El muestreo se fija antes de la CV.
    """
    from copy import deepcopy
    actual = deepcopy(configuracion_actual)
    actual.setdefault('nombre','configuracion_actual')
    grilla = []
    for profundidad in (4,5,6,7,8):
        for arboles,tasa in ((800,.05),(1400,.03),(2000,.02)):
            for regularizacion in (1,3,10,30):
                configuracion = deepcopy(actual)
                configuracion['parametros'] = {**actual['parametros'],'depth':profundidad,'iterations':arboles,
                                               'learning_rate':tasa,'l2_leaf_reg':regularizacion}
                configuracion['nombre'] = f"ajuste_d{profundidad}_i{arboles}_lr{tasa}_l2{regularizacion}"
                if configuracion['parametros'] != actual['parametros']:
                    grilla.append(configuracion)
    indices = np.random.default_rng(20261028).permutation(len(grilla))[:24]
    return [actual]+[grilla[int(i)] for i in indices]


def elegir_candidato(resultados, *, solo_precio=False):
    """Criterios prefijados sobre CV; nunca recibe observaciones de prueba."""
    referencia = resultados[0]['validacion']
    factor = 1.10 if solo_precio else 1.05
    limite_mae = referencia['mae_usd']['media']*factor
    limite_rmse = None if solo_precio else referencia['rmse_usd']['media']*factor
    for resultado in resultados:
        resultado['cumple_limite_mae'] = resultado['validacion']['mae_usd']['media'] <= limite_mae
        resultado['cumple_limite_rmse'] = limite_rmse is None or resultado['validacion']['rmse_usd']['media'] <= limite_rmse
    elegibles = [r for r in resultados if r['cumple_limite_mae'] and r['cumple_limite_rmse']]
    mejor = min(elegibles,key=lambda r:(r['validacion']['mape_porcentaje']['media'],r['validacion']['mae_usd']['media']))
    return mejor,limite_mae,limite_rmse


def seleccionar_configuracion(X, y, grupos, *, solo_precio=False, configuracion_actual=None):
    """Selecciona solo con CV interna. El test queda fuera de todos los candidatos."""
    import numpy as np
    from sklearn.model_selection import GroupKFold
    from .modelo import dividir_datos, calcular_metricas, CONFIGURACION_BASE
    train, _ = dividir_datos(len(X), grupos, random_state=20261028)
    grupos = np.asarray(grupos)
    candidatos = (candidatos_tratamiento_precio() if solo_precio
                  else candidatos_ajuste_catboost(configuracion_actual or leer_configuracion()))
    resultados = []
    particiones = list(GroupKFold(n_splits=5,shuffle=True,random_state=42).split(X.iloc[train],groups=grupos[train]))
    for numero,configuracion in enumerate(candidatos,1):
        print(f'Validación interna {numero}/{len(candidatos)}: '+configuracion['nombre'],flush=True)
        metricas = []
        for a,b in particiones:
            modelo = crear_modelo(configuracion).fit(X.iloc[train[a]], y.iloc[train[a]])
            metricas.append(calcular_metricas(y.iloc[train[b]], modelo.predict(X.iloc[train[b]])))
        resumen = {k:{'media':float(np.mean([m[k] for m in metricas])),
                      'desvio_estandar':float(np.std([m[k] for m in metricas],ddof=1))}
                   for k in ['mae_usd','rmse_usd','mape_porcentaje','r2']}
        resultados.append({'configuracion':configuracion,'validacion':resumen,'folds':metricas})
    mejor,limite_mae,limite_rmse = elegir_candidato(resultados,solo_precio=solo_precio)
    criterio = ('Minimizar MAPE medio interno, con MAE interno no más de 10% superior al CatBoost directo RMSE.' if solo_precio
                else 'Minimizar MAPE medio interno manteniendo MAE y RMSE internos como máximo 5% por encima de la configuración anterior. Desempate por MAE.')
    return mejor['configuracion'], {'criterio':criterio,
                                    'experimento':'tratamiento_precio' if solo_precio else 'ajuste_catboost',
                                    'configuracion_referencia':candidatos[0],
                                    'semilla_particion_externa':20261028,'semilla_folds_internos':42,
                                    'semilla_muestreo_grilla':None if solo_precio else 20261028,
                                    'n_candidatos':len(resultados),'resultados':resultados,
                                    'seleccion':mejor['configuracion']['nombre'],
                                    'limite_mae_interno_usd':limite_mae,
                                    'limite_rmse_interno_usd':limite_rmse,
                                    'advertencia':'La CV del candidato elegido se usó para selección; no es estimación independiente.'}


def graficar_tratamiento_precio(precios, informe, salida):
    """Distribución del objetivo y comparación interna en USD y porcentajes."""
    import matplotlib.pyplot as plt
    seleccion = informe['seleccion_interna']
    resultados = seleccion['resultados']
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes[0,0].hist(precios / 1000000, bins=45, color='#247BA0')
    axes[0,0].set(title='Precios publicados: cola hacia valores altos', xlabel='Precio (millones de USD)', ylabel='Propiedades')
    axes[0,1].hist(np.log(precios), bins=45, color='#247BA0')
    axes[0,1].set(title='Mismas propiedades en escala logarítmica', xlabel='log natural del precio en USD', ylabel='Propiedades')
    nombres = [r['configuracion']['nombre'].replace('Huber:delta=0.2','Huber (δ=0,2)') for r in resultados]
    colores = ['#247BA0' if r['configuracion']['nombre'] == seleccion['seleccion'] else '#999999' for r in resultados]
    for ax, metrica, titulo in zip(axes[1], ['mape_porcentaje','mae_usd'], ['MAPE interno (%)','MAE interno (USD)']):
        valores = [r['validacion'][metrica]['media'] for r in resultados]
        desvios = [r['validacion'][metrica]['desvio_estandar'] for r in resultados]
        bars = ax.barh(nombres, valores, xerr=desvios, color=colores)
        ax.invert_yaxis()
        ax.bar_label(bars, fmt='%.2f' if metrica == 'mape_porcentaje' else '%.0f', padding=5)
        ax.set(xlabel=titulo, title='Validación por grupos: menor es mejor')
        ax.set_xlim(0, max(v+d for v,d in zip(valores,desvios))*1.25)
    axes[1,1].axvline(seleccion['limite_mae_interno_usd'], color='#D17A22', linestyle='--', label='Límite de MAE para elegir')
    axes[1,1].legend(loc='lower right', fontsize=8)
    fig.suptitle('Tratamiento del precio: mismos datos, árboles y folds internos', fontsize=14)
    fig.text(.5,.015,'Azul: candidato con menor MAPE interno. No cambia el modelo vigente. Barras de error: desviación entre folds, no intervalo de confianza.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.035,1,.96))
    fig.savefig(salida/'07_tratamiento_precio.png',dpi=160)
    plt.close(fig)


def graficar_ajuste_catboost(informe,salida):
    """Antes/después en la misma prueba; no se utiliza para elegir parámetros."""
    import matplotlib.pyplot as plt
    comparacion = informe['comparacion_ajuste']
    anterior,ajustada = comparacion['prueba_anterior'],comparacion['prueba_ajustada']
    fig,axes = plt.subplots(2,3,figsize=(16,10))
    colores = ['#999999','#247BA0']
    for ax,campo,titulo in zip(axes.flat[:4],['mape_porcentaje','mae_usd','rmse_usd','r2'],
                              ['MAPE (%) · menor es mejor','MAE (USD) · menor es mejor','RMSE (USD) · menor es mejor','R² · mayor es mejor']):
        valores = [anterior[campo],ajustada[campo]]
        barras = ax.bar(['Anterior','Ajustado'],valores,color=colores,width=.6)
        ax.bar_label(barras,fmt='%.3f' if campo=='r2' else ('%.2f' if campo=='mape_porcentaje' else '%.0f'),padding=5)
        ax.set(title=titulo,ylim=(min(0,min(valores)*1.2),max(valores)*1.22 or 1))
        ax.grid(axis='y',alpha=.15)
        ax.set_axisbelow(True)
    percentiles = ['p50','p75','p90','p95','p99']
    x = np.arange(len(percentiles))
    for desplazamiento,metricas,color,nombre in [(-.18,anterior,colores[0],'Anterior'),(.18,ajustada,colores[1],'Ajustado')]:
        axes[1,1].bar(x+desplazamiento,[metricas['percentiles_error_porcentual'][p] for p in percentiles],width=.36,color=color,label=nombre)
    axes[1,1].set(xticks=x,xticklabels=percentiles,ylabel='Error absoluto (%)',title='Percentiles del error · menor es mejor')
    axes[1,1].legend()
    tipos = sorted(informe['prueba_por_tipo'])
    for desplazamiento,metricas,color,nombre in [(-.18,comparacion['prueba_por_tipo_anterior'],colores[0],'Anterior'),
                                                (.18,informe['prueba_por_tipo'],colores[1],'Ajustado')]:
        axes[1,2].bar(np.arange(len(tipos))+desplazamiento,[metricas[t]['metricas']['mape_porcentaje'] for t in tipos],width=.36,color=color,label=nombre)
    axes[1,2].set(xticks=np.arange(len(tipos)),xticklabels=[f"{t}\nn={informe['prueba_por_tipo'][t]['n']}" for t in tipos],
                  ylabel='MAPE (%)',title='Error por tipo de propiedad')
    axes[1,2].legend()
    fig.suptitle(f"Ajuste de CatBoost · mismas {informe['n_prueba']} propiedades de prueba",fontsize=15)
    fig.text(.5,.015,'Datos, variables y tratamiento del precio fijos. Parámetros elegidos con CV interna. Esta prueba ya fue explorada; falta validación futura.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.04,1,.96))
    fig.savefig(Path(salida)/'09_ajuste_catboost.png',dpi=170)
    plt.close(fig)


if __name__ == '__main__':
    main()
