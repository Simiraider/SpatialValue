# CatBoost de SpatialValue

## Estado y alcance

El modelo estima precios publicados de unidades residenciales individuales (casas, departamentos y PH). No estima valores de cierre, edificios en bloque ni el precio de un desarrollo completo. La moneda original del conjunto completo todavía no está certificada.

El dataset de trabajo es `dataset/propiedades.csv`: 3.917 filas después de quitar seis copias verificadas. El original de 3.923 filas se conserva byte por byte en `dataset/propiedades_antes_republicaciones_b7c2fe391ebd.csv`. Las demás exclusiones y correcciones se aplican en memoria. No se modifican el scraper, el backend JavaScript ni Neon.

**Resultado actual después de las cuatro revisiones:** 3.375 registros válidos; 2.701 de entrenamiento y 674 de prueba. Se mantiene CatBoost general con los mismos parámetros. La oferta `zp-60396281` se excluye por ofrecer dos casas linderas. MAPE de prueba común: **21,48%**; MAE USD 135.473; RMSE USD 609.222; R² 0,508. La caída desde el 23,69% histórico proviene de cambiar la población, no de mejores predicciones sobre las mismas viviendas. Las variantes de ubicación, superficies y especialistas se implementaron y evaluaron por separado, pero ninguna mejoró MAPE interno. Detalles en [las cuatro revisiones](auditoria/mejoras_segmentos/RESULTADOS.md).

## Organización

- `modelo.py`: carga, limpieza, preparación de variables, agrupación de posibles republicaciones, CatBoost y evaluación.
- `configuracion_catboost.json`: configuración seleccionada por validación interna, compartida por la API y el evaluador. No contiene credenciales ni pesos entrenados.
- `evaluar_dataset.py`: evalúa y genera informes. `--comparar-precio` aísla el tratamiento del objetivo; `--optimizar` ajusta los árboles manteniendo la escala y la pérdida vigentes.
- `dataset/revision_republicaciones.json`: decisiones documentadas de identidad, fuentes y huellas de los anuncios. La limpieza lo utiliza para excluir copias verificadas si se vuelve a cargar el original.
- `test_modelo.py`: pruebas sin conectarse a Neon.
- `mejoras_segmentos.py`: variables geográficas y de superficies opcionales; estimador de especialistas por tipo con respaldo general. Es experimental; no se activa en la configuración actual porque no mejoró validación.
- `comparar_mejoras.py`: comparación controlada de las cuatro propuestas, selección interna y regeneración del diagnóstico elegido.
- `dataset/barrios_caba.geojson`: límites oficiales locales de GCBA, utilizados sin red durante entrenamiento o inferencia. Fuente y licencia en el nuevo informe.
- `auditoria/evaluacion/`: resultados históricos anteriores a la revisión del caso de dos casas; se conservan durante esta comparación.
- `auditoria/mejoras_segmentos/`: referencia actual, resultados separados, gráficos, predicciones y particiones verificables.

La API entrena la configuración elegida al iniciar o reentrenar. Las predicciones se expresan siempre en USD, aunque internamente el modelo trabaje en logaritmos. El cambio de código no reinicia ni despliega una API remota.

## Plan acordado y avance

| Paso | Trabajo | Estado |
|---|---|---|
| 1 | Revisar mayores errores y contrastar fuentes | Confirmados emprendimiento, ventas en bloque, un departamento mal clasificado y una superficie contradictoria. Tres anuncios prioritarios no pudieron recuperarse y siguen pendientes |
| 2 | Evitar republicaciones entre entrenamiento y prueba | Seis copias verificadas eliminadas con respaldo. Se conserva la agrupación preventiva; hay candidatos pendientes de verificar |
| 3 | Mejorar el tratamiento del precio | Cinco tratamientos comparados con los mismos árboles y folds. Log + MAE tiene una ventaja interna mínima, pero empeora MAPE en prueba frente a log + RMSE. Se conserva la configuración vigente |
| 4 | Comparar profundidad, iteraciones, tasa y regularización | Completado: 25 configuraciones, cinco folds internos. Elegida profundidad 6, 1.400 árboles, tasa 0,03 y L2=1. Mejoran MAE, RMSE y R² de prueba; MAPE empeora ligeramente |
| 5 | Medir por tipo, barrio y rango de precio | Completado: cobertura de entrenamiento/prueba, grupos, errores, sesgo y márgenes de 10/20/30%. Incluye cruce tipo × precio y alertas por pocos ejemplos |
| Revisión posterior | Caso extremo, ubicación, superficies y modelos por tipo | Las cuatro propuestas se implementaron o contrastaron por separado. Se aplica la exclusión por alcance; las nuevas variables y especialistas no se activan porque no mejoraron el MAPE de validación |

Pendiente externo: obtener una muestra futura con precios y características verificadas. El CSV ya fue explorado y se diagnosticaron errores con él; redividirlo por grupos no lo convierte en un dataset externo nuevo.

## Cambios de datos y evidencia

Las fuentes de abajo se consultaron el 28 de octubre de 2026. El contenido recuperado puede tener una fecha de rastreo anterior; no se sustituyeron precios históricos por precios actuales.

| Caso | Evidencia | Tratamiento |
|---|---|---|
| `zp-57591434` | [Anuncio de Paraguay 5442](https://www.zonaprop.com.ar/propiedades/emprendimiento/ememvein-paraguay-5442-1-y-2-ambientes-con-terraza-en-venta-57591434.html): desarrollo con ocho unidades, rangos de superficies y precio inicial | No usar como una vivienda de superficie única. Regla general para rutas `/emprendimiento/` |
| `zp-58786232` y `zp-59958267` | [Primer anuncio](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-edificio-de-4-pisos-venta-en-block-ideal-embajada-58786232.html), [republicación](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-triplex-en-venta-en-belgrano-capital-federal-59958267.html): edificio de cuatro pisos vendido en conjunto | Excluir por alcance, no por precio. Extender la regla a URLs que identifican ventas en bloque |
| `zp-56957710` | [Anuncio](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-casa-en-villa-pueyrredon-5-ambientes-cochera-jardin-56957710.html): ficha con 3.121.000 m² y descripción de lote de 8,70 × 34,53 m | Cuarentena por contradicción de la fuente. No inventar una superficie alternativa |
| `zp-60396281` | [Anuncio](https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-imponente-casa-con-el-mejor-jardin-de-belgrano-r-60396281.html): descripción de dos casas linderas; precio actual a consultar | Excluir por alcance de vivienda individual; no inventar precio ni corregir superficies. Se conserva el CSV |
| `zp-54680701` | [Anuncio](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-encarnacion-ezcurra-y-juana-manso-54680701.html): departamento; CSV lo clasifica como casa | Corregir el tipo utilizando la categoría codificada en la URL del anuncio |
| `zp-55418984` | [Anuncio](https://www.zonaprop.com.ar/propiedades/clasificado/veclphin-departamento-de-2-ambientes-a-la-venta-en-villa-55418984.html): PH aunque el título menciona departamento | Priorizar la categoría del anuncio sobre palabras sueltas del título |

Las categorías `veclapin`, `veclcain` y `veclphin` se interpretan respectivamente como departamento, casa y PH. Es una convención de la fuente contrastada en ejemplos, no una verificación manual de cada inmueble. Cualquier cambio de esa convención requiere revisar la regla.

No se excluyen viviendas por ser caras ni por tener errores altos. Los anuncios `zp-60149321`, `zp-60055156` y `zp-59227659` no pudieron verificarse online; no se inventaron correcciones para ellos. Revisar especialmente posibles ventas mixtas o de más de una unidad.

## Limpieza y agrupación

Además de las reglas anteriores se rechazan precios no positivos/no finitos, superficies ausentes o incompatibles y características incoherentes. Se preservan ceros válidos y faltantes. El precio estimado por la propia IA no es la etiqueta.

La agrupación une direcciones normalizadas del mismo tipo, o coordenadas redondeadas junto con cubierta, ambientes y tipo. No usa el precio ni elimina registros. Una dirección por cuadra puede reunir distintas viviendas y faltantes pueden impedir detectar algunas republicaciones: es una protección conservadora, no una identificación catastral.

### Republicaciones verificadas

La detección de candidatos compara título de la URL, dirección y características estructurales. Esto no autoriza una eliminación: las fuentes de Vilela 2630 describen [primer piso](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-2-ambientes-saavedra-56845646.html) y [sexto piso](https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento-en-venta-2-ambientes-saavedra-59960669.html), aunque el CSV los muestra casi iguales y omite el piso. Se conservan ambas unidades.

Se contrastaron descripciones detalladas de ambas publicaciones para confirmar seis pares: Pareja, José Juan Biedma, Venezuela, Zárraga, Washington y Teodoro Vilardebó. Se retiró una copia de cada par. Cada eliminación tiene ID conservado, fechas, precios, URLs y evidencia en `auditoria/republicaciones/eliminadas_b7c2fe391ebd.csv`; el JSON contiguo registra respaldo y hashes antes/después.

La retención prioriza fecha publicada del CSV, después completitud y menor ID. No elige por precio ni por error del modelo. La fecha del export no certifica la última actualización real. Las huellas por ID incluyen URL, dirección completa, categoría, barrio, coordenadas y estructura: si cambian, la revisión deja de autorizar la eliminación. No se combinan atributos de anuncios diferentes.

Después de depurar quedan 41 grupos de candidatos con 84 anuncios: uno corresponde a las dos unidades distintas de Vilela y 40 siguen pendientes. Algunos avisos no pudieron recuperarse online; se conservan. El tercer aviso de Biedma tampoco pudo verificarse y permanece en el dataset. Esta revisión documental no es una certificación catastral ni detecta todas las posibles republicaciones.

Ambas fuentes de Vilardebó dicen que no hay expensas, mientras el CSV contiene importes contradictorios. La deduplicación no corrige ese atributo de manera implícita: queda como problema de calidad para revisar.

## Protocolo de evaluación y selección

1. Ordenar por ID y limpiar sin usar errores de predicción ni cuantiles de precios.
2. Construir grupos sin etiquetas de precio. Reservar aproximadamente el 20% de los grupos con semilla `20261028`; la proporción de filas puede diferir.
3. Con `--comparar-precio`, comparar cinco tratamientos manteniendo los árboles; con `--optimizar`, evaluar 25 configuraciones sin cambiar el tratamiento del precio. Se usan los mismos cinco folds de grupos SOLO en desarrollo (semilla interna 42). Para precio se minimiza MAPE, admitiendo MAE interno hasta 10% por encima del CatBoost directo RMSE. Para ajustar árboles se minimiza MAPE, admitiendo MAE y RMSE internos hasta 5% por encima de la configuración anterior; desempate por MAE.
4. Elegir la configuración antes de evaluar el test. No elegir por resultados de test, no ajustar iteraciones con él y no emplear early stopping en ese conjunto.
5. Evaluar el modelo seleccionado, CatBoost directo y la configuración anterior sobre el mismo test agrupado. Se incluye una referencia de mediana calculada solo en desarrollo. `--comparar-precio` no reemplaza automáticamente la configuración vigente; informa la candidata y sus resultados por separado. `--optimizar` guarda la configuración elegida con CV para el próximo inicio o reentrenamiento de la API.

La CV del candidato ganador participó en su selección y no es validación independiente. Las métricas históricas del reparto aleatorio previo no son comparables directamente: cambió la población y el reparto. La nueva prueba es una comprobación interna, no una muestra futura nunca explorada.

## Cómo funciona la configuración elegida

CatBoost suma árboles en secuencia para reducir el error de su combinación. Recibe categorías normalizadas y números con NaN, sin One-Hot externo.

`TransformedTargetRegressor` aplica `log(precio)` al entrenar y `exp(predicción)` al predecir. Esto pone el foco en diferencias proporcionales; la salida sigue estando en dólares. No se añade corrección de sesgo para convertir la predicción en una media aritmética condicional. No se garantiza que log mejore todos los indicadores.

Por ejemplo, pasar de USD 100.000 a 120.000 y de USD 1.000.000 a 1.200.000 produce el mismo incremento logarítmico: `log(1,2)`. Así se atenúa la diferencia de escala entre propiedades económicas y caras. No obliga a que los precios sigan una distribución normal ni elimina propiedades caras.

RMSE penaliza fuertemente los errores grandes; MAE penaliza el tamaño absoluto del error. En escala logarítmica esos errores corresponden a diferencias entre razones de precios. Se probó también Huber con delta 0,2: es cuadrática para errores pequeños y lineal para grandes. Este delta se fijó antes de evaluar, no se eligió con el test.

Huber no admite la inicialización `boost_from_average` de CatBoost. Para ese candidato se centra el logaritmo con la media aprendida exclusivamente en el entrenamiento de cada fold: `log(precio) - media_train`. Al predecir se revierte el centrado y se aplica la exponencial. Ni el centrado ni los árboles aprenden del conjunto de validación o prueba.

La configuración actual usa 1.400 árboles, profundidad 6, tasa 0,03 y L2=1. Se mantienen semilla CatBoost 42, cuatro hilos y `log(precio) + RMSE`. `allow_writing_files=False` evita archivos auxiliares en el servicio.

### Resultado del experimento de precio (paso 3, antes del ajuste de árboles)

Historial del paso 3 con 600 árboles, profundidad 6, tasa 0,05 y L2=3. Estas cifras comparan tratamientos del precio antes del ajuste de árboles; los resultados actuales están en el paso 4. Se usaron los mismos cinco folds internos para todos los tratamientos:

| Tratamiento | MAPE medio interno | MAE medio interno (USD) |
|---|---:|---:|
| Precio directo + RMSE | 26,84% | 114.699 |
| Precio directo + MAE | 23,38% | 110.939 |
| Log + RMSE (vigente) | 22,00% | 107.498 |
| Log + MAE (candidata de CV) | 21,87% | 109.040 |
| Log centrado + Huber | 21,92% | 107.106 |

La diferencia de 0,13 puntos entre log + MAE y log + RMSE es pequeña frente a la variación entre folds (aproximadamente 0,9–1 punto de MAPE). No demuestra superioridad estable.

Prueba agrupada de 675 anuncios, con 2.701 en entrenamiento y cero grupos compartidos:

| Modelo | MAPE | MAE (USD) | RMSE (USD) |
|---|---:|---:|---:|
| Precio directo + RMSE | 27,83% | 143.999 | 577.305 |
| Log + RMSE (vigente) | 23,50% | 143.537 | 634.897 |
| Log + MAE (candidata) | 24,20% | 145.792 | 607.972 |

Se conserva log + RMSE. El candidato MAE no mejora MAPE ni MAE de prueba frente al vigente, aunque reduce RMSE. Tampoco el vigente gana todas las métricas frente al precio directo: mejora MAPE, pero tiene mayor RMSE. No se anuncia una mejora general que los resultados no demuestran. La siguiente comprobación debe usar una extracción futura verificada; este test ya fue explorado.

El comando `--comparar-precio` genera `07_tratamiento_precio.png`: arriba muestra los mismos precios antes y después de aplicar logaritmos; abajo compara MAPE y MAE internos. Azul identifica la candidata de CV, que puede diferir del modelo vigente. Las barras de error son desviación entre folds, no intervalos de confianza. Este gráfico no se conserva como resultado actual de una ejecución de ajuste de árboles.

### Ajuste de CatBoost (paso 4)

El tratamiento del precio y las 30 variables permanecen fijos. Se compara la configuración anterior contra 24 combinaciones de una grilla de 60, elegidas con semilla `20261028` antes de entrenar. Cada combinación se mide en los mismos cinco folds internos por grupos; ninguna se elige por su resultado en prueba.

| Parámetro | Qué controla | Valores explorados |
|---|---|---|
| Profundidad (`depth`) | Complejidad e interacciones que puede representar cada árbol; mayor profundidad también facilita sobreajuste | 4, 5, 6, 7 y 8 |
| Árboles (`iterations`) | Cantidad de correcciones sucesivas | 800, 1.400 y 2.000, además de los 600 anteriores |
| Tasa (`learning_rate`) | Cuánto aporta cada corrección | 0,05 con 800 árboles; 0,03 con 1.400; 0,02 con 2.000 |
| Regularización (`l2_leaf_reg`) | Penalización sobre valores de las hojas para moderar ajustes excesivos | 1, 3, 10 y 30 |

Las parejas tasa/árboles permiten probar pasos menores con más correcciones. No se utiliza early stopping con el test. El criterio de selección se fijó antes de entrenar: menor MAPE interno entre candidatos cuyo MAE y RMSE internos no superen en más de un 5% los del modelo anterior. Estos límites son una regla operativa, no intervalos de confianza.

`comparacion_ajuste` en `metricas_modelo.json` conserva ambas configuraciones, sus métricas y CV, además de los segmentos anteriores. `09_ajuste_catboost.png` compara los resultados antes/después sobre las mismas 675 propiedades; también muestra percentiles y errores por tipo. El resultado de la búsqueda no certifica precisión en datos futuros.

#### Configuración elegida y resultado

| Parámetro | Anterior | Ajustado |
|---|---:|---:|
| Profundidad | 6 | 6 |
| Árboles | 600 | 1.400 |
| Tasa | 0,05 | 0,03 |
| L2 | 3 | 1 |

Más árboles permiten realizar más correcciones, y la tasa menor reduce el tamaño de cada corrección. L2=1 penaliza menos los valores de las hojas que L2=3: permite más flexibilidad. La profundidad se mantiene; los árboles más profundos probados no ganaron con el criterio establecido.

La CV usada para elegir parámetros (semilla interna 42) pasó de MAPE 22,00% a 21,55%. El MAE interno pasó de USD 107.498 a 106.392 y el RMSE interno de 287.484 a 288.963; ambos cumplen los límites prefijados. La diferencia entre candidatos es pequeña frente a la dispersión entre folds; no se interpreta como superioridad estadística demostrada.

Prueba de las mismas 675 publicaciones, con 2.701 filas en entrenamiento y cero grupos compartidos:

| Métrica | Anterior | Ajustado | Lectura |
|---|---:|---:|---|
| MAE (USD) | 143.537 | 140.101 | Baja aproximadamente 2,39% |
| RMSE (USD) | 634.897 | 621.560 | Baja aproximadamente 2,10% |
| MAPE | 23,50% | 23,69% | Sube 0,19 puntos porcentuales |
| R² | 0,465 | 0,487 | Sube 0,022 |
| Mediana del error porcentual | 15,85% | 16,13% | Empeora ligeramente |
| Percentil 75 del error porcentual | 29,72% | 29,48% | Mejora |
| Percentil 90 del error porcentual | 47,74% | 46,99% | Mejora |
| Percentil 95 del error porcentual | 60,68% | 59,22% | Mejora |
| Percentil 99 del error porcentual | 104,63% | 103,60% | Mejora |

La CV de evaluación con semilla `20261028`, distinta de los folds de selección pero sobre el mismo conjunto de desarrollo, pasa de MAPE medio 22,15% ± 1,16 a 21,76% ± 1,04. El signo ± es desviación entre folds. No es una validación externa independiente de la búsqueda.

El MAPE por tipo pasa de 30,79% a 31,40% en casas (249 ejemplos), de 19,66% a 19,60% en departamentos (280) y de 18,43% a 18,39% en PH (146). El error porcentual máximo sigue siendo muy grande y empeora de 1.236% a 1.516%; esos casos requieren revisar datos y anuncios, no eliminarlos para mejorar métricas.

Se guarda la configuración elegida por CV. El ajuste logra una mejora moderada en errores en dólares y R², con un pequeño empeoramiento del error porcentual agregado. No mejora todos los indicadores. No se vuelve a buscar otra configuración según este test; la siguiente confirmación necesita datos futuros verificados.

### Interpretación SHAP del modelo vigente

`08_shap.png` explica las predicciones del CatBoost log + RMSE sobre las 675 propiedades de prueba. Se reproduce el entrenamiento con las mismas 2.701 filas y la misma configuración; las predicciones coinciden exactamente con las guardadas. Se utilizan `ShapValues` nativos de CatBoost, sin instalar otra dependencia ni modificar el modelo.

- Panel izquierdo: media del valor absoluto de SHAP; una barra más larga indica mayor influencia media en esta muestra. No es el porcentaje del precio atribuible a una variable.
- Panel derecho: cada punto es una propiedad. A la derecha de cero, el aporte aumenta la salida respecto del valor base del modelo; a la izquierda, la reduce. Rojo significa valor numérico alto y azul bajo dentro de esa variable. Gris corresponde a categorías o faltantes; los barrios no tienen un orden numérico.
- La escala es `log(precio en USD)`. El valor base más la suma de los aportes reconstruye la salida de los árboles; al aplicar la transformación inversa se recupera la predicción en USD. Exponenciar cada aporte por separado no produce una descomposición aditiva en dólares.

Ranking actual de influencia media absoluta: superficie total 0,248; superficie cubierta 0,232; latitud 0,112; barrio 0,078; cochera 0,0634; antigüedad 0,0627. Las superficies grandes suelen aportar hacia arriba, y las pequeñas hacia abajo. En esta muestra, tener cochera o pileta también suele aportar positivamente. Son patrones del modelo, no efectos causales verificados.

Ambientes y dormitorios pueden mostrar aportes menores porque comparten información con las superficies. No implica que carezcan de relación con el precio. La importancia también depende de la calidad y la cobertura de cada dato: SHAP explica lo aprendido, no certifica que los datos sean correctos ni mide precisión. La precisión se consulta en las métricas de prueba.

El error máximo de reconstrucción observado es menor que `1e-13` en la salida logarítmica y menor que `1e-6` USD después de invertirla. El ranking de las 30 variables y estas verificaciones quedan en la sección `shap` de `metricas_modelo.json`.

### Evaluación histórica por segmentos (paso 5)

Se analizan las mismas 675 predicciones guardadas, provenientes de 600 grupos de prueba, sin volver a entrenar ni modificar CatBoost. El MAPE global permanece en 23,69%. La evaluación segmentada sirve para identificar dónde falla ese promedio, no para reducirlo mediante filtros.

Cada segmento muestra publicaciones y grupos en entrenamiento/prueba, MAE, RMSE, MAPE, R², mediana y percentiles del error, sesgo con signo y proporción dentro de errores del 10%, 20% y 30%. También se cruzan tipo y precio para no atribuir a todo un tipo un problema concentrado en un rango.

#### Por tipo de propiedad

| Tipo | Entrena | Prueba | Grupos prueba | MAPE | Mediana del error | Error ≤20% |
|---|---:|---:|---:|---:|---:|---:|
| Casa | 928 | 249 | 202 | 31,40% | 19,85% | 50,20% |
| Departamento | 1.309 | 280 | 262 | 19,60% | 14,26% | 64,29% |
| PH | 464 | 146 | 136 | 18,39% | 13,96% | 66,44% |

Las casas presentan más error que departamentos y PH. El MAPE de casas es bastante mayor que su mediana: hay errores extremos influyendo en el promedio. El sesgo medio de casas es +6,80%, pero el mediano es −2,33%; un promedio positivo no implica que se sobreestimen la mayoría de las casas.

#### Por precio observado

| Rango (USD) | Prueba | Grupos prueba | MAPE | Mediana del error | Error ≤20% |
|---|---:|---:|---:|---:|---:|
| Hasta 100.000 | 87 | 84 | 26,67% | 19,50% | 51,72% |
| Más de 100.000 hasta 250.000 | 277 | 260 | 23,18% | 12,40% | 70,76% |
| Más de 250.000 hasta 500.000 | 191 | 174 | 19,43% | 16,48% | 59,69% |
| Más de 500.000 hasta 1 millón | 80 | 70 | 26,77% | 22,60% | 40,00% |
| Más de 1 millón | 40 | 26 | 34,92% | 36,04% | 37,50% |

El tramo de USD 250.000–500.000 tiene menor MAPE agregado. El tramo de USD 100.000–250.000 tiene mayor proporción de predicciones dentro de ±20%; son criterios diferentes. Las propiedades de más de un millón tienen errores elevados incluso en la mediana, pero solo 26 grupos de prueba: el resultado requiere cautela. Estos rangos usan el precio publicado observado, que se conoce para evaluar el dataset, no para tasar una propiedad nueva.

#### Barrio y cruce por tipo/precio

- Caballito: MAPE 17,61%, 30 publicaciones y 30 grupos; Palermo: 20,24%, 68 publicaciones y 57 grupos; Villa Devoto: 22,33%, 41 publicaciones y 34 grupos.
- Belgrano: MAPE 57,61%, pero mediana 11,89%, con 38 publicaciones y 33 grupos. El caso `zp-60396281` tiene precio observado USD 215.000 y predicción aproximada USD 3.474.064; su error de 1.515,84% aporta 39,89 puntos al MAPE de ese segmento. Se conserva en todas las métricas y se señala para revisar variables y fuente, sin asumir que el precio o la predicción sean correctos.
- La etiqueta genérica Capital Federal tiene 87 publicaciones de prueba (12,89% de la prueba), con MAPE 29,85%. No identifica un barrio específico. Existen alias, subzonas y textos con aspecto de calles; no se fusionan ni corrigen automáticamente durante esta evaluación.
- PH de USD 100.000–250.000: MAPE 14,29%, 93 publicaciones y 86 grupos. Departamentos del mismo rango: 16,23%, 135 publicaciones y 131 grupos.
- Casas de USD 100.000–250.000: MAPE 59,22%, pero mediana 19,40%, con 49 publicaciones y 43 grupos; contiene el mismo caso extremo de Belgrano.
- Solo hay tres casas de hasta USD 100.000, cuatro departamentos de más de un millón y un PH de USD 500.000–1 millón en prueba. No se publican métricas agregadas para esos cruces. PH de más de un millón tiene un ejemplo de entrenamiento y ninguno de prueba: no hay evidencia de precisión para ese segmento.

Hay 88 etiquetas de barrio entre ambos conjuntos: 40 tienen al menos cinco publicaciones de prueba y 27 no tienen ninguna publicación de prueba. Superar 30 grupos no certifica estabilidad; se usa como alerta operativa, no como intervalo de confianza. Un grupo puede aparecer en más de un rango o barrio si sus publicaciones tienen precios o etiquetas diferentes; los conteos de grupos por segmento no siempre suman el total global.

Los gráficos marcan muestras pequeñas y conservan los conteos aunque no haya métricas. Con menos de cinco publicaciones de prueba se deja la métrica ausente, no en cero. Las prioridades que surgen son revisar el caso extremo, mejorar la información de barrio y ampliar la cobertura de segmentos caros y poco representados. Esta etapa no cambia precios, etiquetas, configuración ni predicciones.

Las tablas completas están en `auditoria/evaluacion/evaluacion_segmentos.md`; los números detallados, en `evaluacion_segmentos` de `metricas_modelo.json`.

### Cuatro revisiones posteriores, separadas

1. **Caso extremo:** se verificó que `zp-60396281` ofrece dos casas linderas y no una vivienda individual. Se aplica una exclusión por ID y URL sin modificar el CSV. La publicación no valida el precio de USD 215.000 del export; no se inventa un reemplazo. El precio actual no demuestra cuál fue el histórico.
2. **Ubicación:** se incorporó una copia de los límites oficiales de CABA. Se implementó barrio por GPS, barrio principal, subzona reconocida, discrepancia GPS/texto y marcadores de ubicación imprecisa. Hay 170 filas con la coordenada central genérica, 150 discrepancias y 98 ubicaciones recuperables por GPS sin barrio textual válido. El resultado es una hipótesis geográfica, no una certificación de la dirección real. La transformación funciona igual al entrenar y al predecir, sin consultas de red.
3. **Superficies:** se implementaron nueve variables derivadas de las medidas existentes y sus faltantes. La diferencia total−cubierta no se llama patio o terreno. Se documentaron 37 casas descartadas con cubierta mayor que total; dos fuentes muestran que esto puede representar varias plantas. No se reincorporan automáticamente: el CSV no distingue terreno de total construido y el contrato actual de la API también exige cubierta ≤ total. Resolver ese contrato requiere datos separados del origen; no se modifica el trabajo de backend.
4. **Modelos por tipo:** se entrenaron especialistas para casa/departamento/PH con los mismos parámetros, exclusivamente sobre cada entrenamiento interno. El tipo determina qué especialista se usa; nunca se utiliza el precio objetivo para enrutar. Categorías nuevas o con menos de 100 filas usan un modelo general de respaldo. Este mínimo es operativo, no una garantía de calidad. La implementación también calcula SHAP del modelo que realmente predijo cada fila.

Para aislar los efectos se compararon seis alternativas en cinco folds internos idénticos por grupos (semilla `20261101`), usando solo las 2.701 filas de desarrollo. La prueba mantiene los IDs y grupos históricos, quitando únicamente el registro fuera de alcance. No hay grupos compartidos. Como este registro estaba en prueba, las predicciones de la base revisada coinciden con las históricas para todas las 674 viviendas comunes: se verificó numéricamente.

| Variante | MAPE medio interno | MAPE prueba común |
|---|---:|---:|
| Base revisada | **21,89%** | 21,48% |
| Ubicación | 21,97% | 22,10% |
| Superficies | 21,95% | 21,93% |
| Ubicación + superficies | 22,05% | 21,47% |
| Modelos por tipo | 22,60% | 22,17% |
| Ubicación + superficies + tipo | 22,45% | 22,35% |

La regla, fijada antes de medir prueba, exige mejorar MAPE interno al menos 0,20 puntos y ganar en tres de cinco folds, sin empeorar MAE/RMSE más de 5% ni MAPE por tipo más de 10%. Nadie cumple: se conserva la base. Que ubicación + superficies dé 21,47% de prueba no justifica elegirla después de observar ese conjunto. Las diferencias pequeñas tampoco prueban que las variables sean inútiles; no demostraron mejorar el modelo con este experimento y estos parámetros.

En la prueba actual el MAPE por tipo es casa **25,41%**, departamento **19,60%** y PH **18,39%**. Los nuevos gráficos, fuentes y tablas están en `auditoria/mejoras_segmentos/`. El informe conserva las predicciones históricas mínimas, la decisión de selección previa al test, predicciones OOF por alternativa, particiones y hashes de fuente, mapa, preparación y código. Una nueva extracción futura verificada sigue siendo necesaria para confirmar mejoras.

## Ejecución

Desde la raíz, en un entorno con las dependencias de `src/pages/Apis/requirements.txt`:

Para repetir las cuatro revisiones y la comparación completa, o regenerar solo el diagnóstico elegido:

```sh
PYTHONPATH=src/pages/Apis python -m modelo_ia.comparar_mejoras
PYTHONPATH=src/pages/Apis python -m modelo_ia.comparar_mejoras --evaluar-vigente
```

`--no-activar` permite comparar sin guardar la configuración elegida. La ejecución completada eligió la configuración que ya estaba vigente. `evaluar_dataset` sin opciones, con `--solo-shap` o con `--solo-segmentos` utiliza el nuevo informe cuando existe; comprueba su fuente, configuración, mapa y código. `--solo-segmentos` reutiliza las predicciones y no entrena. Las opciones históricas de búsqueda de precio/árboles siguen siendo procedimientos separados.

```sh
PYTHONPATH=src/pages/Apis python -m unittest modelo_ia.test_modelo -v
PYTHONPATH=src/pages/Apis python -m modelo_ia.evaluar_dataset
PYTHONPATH=src/pages/Apis python -m modelo_ia.evaluar_dataset --comparar-precio
```

Para regenerar solo SHAP sobre la misma evaluación:

```sh
PYTHONPATH=src/pages/Apis python -m modelo_ia.evaluar_dataset --solo-shap
```

Este comando verifica fuente, limpieza, configuración, propiedades de prueba y predicciones guardadas. Conserva los gráficos y resultados de la comparación de precio. Una evaluación completa también genera SHAP automáticamente.

Para regenerar solo segmentos usando las predicciones ya guardadas:

```sh
PYTHONPATH=src/pages/Apis python -m modelo_ia.evaluar_dataset --solo-segmentos
```

Valida que fuente, limpieza, configuración, IDs y precios observados coincidan con la evaluación. No entrena el modelo, no cambia la configuración y conserva las métricas globales, SHAP y la comparación de ajuste. Una evaluación completa también genera este diagnóstico automáticamente.

Para repetir la selección interna y guardar la configuración elegida:

```sh
PYTHONPATH=src/pages/Apis python -m modelo_ia.evaluar_dataset --optimizar
```

Para usar otro archivo se admite `--csv /ruta/propiedades.csv`. La API permite `MODELO_DATASET_CSV` como ruta alternativa y usa la misma configuración y limpieza. El evaluador no importa FastAPI ni modifica la API activa. La API informa 503 si no tiene modelo; no devuelve un precio fijo inventado.

`--depurar-republicaciones` elimina físicamente del CSV indicado solo las copias verificadas, con respaldo y registro previo. Volver a ejecutarlo sin nuevas copias no cambia el archivo ni crea otro respaldo. La limpieza habitual también las excluye en memoria si reaparecen.

## Resultados generados

- `metricas_modelo.json`: parámetros, selección interna, comparación antes/después del ajuste (o vigente/candidata de precio), baseline directo, métricas, cobertura, segmentos, grupos y hashes de fuente/preparación/revisión de republicaciones.
- `predicciones_prueba.csv`: predicciones y errores de test con ID y grupo.
- `ajustes_datos.csv`: exclusiones y cambios de tipo por registro. No modifica el original.
- `grupos_republicaciones.csv`: publicaciones que comparten grupo; son candidatos, no duplicados certificados.
- `candidatos_republicaciones.csv`: coincidencias por título, dirección y estructura, con estado de revisión. No es una lista de eliminación automática.
- `01_metricas_catboost.png`: elegido, CatBoost directo y mediana en el mismo test agrupado.
- `02_errores_catboost.png`: observado/predicho, errores con signo y percentiles.
- `03_variables_y_aprendizaje.png`: importancia y curva interna calculada en USD. La curva usa grupos internos y no selecciona iteraciones.
- `04_mayores_errores.png`, `revision_errores.md`, `mayores_errores.csv`: siguientes casos para revisar; no se excluyen automáticamente.
- `05_experimentos.png`: resultados de selección interna con variación entre folds; se genera con `--optimizar` o `--comparar-precio`.
- `06_segmentos.png`: MAPE/mediana por tipo y precio, sesgo y proporción de predicciones con error ≤20%, indicando publicaciones y grupos.
- `07_tratamiento_precio.png`: distribución del objetivo y comparación interna de los cinco tratamientos; se genera con `--comparar-precio`.
- `08_shap.png`: ranking por media absoluta de SHAP y distribución de aportes individuales, sobre las propiedades de prueba del modelo vigente.
- `09_ajuste_catboost.png`: comparación antes/después del ajuste, con métricas, percentiles de error y resultados por tipo de propiedad.
- `10_segmentos_barrios.png`: error medio y mediano por barrio, cobertura de entrenamiento/prueba y alerta de muestras pequeñas.
- `11_segmentos_tipo_precio.png`: cruce tipo × precio; gris indica métricas ausentes por pocos ejemplos y asterisco, menos de 30 grupos.
- `evaluacion_segmentos.md`: tablas de todos los segmentos, incluidos los que no tienen ejemplos de prueba.

MAE y RMSE se expresan en USD; MAPE, en porcentaje. R² no es porcentaje de aciertos. Los percentiles no son intervalos de confianza individuales. La importancia `PredictionValuesChange` describe el modelo, no causalidad ni porcentaje del precio.

## Fuentes técnicas

- [CatBoost: pérdidas de regresión](https://catboost.ai/docs/en/concepts/loss-functions-regression)
- [CatBoost: inicialización y parámetros de entrenamiento](https://catboost.ai/docs/en/references/training-parameters/common)
- [CatBoost: importancia](https://catboost.ai/docs/en/concepts/fstr)
- [CatBoost: valores SHAP](https://catboost.ai/docs/en/concepts/shap-values)
- [Transformación del objetivo](https://scikit-learn.org/stable/modules/generated/sklearn.compose.TransformedTargetRegressor.html)
- [Separación por grupos](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupShuffleSplit.html)
- [Validación cruzada por grupos](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html)
- [Métricas de regresión](https://scikit-learn.org/stable/modules/model_evaluation.html)
