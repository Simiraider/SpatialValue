"""Mejoras aisladas de ubicación, superficies y modelos por tipo.

No usa precios para transformar variables ni accede a servicios externos.
La misma preparación se ejecuta al entrenar y al predecir en la API.
"""
from functools import lru_cache
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin, clone
from sklearn.utils.validation import check_is_fitted

from .modelo import (normalizar_texto, COLUMNAS_TEXTO, COLUMNAS_NUMERICAS,
                     crear_modelo, catboost_ajustado)

MAPA_BARRIOS = Path(__file__).resolve().parent/'dataset'/'barrios_caba.geojson'
SUBZONAS = {
    'belgrano r':'belgrano', 'belgrano c':'belgrano', 'belgrano chico':'belgrano',
    'palermo chico':'palermo', 'palermo hollywood':'palermo', 'palermo soho':'palermo',
    'caballito norte':'caballito', 'almagro norte':'almagro', 'flores norte':'flores',
    'devoto':'villa devoto', 'paternal':'la paternal', 'pompeya':'nueva pompeya',
    'lomas de nunez':'nunez',
}


@lru_cache(maxsize=1)
def poligonos_barrios():
    datos = json.loads(MAPA_BARRIOS.read_text())
    salida = []
    for f in datos['features']:
        nombre = normalizar_texto(f['properties'].get('BARRIO',f['properties'].get('nombre')))
        geometria = f['geometry']
        partes = geometria['coordinates'] if geometria['type']=='MultiPolygon' else [geometria['coordinates']]
        for parte in partes:
            anillos = [np.asarray(anillo,dtype=float) for anillo in parte]
            exterior = anillos[0]
            salida.append((nombre,exterior.min(axis=0),exterior.max(axis=0),anillos))
    return salida


def _en_anillo(x,y,anillo):
    # Ray casting, con comprobación explícita de bordes. None = límite ambiguo.
    a,b = anillo[:-1],anillo[1:]
    cruz = (x-a[:,0])*(b[:,1]-a[:,1])-(y-a[:,1])*(b[:,0]-a[:,0])
    borde = (np.abs(cruz)<1e-13)&(x>=np.minimum(a[:,0],b[:,0])-1e-11)&(x<=np.maximum(a[:,0],b[:,0])+1e-11)&(y>=np.minimum(a[:,1],b[:,1])-1e-11)&(y<=np.maximum(a[:,1],b[:,1])+1e-11)
    if borde.any():
        return None
    cruza = (a[:,1]>y)!=(b[:,1]>y)
    aa,bb = a[cruza],b[cruza]
    return bool(np.count_nonzero(x<(bb[:,0]-aa[:,0])*(y-aa[:,1])/(bb[:,1]-aa[:,1])+aa[:,0])%2)


@lru_cache(maxsize=50000)
def barrio_por_gps(lat,lon):
    if not np.isfinite([lat,lon]).all() or (round(lat,4),round(lon,4))==(-34.6037,-58.3816):
        return None
    encontrados = set()
    for nombre,minimo,maximo,anillos in poligonos_barrios():
        if not (minimo[0]<=lon<=maximo[0] and minimo[1]<=lat<=maximo[1]):
            continue
        resultados = [_en_anillo(lon,lat,a) for a in anillos]
        if None in resultados:
            return None
        if resultados[0] and not any(resultados[1:]):
            encontrados.add(nombre)
    return next(iter(encontrados)) if len(encontrados)==1 else None


def preparar_mejoras(X, *, ubicacion=False, superficies=False):
    """Variables determinísticas calculables sin etiquetas y sin aprender del test."""
    d = X[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS].copy()
    for c in COLUMNAS_TEXTO:
        d[c] = d[c].map(normalizar_texto)
    if ubicacion:
        oficiales = {p[0] for p in poligonos_barrios()}
        originales = d.barrio_zona.tolist()
        texto = [SUBZONAS.get(b,b) if SUBZONAS.get(b,b) in oficiales else None for b in originales]
        gps,estados,principales = [],[],[]
        for i,(lat,lon) in enumerate(zip(d.latitud,d.longitud)):
            g = barrio_por_gps(float(lat),float(lon))
            t = texto[i]
            gps.append(g or 'no especificada')
            estados.append('coincide' if g and g==t else 'conflicto' if g and t else 'solo gps' if g else 'solo texto' if t else 'sin barrio')
            principales.append(g or t or 'no especificada')
        d['barrio_zona'] = principales
        d['barrio_segun_gps'] = gps
        d['ubicacion_consistencia'] = estados
        # Conserva subzonas reconocidas; evita crear categorías con calles sueltas.
        d['subzona_declarada'] = [b if b in SUBZONAS and SUBZONAS[b]!=b else 'no especificada' for b in originales]
        central = (d.latitud.round(4)==-34.6037)&(d.longitud.round(4)==-58.3816)
        d['gps_central_generico'] = central.astype(float)
        # Coordenadas que no ubican un punto inequívoco en CABA no se usan como exactas.
        d['gps_no_utilizable'] = [float(g=='no especificada') for g in gps]
        d.loc[d.gps_no_utilizable==1,['latitud','longitud']] = np.nan
    if superficies:
        total,cubierta = d.superficie_total_m2,d.superficie_cubierta_m2
        d['proporcion_cubierta_total'] = cubierta/total.where(total>0)
        # No se llama "patio" ni "terreno": las medidas de origen son ambiguas.
        d['diferencia_total_cubierta_m2'] = total-cubierta
        d['cubierta_por_ambiente_m2'] = cubierta/d.ambientes.where(d.ambientes>0)
        d['cubierta_por_dormitorio_m2'] = cubierta/d.dormitorios.where(d.dormitorios>0)
        for c in ('ambientes','dormitorios','banos','anios_de_antiguedad','piso'):
            d[c+'_faltante'] = d[c].isna().astype(float)
    return d.replace([np.inf,-np.inf],np.nan)


class ModeloSegmentos(RegressorMixin,BaseEstimator):
    """CatBoost con variables opcionales y especialistas con respaldo general.

    Los especialistas se eligen por tipo conocido, nunca por precio observado.
    Categoría nueva o con menos de 100 filas: se usa el modelo general.
    """
    def __init__(self,configuracion):
        self.configuracion = configuracion

    def preparar(self,X):
        opciones = self.configuracion['mejoras_segmentos']
        return preparar_mejoras(X,ubicacion=opciones.get('ubicacion',False),superficies=opciones.get('superficies',False))

    def fit(self,X,y):
        self.feature_names_in_ = np.array(X.columns,dtype=object)
        self.n_features_in_ = len(X.columns)
        d = self.preparar(X)
        conf = {k:v for k,v in self.configuracion.items() if k!='mejoras_segmentos'}
        # Crear el estimador base sin recursión; CatBoost recibe TODAS sus categóricas.
        from sklearn.compose import TransformedTargetRegressor
        self.general_ = crear_modelo(conf)
        base = self.general_.regressor if isinstance(self.general_,TransformedTargetRegressor) else self.general_
        base.set_params(cat_features=tuple(d.select_dtypes(include=['object','str','string']).columns))
        self.general_.fit(d,y)
        self.especialistas_ = {}
        if self.configuracion['mejoras_segmentos'].get('por_tipo',False):
            for tipo in sorted(set(d.tipo_propiedad)):
                mask = (d.tipo_propiedad==tipo).to_numpy()
                if mask.sum()>=100:
                    self.especialistas_[tipo] = clone(self.general_).fit(d.loc[mask],np.asarray(y)[mask])
        return self

    def predict(self,X):
        check_is_fitted(self,'general_')
        d = self.preparar(X)
        p = np.asarray(self.general_.predict(d))
        for tipo,m in self.especialistas_.items():
            mask = (d.tipo_propiedad==tipo).to_numpy()
            if mask.any():
                p[mask] = m.predict(d.loc[mask])
        return p

    def aportes_shap(self,X):
        """SHAP y base del estimador que produjo cada predicción (incluido respaldo)."""
        from catboost import Pool
        d = self.preparar(X)
        salida = np.empty((len(d),len(d.columns)+1))
        pendientes = np.ones(len(d),dtype=bool)
        for tipo,m in self.especialistas_.items():
            mask = (d.tipo_propiedad==tipo).to_numpy()
            if mask.any():
                salida[mask] = catboost_ajustado(m).get_feature_importance(Pool(d.loc[mask],cat_features=catboost_ajustado(m).get_cat_feature_indices()),type='ShapValues')
                pendientes[mask] = False
        if pendientes.any():
            base = catboost_ajustado(self.general_)
            salida[pendientes] = base.get_feature_importance(Pool(d.loc[pendientes],cat_features=base.get_cat_feature_indices()),type='ShapValues')
        return d,salida
