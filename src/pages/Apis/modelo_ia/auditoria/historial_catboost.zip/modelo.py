"""Carga del CSV, limpieza, CatBoost y evaluación. Importar no abre conexiones ni entrena."""

import math
import re
import os
from pathlib import Path
import unicodedata
from collections import Counter
from urllib.parse import urlsplit
import json
import hashlib
import pandas as pd
from catboost import CatBoostRegressor
import numpy as np
from sklearn.base import clone
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error, r2_score
from sklearn.model_selection import KFold, train_test_split, GroupShuffleSplit, GroupKFold
from sklearn.compose import TransformedTargetRegressor
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.pipeline import make_pipeline


# Fuente de entrenamiento: copia del CSV provisto por el usuario.

DATASET_CSV = Path(__file__).resolve().parent / "dataset" / "propiedades.csv"
REVISION_REPUBLICACIONES = DATASET_CSV.parent / "revision_republicaciones.json"
COLUMNAS_BOOLEANAS = (
    "cochera", "balcon", "terraza", "patio", "pileta", "parrilla", "ascensor",
    "baulera", "sum", "gym", "lounge", "laundry", "seguridad_24hs", "camara",
)


def cargar_dataset_csv(ruta=None):
    """Carga una copia en memoria. Nunca modifica el CSV ni accede a Neon.

    Ruta explícita > MODELO_DATASET_CSV > copia incluida junto al modelo.
    precio_real_usd es la etiqueta publicada; precio_estimado_ia_usd se ignora.
    """
    ruta = Path(ruta or os.environ.get("MODELO_DATASET_CSV") or DATASET_CSV).expanduser()
    df = pd.read_csv(ruta, encoding="utf-8-sig", dtype=str, keep_default_na=False)
    requeridas = {"id_propiedad", "url", "tipo_operacion", "tipo_propiedad", "barrio_zona",
                  "precio_real_usd", "superficie_total_m2", "superficie_cubierta_m2"}
    faltan = requeridas - set(df.columns)
    if faltan:
        raise ValueError("Faltan columnas requeridas en el CSV: " + ", ".join(sorted(faltan)))
    # Los valores de texto vacíos o NULL del export se conservan como desconocidos.
    for col in df.columns:
        df[col] = df[col].str.strip().map(lambda v: None if v in ("", "NULL", "null", "\\N") else v)
    for col in COLUMNAS_BOOLEANAS:
        if col not in df:
            df[col] = None
            continue
        mapeo = {"true": 1.0, "t": 1.0, "1": 1.0, "false": 0.0, "f": 0.0, "0": 0.0}
        valores = df[col].map(lambda v: v.casefold() if v is not None else None)
        invalidos = valores.notna() & ~valores.isin(mapeo)
        if invalidos.any():
            raise ValueError(f"El CSV contiene {int(invalidos.sum())} booleanos no reconocidos en {col}.")
        df[col] = valores.map(mapeo)
    for col in COLUMNAS_NUMERICAS:
        if col not in COLUMNAS_BOOLEANAS:
            df[col] = pd.to_numeric(df[col], errors="coerce") if col in df else float("nan")
    df["precio_usd"] = pd.to_numeric(df["precio_real_usd"], errors="coerce")
    return df


# Limpieza de registros

def normalizar_texto(valor):
    if valor is None or (isinstance(valor, float) and math.isnan(valor)):
        return "no especificada"
    texto = unicodedata.normalize("NFKD", str(valor))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return " ".join(texto.casefold().split()) or "no especificada"


def numero(valor):
    try:
        resultado = float(valor)
        return resultado if math.isfinite(resultado) else None
    except (TypeError, ValueError, OverflowError):
        return None


def es_venta(registro):
    # Conserva la selección previa: alquiler se rechaza; venta o una URL de
    # venta se aceptan. «compra» no se convierte automáticamente en «venta».
    operacion = normalizar_texto(registro.get("tipo_operacion"))
    ruta = urlsplit(str(registro.get("url") or "")).path.casefold()
    if operacion == "alquiler" or "alquiler" in ruta or "/clasificado/al" in ruta:
        return False
    return operacion == "venta" or "venta" in ruta or "/clasificado/ve" in ruta


def limpiar_registros(registros, *, aplicar_revision_segmentos=True):
    """Devuelve copias válidas e informe con el primer motivo de descarte por fila.

    precio_usd sigue dependiendo del contrato de la fuente: esta función no puede
    certificar que el scraper haya interpretado correctamente la moneda original.
    """
    motivos = Counter()
    ajustes = Counter()
    vistos = set()
    limpios = []
    for original in registros:
        fila = dict(original)
        motivo = None
        precio = numero(fila.get("precio_usd"))
        total = numero(fila.get("superficie_total_m2"))
        cubierta = numero(fila.get("superficie_cubierta_m2"))
        ruta = urlsplit(str(fila.get("url") or "")).path.casefold()
        # El alcance es una unidad residencial, no precios "desde" de conjuntos.
        if "/emprendimiento/" in ruta:
            motivo = "emprendimiento_sin_unidad_individual"
        elif (aplicar_revision_segmentos and str(fila.get('id_propiedad')) == 'zp-60396281'
              and ruta == '/propiedades/clasificado/veclcain-imponente-casa-con-el-mejor-jardin-de-belgrano-r-60396281.html'):
            # Revisión 2026-10-28: la descripción ofrece DOS casas linderas.
            # No se elimina por su error ni se inventa un precio; evidencia en
            # auditoria/mejoras_segmentos/01_caso_extremo.md. CSV intacto.
            motivo = 'dos_casas_linderas_fuera_de_alcance'
        elif str(fila.get("id_propiedad")) in {"zp-58786232", "zp-59958267"} or re.search(r"(?:^|[-/])en-(?:block|bloque)(?:[-./]|$)", ruta):
            motivo = "venta_en_bloque_fuera_de_alcance"
        elif str(fila.get("id_propiedad")) == "zp-56957710":
            motivo = "superficie_contradictoria_verificada"
        elif normalizar_texto(fila.get("fuente_precio")) == "ia":
            motivo = "precio_generado_por_ia"
        elif not es_venta(fila):
            motivo = "operacion_no_confirmada_como_venta"
        elif precio is None or precio <= 0:
            motivo = "precio_invalido"
        elif total is None or cubierta is None or total <= 0 or cubierta <= 0 or cubierta > total:
            motivo = "superficies_invalidas"
        else:
            fila.update(precio_usd=precio, superficie_total_m2=total, superficie_cubierta_m2=cubierta)
            for campo in ("ambientes", "dormitorios", "banos", "anios_de_antiguedad", "expensas_ars", "piso"):
                fila[campo] = numero(fila.get(campo))
            for campo in ("ambientes", "dormitorios", "banos", "anios_de_antiguedad", "expensas_ars"):
                valor = fila[campo]
                if valor is not None and (valor < 0 or (campo == "ambientes" and valor == 0)):
                    motivo = "caracteristicas_invalidas"
            ambientes, dormitorios = fila["ambientes"], fila["dormitorios"]
            if ambientes is not None and dormitorios is not None and dormitorios > ambientes:
                motivo = "dormitorios_mayores_que_ambientes"
            # No imponemos baños <= ambientes: puede ser legítimo. Un baño por
            # cada menos de 1 m² sí constituye una inconsistencia evidente.
            if fila["banos"] is not None and fila["banos"] >= total:
                motivo = "banos_incompatibles_con_superficie"
        identificador = fila.get("id_propiedad")
        if motivo is None and identificador is not None:
            clave = str(identificador).strip()
            if clave and clave in vistos:
                motivo = "id_duplicado"
            elif clave:
                vistos.add(clave)
        if motivo:
            motivos[motivo] += 1
        else:
            # La categoría de la URL pertenece al anuncio; no se busca "casa"
            # en descripciones o avisos relacionados. Convención contrastada.
            for codigo, tipo in (("veclapin", "Departamento"), ("veclcain", "Casa"), ("veclphin", "PH")):
                if f"/clasificado/{codigo}-" in ruta:
                    if normalizar_texto(fila.get("tipo_propiedad")) != normalizar_texto(tipo):
                        ajustes["tipo_corregido_por_categoria_del_anuncio"] += 1
                    fila["tipo_propiedad"] = tipo
                    break
            limpios.append(fila)
    limpios, republicaciones = eliminar_republicaciones(limpios)
    if republicaciones:
        motivos["republicacion_verificada"] += len(republicaciones)
    return limpios, {"entrada": len(registros), "aceptados": len(limpios), "descartados_por_motivo": dict(motivos), "ajustes": dict(ajustes),
                     "republicaciones_eliminadas": republicaciones}


def firma_republicacion(fila):
    """Indicio para revisión, nunca prueba automática de que es la misma unidad.

    El título proviene de la URL. Preserva UF/departamento/piso y no usa precios,
    fechas ni predicciones. Barrios distintos después de la coma no impiden
    revisar la pareja, porque el export contiene discrepancias de ubicación.
    """
    url = urlsplit(str(fila.get("url") or ""))
    if (url.hostname or "").casefold() not in {"www.zonaprop.com.ar", "zonaprop.com.ar"}:
        return None
    anuncio = re.fullmatch(r"/propiedades/clasificado/(veclapin|veclcain|veclphin)-(.+)-([0-9]+)\.html", url.path.casefold())
    direccion_completa = normalizar_texto(fila.get("direccion"))
    direccion = re.sub(r"\bal\b", "", direccion_completa.split(",")[0])
    direccion = " ".join(re.sub(r"[^a-z0-9]+", " ", direccion).split())
    unidades = re.findall(r"\b(uf|unidad(?: funcional)?|piso|dpto|depto|departamento)\s*[:#-]?\s*([a-z0-9]+)\b", direccion_completa)
    campos = ("superficie_total_m2", "superficie_cubierta_m2", "ambientes", "dormitorios", "banos", "piso")
    valores = [numero(fila.get(c)) for c in campos]
    if not anuncio or not re.search(r"\b[1-9][0-9]{1,4}\b", direccion) or not re.search(r"[a-z]{3}", direccion):
        return None
    if any(v is None or v <= 0 for v in valores[:3]):
        return None
    return [anuncio[2], direccion, [list(u) for u in unidades], *valores]


def detectar_republicaciones(registros):
    """Devuelve candidatos de firma idéntica; incluso GPS igual puede ser otra UF."""
    grupos = {}
    for fila in registros:
        firma = firma_republicacion(fila)
        if firma is not None:
            grupos.setdefault(json.dumps(firma, ensure_ascii=False), []).append(fila)
    return [miembros for miembros in grupos.values() if len(miembros) > 1]


def leer_revision_republicaciones():
    return json.loads(REVISION_REPUBLICACIONES.read_text(encoding="utf-8"))


def huella_identidad_republicacion(fila):
    """Snapshot estricto por anuncio: cambios de identidad invalidan la revisión."""
    url = urlsplit(str(fila.get("url") or ""))
    tipo = normalizar_texto(fila.get("tipo_propiedad"))
    for codigo, categoria in (("veclapin", "Departamento"), ("veclcain", "Casa"), ("veclphin", "PH")):
        if f"/clasificado/{codigo}-" in url.path.casefold():
            tipo = normalizar_texto(categoria)
    gps = [numero(v) for v in _extraer_coordenadas(fila)]
    identidad = [str(fila.get("id_propiedad")), (url.hostname or "").casefold(), url.path,
                 normalizar_texto(fila.get("direccion")), tipo,
                 normalizar_texto(fila.get("barrio_zona")), gps, firma_republicacion(fila)]
    return hashlib.sha256(json.dumps(identidad, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def eliminar_republicaciones(registros, revision=None):
    """Sobre registros validados, quita IDs contrastados en los anuncios originales.

    La firma observada debe seguir coincidiendo con la registrada al revisar:
    un cambio de dirección, unidad o metraje requiere una nueva revisión.
    Conserva fecha publicada más reciente, luego mayor completitud y menor ID.
    La fecha del export es un criterio operativo; no certifica última actualización.
    No modifica las filas ni combina campos/precios entre publicaciones.
    """
    if len(registros) < 2:
        return list(registros), []
    revision = leer_revision_republicaciones() if revision is None else revision
    eliminadas = {}
    revisados = set()
    for caso in revision.get("casos", []):
        if caso["decision"] != "mismo_inmueble":
            continue
        if revisados.intersection(caso["ids"]):
            raise ValueError("La revisión contiene grupos confirmados solapados; unificar su identidad antes de eliminar.")
        revisados.update(caso["ids"])
        miembros = [f for f in registros if str(f.get("id_propiedad")) in caso["ids"]
                    and firma_republicacion(f) == caso["firma"]
                    and huella_identidad_republicacion(f) == caso["huellas"].get(str(f.get("id_propiedad")))]
        if len(miembros) < 2:
            continue
        def orden(fila):
            fecha = pd.to_datetime(fila.get("fecha_publicacion"), errors="coerce", utc=True)
            fecha = fecha.date().toordinal() if pd.notna(fecha) else 0
            # Solo características observadas: nunca elegir por precio o error.
            completitud = sum(normalizar_texto(fila.get(c)) != "no especificada"
                              for c in COLUMNAS_TEXTO + COLUMNAS_NUMERICAS)
            return (-fecha, -completitud, str(fila.get("id_propiedad")))
        conservada = min(miembros, key=orden)
        for fila in miembros:
            if fila is conservada:
                continue
            identificador = str(fila["id_propiedad"])
            eliminadas[identificador] = {
                "id_eliminado": identificador, "id_conservado": str(conservada["id_propiedad"]),
                "fecha_eliminado": fila.get("fecha_publicacion"), "fecha_conservado": conservada.get("fecha_publicacion"),
                "url_eliminado": fila.get("url"), "url_conservado": conservada.get("url"),
                "precio_eliminado_usd": numero(fila.get("precio_usd", fila.get("precio_real_usd"))),
                "precio_conservado_usd": numero(conservada.get("precio_usd", conservada.get("precio_real_usd"))),
                "motivo": "republicacion_verificada", "evidencia": caso["evidencia"],
            }
    return [f for f in registros if str(f.get("id_propiedad")) not in eliminadas], list(eliminadas.values())


# Preparación y CatBoost

COLUMNAS_TEXTO = [
    "tipo_propiedad",
    "barrio_zona",
    "estado",
    "orientacion",
    "disposicion",
    "seguridad_tipo",
]


COLUMNAS_NUMERICAS = [
    "ambientes",
    "dormitorios",
    "banos",
    "superficie_total_m2",
    "superficie_cubierta_m2",
    "anios_de_antiguedad",
    "piso",
    "cochera",
    "balcon",
    "terraza",
    "patio",
    "pileta",
    "parrilla",
    "seguridad_24hs",
    "ascensor",
    "expensas_ars",
    "baulera",
    "sum",
    "camara",
    "gym",
    "lounge",
    "laundry",
    "latitud",
    "longitud",
]


def _extraer_coordenadas(row):
    lat, lng = row.get("latitud"), row.get("longitud")
    lat, lng = pd.to_numeric(lat, errors="coerce"), pd.to_numeric(lng, errors="coerce")
    if pd.notna(lat) and pd.notna(lng) and -90 <= lat <= 90 and -180 <= lng <= 180 and (lat, lng) != (0, 0):
        return pd.Series([lat, lng])
    gps = row.get("coordenadas_gps")
    try:
        coords = json.loads(gps) if isinstance(gps, str) else gps
        lat, lng = float(coords["lat"]), float(coords["lng"])
        if -90 <= lat <= 90 and -180 <= lng <= 180 and (lat, lng) != (0, 0):
            return pd.Series([lat, lng])
    except (KeyError, TypeError, ValueError, OverflowError):
        pass
    return pd.Series([float("nan"), float("nan")])


def _preparar_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df[["latitud", "longitud"]] = df.apply(_extraer_coordenadas, axis=1)

    for col in COLUMNAS_TEXTO:
        if col not in df.columns:
            df[col] = "No especificada"
        df[col] = df[col].map(normalizar_texto)

    for col in COLUMNAS_NUMERICAS:
        if col not in df.columns:
            df[col] = float("nan")
        df[col] = pd.to_numeric(df[col], errors="coerce").replace([float("inf"), -float("inf")], float("nan")).astype(float)

    return df


CONFIGURACION_MODELO = Path(__file__).resolve().parent / "configuracion_catboost.json"
CONFIGURACION_BASE = {"transformacion_objetivo": "directo", "parametros": {
    "iterations": 600, "depth": 6, "learning_rate": .05, "loss_function": "RMSE", "l2_leaf_reg": 3}}


def leer_configuracion():
    return json.loads(CONFIGURACION_MODELO.read_text()) if CONFIGURACION_MODELO.exists() else CONFIGURACION_BASE


def crear_modelo(configuracion=None):
    """Objetivo directo o logarítmico; predict siempre devuelve dólares."""
    configuracion = configuracion or leer_configuracion()
    if configuracion.get('mejoras_segmentos'):
        from .mejoras_segmentos import ModeloSegmentos
        return ModeloSegmentos(configuracion)
    parametros = {**CONFIGURACION_BASE["parametros"], **configuracion["parametros"]}
    modelo = CatBoostRegressor(**parametros, cat_features=tuple(COLUMNAS_TEXTO),
                              nan_mode="Min", random_seed=42, thread_count=4,
                              verbose=False, allow_writing_files=False)
    if configuracion["transformacion_objetivo"] == "log":
        if configuracion.get('centrar_log', False):
            # Huber no admite boost_from_average. Centrar con la media del fold
            # evita arrancar a unos 12 puntos logarítmicos del precio típico.
            transformador = make_pipeline(FunctionTransformer(np.log, inverse_func=np.exp, check_inverse=False),
                                           StandardScaler(with_std=False))
            return TransformedTargetRegressor(regressor=modelo, transformer=transformador, check_inverse=False)
        return TransformedTargetRegressor(regressor=modelo, func=np.log, inverse_func=np.exp, check_inverse=False)
    if configuracion["transformacion_objetivo"] != "directo":
        raise ValueError("Transformación del objetivo desconocida")
    return modelo


def catboost_ajustado(modelo):
    return modelo.regressor_ if isinstance(modelo, TransformedTargetRegressor) else modelo


def agrupar_inmuebles(df):
    """Agrupación conservadora sin usar precios: no elimina publicaciones.

    Une dirección aproximada + tipo, o GPS + cubierta + ambientes + tipo.
    Direcciones al mismo bloque pueden agrupar viviendas diferentes: se acepta
    esa precaución para evitar sobreestimar generalización. No prueba identidad.
    """
    padres = list(range(len(df)))
    def raiz(i):
        while padres[i] != i:
            padres[i] = padres[padres[i]]
            i = padres[i]
        return i
    vistos = {}
    for i, fila in enumerate(df.to_dict("records")):
        tipo = normalizar_texto(fila.get("tipo_propiedad"))
        direccion = normalizar_texto(fila.get("direccion")).split(",")[0]
        direccion = re.sub(r"\bal\b", "", direccion)
        direccion = re.sub(r"[^a-z0-9 ]", " ", direccion)
        direccion = " ".join(direccion.split())
        claves = []
        if re.search(r"[1-9][0-9]{1,4}", direccion) and re.search(r"[a-z]{3}", direccion):
            claves.append(("direccion", tipo, direccion))
        lat, lng = _extraer_coordenadas(fila)
        cubierta, ambientes = numero(fila.get("superficie_cubierta_m2")), numero(fila.get("ambientes"))
        if pd.notna(lat) and pd.notna(lng) and (round(lat,4),round(lng,4)) != (-34.6037,-58.3816) and cubierta is not None and ambientes is not None:
            claves.append(("gps",tipo,round(lat,4),round(lng,4),round(cubierta,1),ambientes))
        for clave in claves:
            if clave in vistos:
                padres[raiz(i)] = raiz(vistos[clave])
            else:
                vistos[clave] = i
    # Identificador reproducible basado en el ID mínimo del componente.
    componentes = {}
    for i, fila in enumerate(df.to_dict("records")):
        componentes.setdefault(raiz(i), []).append(str(fila.get("id_propiedad") or i))
    return np.array([min(componentes[raiz(i)]) for i in range(len(df))])


def dividir_datos(n, grupos=None, random_state=20261028):
    indices = np.arange(n)
    if grupos is None:
        return train_test_split(indices, test_size=.2, random_state=random_state)
    return next(GroupShuffleSplit(n_splits=1, test_size=.2, random_state=random_state).split(indices, groups=grupos))


# Evaluación y métricas

def calcular_metricas(reales, predichos):
    reales, predichos = np.asarray(reales, dtype=float), np.asarray(predichos, dtype=float)
    if reales.ndim != 1 or reales.shape != predichos.shape or len(reales) < 2:
        raise ValueError('Se necesitan al menos dos pares de observaciones y predicciones.')
    if not np.isfinite(reales).all() or not np.isfinite(predichos).all() or (reales <= 0).any():
        raise ValueError('Los precios reales deben ser positivos y todos los valores finitos.')
    absoluto = np.abs(reales - predichos)
    relativo = absoluto / reales * 100
    r2 = float(r2_score(reales, predichos)) if np.var(reales) > 0 else None
    return {
        'n': len(reales),
        'mae_usd': float(mean_absolute_error(reales, predichos)),
        'rmse_usd': float(np.sqrt(mean_squared_error(reales, predichos))),
        'mape_porcentaje': float(mean_absolute_percentage_error(reales, predichos) * 100),
        'r2': r2,
        'percentiles_error_absoluto_usd': {f'p{p}': float(np.percentile(absoluto, p)) for p in (50, 75, 90, 95, 99, 100)},
        'percentiles_error_porcentual': {f'p{p}': float(np.percentile(relativo, p)) for p in (50, 75, 90, 95, 99, 100)},
    }


RANGOS_PRECIO = (
    ('hasta_100k',0,100000),('100k_250k',100000,250000),
    ('250k_500k',250000,500000),('500k_1m',500000,1000000),('mas_1m',1000000,float('inf')),
)


def evaluar_segmentos(X,y,predicciones,train,test,*,grupos=None):
    """Diagnóstico de predicciones ya hechas; no entrena ni selecciona modelos.

    Los rangos se definen por el precio observado, solo después de predecir.
    Incluye segmentos sin prueba y no presenta pocas filas como precisión estable.
    """
    y,pred = np.asarray(y,dtype=float),np.asarray(predicciones,dtype=float)
    train,test = np.asarray(train,dtype=int),np.asarray(test,dtype=int)
    if (y.shape != (len(X),) or pred.shape != (len(test),) or not np.isfinite(y).all()
            or (y<=0).any() or not np.isfinite(pred).all()):
        raise ValueError('Etiquetas positivas y predicciones finitas alineadas con las filas de prueba son necesarias.')
    if (len(set(train))!=len(train) or len(set(test))!=len(test) or set(train)&set(test)
            or any(i<0 or i>=len(X) for i in np.r_[train,test])):
        raise ValueError('Entrenamiento y prueba deben contener posiciones únicas, válidas y separadas.')
    if grupos is not None:
        grupos = np.asarray(grupos)
        if len(grupos)!=len(X) or set(grupos[train])&set(grupos[test]):
            raise ValueError('Los grupos deben estar alineados y separados entre entrenamiento y prueba.')
    rangos = np.full(len(X),'',dtype=object)
    for nombre,bajo,alto in RANGOS_PRECIO:
        rangos[(y>bajo)&(y<=alto)] = nombre
    etiquetas = {}
    for campo,dimension in [('tipo_propiedad','por_tipo'),('barrio_zona','por_barrio')]:
        if campo in X:
            etiquetas[dimension] = X[campo].map(normalizar_texto).to_numpy()
    etiquetas['por_precio'] = rangos

    def resumir(mascara):
        mascara_train,mascara_test = mascara[train],mascara[test]
        n_train,n_test = int(mascara_train.sum()),int(mascara_test.sum())
        n_grupos_train = len(set(grupos[train][mascara_train])) if grupos is not None else None
        n_grupos_test = len(set(grupos[test][mascara_test])) if grupos is not None else None
        avisos = []
        if n_train==0:
            avisos.append('Sin ejemplos de este segmento en entrenamiento.')
        if n_test==0:
            avisos.append('Sin ejemplos de prueba; no se evaluó precisión en este segmento.')
        elif n_test<5:
            avisos.append('Menos de cinco publicaciones de prueba: se omiten las métricas agregadas.')
        pocos = (n_grupos_test if n_grupos_test is not None else n_test)<30
        if n_test and pocos:
            avisos.append('Menos de 30 grupos de prueba (o filas si no hay grupos): muestra pequeña.')
        resultado = {'n_entrenamiento':n_train,'n_prueba':n_test,
                     'grupos_entrenamiento':n_grupos_train,'grupos_prueba':n_grupos_test,
                     'porcentaje_de_la_prueba':float(n_test/max(1,len(test))*100),
                     'muestra_pequena':pocos,'advertencias':avisos,'metricas':None}
        if n_test>=5:
            reales,estimados = y[test][mascara_test],pred[mascara_test]
            resultado['metricas'] = calcular_metricas(reales,estimados)
            error = (estimados-reales)/reales*100
            resultado['metricas']['sesgo_porcentual_medio'] = float(error.mean())
            resultado['metricas']['sesgo_porcentual_mediano'] = float(np.median(error))
            resultado['metricas']['dentro_del_error_porcentual'] = {
                f'hasta_{limite}':float(np.mean(np.abs(error)<=limite+1e-12)*100) for limite in (10,20,30)}
        return resultado

    informe = {'n_entrenamiento':len(train),'n_prueba':len(test),
               'minimo_publicaciones_para_metricas':5,'umbral_alerta_grupos_pequenos':30,
               'metricas_globales':calcular_metricas(y[test],pred) if len(test)>=2 else None,
               'notas':['Análisis descriptivo del mismo test: no cambia modelos ni usa segmentos para seleccionar parámetros.',
                        'Cinco y treinta son umbrales operativos; superarlos no certifica estabilidad estadística.',
                        'Precio observado define el rango de diagnóstico; ese precio no se conoce al tasar una vivienda nueva.',
                        'Se conservan las etiquetas de barrio del modelo; no se unifican barrios, alias ni subzonas.',
                        'Un grupo puede aparecer en varios rangos o barrios si sus anuncios tienen precios o etiquetas distintos; no sumar grupos entre segmentos.',
                        'R² en rangos estrechos puede ser negativo y no equivale a porcentaje de aciertos.']}
    for dimension,valores in etiquetas.items():
        nombres = [r[0] for r in RANGOS_PRECIO] if dimension=='por_precio' else sorted(set(valores))
        informe[dimension] = {str(nombre):resumir(valores==nombre) for nombre in nombres}
    for barrio,resultado in informe.get('por_barrio',{}).items():
        if barrio in ('no especificada','capital federal','caba','ciudad autonoma de buenos aires') or barrio.startswith(('entre ','e/ ')):
            resultado['advertencias'].append('Etiqueta geográfica genérica, ausente o con aspecto de dirección; revisar origen.')
    if 'por_tipo' in etiquetas:
        informe['por_tipo_y_precio'] = {
            tipo:{nombre:resumir((etiquetas['por_tipo']==tipo)&(rangos==nombre)) for nombre,_,_ in RANGOS_PRECIO}
            for tipo in sorted(set(etiquetas['por_tipo']))}
    return informe


def evaluar_modelo(modelo, X, y, *, random_state=42, grupos=None):
    """Devuelve el modelo ajustado SOLO en el 80%, informe y predicciones holdout.

    Las cinco particiones de CV usan exclusivamente ese 80%. Cada clon vuelve a
    aprender su procesamiento y árboles exclusivamente con su entrenamiento. El 20% final no participa en CV ni selección.
    No se ajustan hiperparámetros ni se eliminan extremos en función de su precio.
    """
    if len(X) < 20:
        raise ValueError('Evaluación de 5 folds requiere al menos 20 registros; no es un umbral de suficiencia estadística.')
    train, test = dividir_datos(len(X), grupos, random_state)
    y = pd.Series(np.asarray(y, dtype=float))
    X_train, y_train = X.iloc[train], y.iloc[train]
    folds = []
    if grupos is None:
        particiones = KFold(n_splits=5, shuffle=True, random_state=random_state).split(X_train)
    else:
        grupos = np.asarray(grupos)
        if len(set(grupos[train])) < 5:
            raise ValueError("Se necesitan al menos cinco grupos de entrenamiento")
        particiones = GroupKFold(n_splits=5, shuffle=True, random_state=random_state).split(X_train, groups=grupos[train])
    for numero, (a, b) in enumerate(particiones, 1):
        candidato = clone(modelo)
        candidato.fit(X_train.iloc[a], y_train.iloc[a])
        folds.append({'fold': numero, **calcular_metricas(y_train.iloc[b], candidato.predict(X_train.iloc[b]))})
    ajustado = clone(modelo).fit(X_train, y_train)
    pred = ajustado.predict(X.iloc[test])
    baseline = DummyRegressor(strategy='median').fit(np.zeros((len(train), 1)), y_train)
    referencia = baseline.predict(np.zeros((len(test), 1)))
    informe = {
        'metodo': 'holdout por grupos de inmueble; CV GroupKFold de cinco particiones solo en desarrollo' if grupos is not None else 'holdout aleatorio 80/20 y CV KFold',
        'random_state': random_state, 'n_entrenamiento': len(train), 'n_prueba': len(test),
        'prueba': calcular_metricas(y.iloc[test], pred),
        'referencia_mediana_prueba': calcular_metricas(y.iloc[test], referencia),
        'cross_validation': {
            'folds': folds,
            'resumen': {k: {'media': float(np.mean(v)), 'desvio_estandar': float(np.std(v, ddof=1))} for k in ('mae_usd', 'rmse_usd', 'mape_porcentaje', 'r2') if (v := [f[k] for f in folds if f[k] is not None])},
        },
        'limitaciones': [
            'Partición aleatoria: no mide generalización temporal ni geográfica.',
            'Sin agrupación por inmueble: republicaciones podrían compartir información entre particiones.',
            'Precios publicados según la fuente, no ventas cerradas ni moneda verificada.',
            'El desempeño agregado no garantiza precisión en tipos con pocos ejemplos.',
            'Percentiles de errores observados no son intervalos de confianza individuales.',
        ],
    }
    if grupos is not None:
        informe['grupos'] = {'total': len(set(grupos)), 'entrenamiento': len(set(grupos[train])),
                             'prueba': len(set(grupos[test])), 'compartidos': len(set(grupos[train]) & set(grupos[test]))}
        informe['limitaciones'][1] = 'Agrupación heurística por dirección/GPS: no certifica identidad ni detecta todas las republicaciones.'
        informe['limitaciones'].append('Test redividido sobre un CSV previamente explorado; no sustituye validación externa con datos futuros.')
    for campo in ('tipo_propiedad', 'barrio_zona'):
        if campo in X:
            informe[f'cobertura_{campo}'] = {nombre: X.iloc[idx][campo].value_counts().to_dict() for nombre, idx in [('entrenamiento', train), ('prueba', test)]}
    if 'tipo_propiedad' in X:
        tipos = X.iloc[test].tipo_propiedad.to_numpy()
        informe['prueba_por_tipo'] = {}
        for tipo in sorted(set(tipos)):
            mascara = tipos == tipo
            n = int(mascara.sum())
            informe['prueba_por_tipo'][tipo] = {
                'n': n,
                'advertencia': 'Muy pocos ejemplos; no demuestra precisión para este segmento.' if n < 30 else None,
                'metricas': calcular_metricas(y.iloc[test].to_numpy()[mascara], pred[mascara]) if n >= 2 else None,
            }
    informe['prueba_por_rango_precio'] = {}
    valores_test = y.iloc[test].to_numpy()
    for etiqueta, bajo, alto in RANGOS_PRECIO:
        mascara = (valores_test > bajo) & (valores_test <= alto)
        n = int(mascara.sum())
        informe['prueba_por_rango_precio'][etiqueta] = {'n':n, 'metricas':calcular_metricas(valores_test[mascara], pred[mascara]) if n >= 2 else None}
    if 'barrio_zona' in X:
        barrios = X.iloc[test].barrio_zona.to_numpy()
        informe['prueba_por_barrio'] = {}
        for barrio in sorted(set(barrios)):
            mascara = barrios == barrio
            n = int(mascara.sum())
            informe['prueba_por_barrio'][barrio] = {'n':n, 'advertencia':'Muestra pequeña' if n<30 else None,
                                                  'metricas':calcular_metricas(valores_test[mascara],pred[mascara]) if n>=5 else None}
    informe['evaluacion_segmentos'] = evaluar_segmentos(X,y,pred,train,test,grupos=grupos)
    detalle = pd.DataFrame({'indice_fila': test, 'precio_observado_usd': y.iloc[test].to_numpy(), 'precio_predicho_usd': pred})
    detalle['error_absoluto_usd'] = abs(detalle.precio_observado_usd - detalle.precio_predicho_usd)
    detalle['error_porcentual'] = detalle.error_absoluto_usd / detalle.precio_observado_usd * 100
    return ajustado, informe, detalle
