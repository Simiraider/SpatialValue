"""Pruebas de limpieza y evaluación; no se conectan a Neon."""
import unittest
import tempfile
import csv
import json
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.dummy import DummyRegressor
from sklearn.model_selection import train_test_split
from modelo_ia.modelo import (
    limpiar_registros, normalizar_texto, calcular_metricas, evaluar_modelo,
    crear_modelo, _preparar_features, COLUMNAS_TEXTO, COLUMNAS_NUMERICAS,
    cargar_dataset_csv,
    agrupar_inmuebles, dividir_datos, CONFIGURACION_BASE,
    firma_republicacion, detectar_republicaciones, eliminar_republicaciones,
    huella_identidad_republicacion,
    evaluar_segmentos,
)
from sklearn.base import clone
from catboost import CatBoostRegressor
from modelo_ia.evaluar_dataset import depurar_csv_republicaciones, candidatos_tratamiento_precio, seleccionar_configuracion, graficar_shap, candidatos_ajuste_catboost, elegir_candidato


class LimpiezaTest(unittest.TestCase):
    def test_excluye_dos_casas_por_alcance_no_por_precio(self):
        url = 'https://www.zonaprop.com.ar/propiedades/clasificado/veclcain-imponente-casa-con-el-mejor-jardin-de-belgrano-r-60396281.html'
        for precio in (215000,4000000):
            fila = self.registro(id_propiedad='zp-60396281',url=url,precio_usd=precio)
            self.assertEqual(limpiar_registros([fila])[1]['descartados_por_motivo'],{'dos_casas_linderas_fuera_de_alcance':1})
            self.assertEqual(len(limpiar_registros([fila],aplicar_revision_segmentos=False)[0]),1)

    def registro(self, **cambios):
        return dict({"id_propiedad": "1", "url": "https://www.zonaprop.com.ar/departamento-venta.html",
                     "precio_usd": 100000, "superficie_total_m2": 50,
                     "superficie_cubierta_m2": 40, "ambientes": 1,
                     "dormitorios": 0, "banos": 1, "anios_de_antiguedad": 0,
                     "piso": 0}, **cambios)

    def test_conserva_ceros_y_no_modifica_original(self):
        original = self.registro()
        antes = dict(original)
        filas, _ = limpiar_registros([original])
        self.assertEqual(original, antes)
        for campo in ("dormitorios", "anios_de_antiguedad", "piso"):
            self.assertEqual(filas[0][campo], 0)

    def test_rechaza_alquiler_aunque_el_precio_sea_alto(self):
        filas, _ = limpiar_registros([self.registro(url="https://ejemplo.com/alquiler.html", precio_usd=500000)])
        self.assertEqual(filas, [])

    def test_no_adivina_operacion(self):
        self.assertEqual(limpiar_registros([self.registro(url=None)])[0], [])

    def test_excluye_predicciones(self):
        self.assertEqual(limpiar_registros([self.registro(fuente_precio="ia")])[0], [])

    def test_rechaza_precios_y_superficies_invalidas(self):
        for cambio in ({"precio_usd": float("inf")}, {"precio_usd": -1},
                       {"superficie_cubierta_m2": 60}, {"superficie_total_m2": None}):
            with self.subTest(cambio=cambio):
                self.assertEqual(limpiar_registros([self.registro(**cambio)])[0], [])

    def test_rechaza_extraccion_incoherente(self):
        self.assertEqual(limpiar_registros([self.registro(dormitorios=97, banos=97)])[0], [])

    def test_deduplica_ids_e_informa(self):
        filas, informe = limpiar_registros([self.registro(), self.registro()])
        self.assertEqual(len(filas), 1)
        self.assertEqual(informe["descartados_por_motivo"], {"id_duplicado": 1})

    def test_faltante_no_se_convierte_en_cero(self):
        filas, _ = limpiar_registros([self.registro(anios_de_antiguedad=None)])
        self.assertIsNone(filas[0]["anios_de_antiguedad"])

    def test_normaliza_categorias(self):
        self.assertEqual(normalizar_texto("  NÚÑEZ  "), "nunez")
        self.assertEqual(normalizar_texto("Departamento"), normalizar_texto("departamento"))


class EvaluacionTest(unittest.TestCase):
    def test_metricas_con_resultado_conocido(self):
        m = calcular_metricas([100, 200], [110, 180])
        self.assertAlmostEqual(m['mae_usd'], 15)
        self.assertAlmostEqual(m['rmse_usd'], np.sqrt(250))
        self.assertAlmostEqual(m['mape_porcentaje'], 10)
        self.assertAlmostEqual(m['r2'], .9)
        self.assertEqual(m['percentiles_error_absoluto_usd']['p100'], 20)

    def test_rechaza_precios_no_positivos(self):
        with self.assertRaises(ValueError):
            calcular_metricas([0, 10], [1, 10])

    def test_r2_indefinido_se_explica_con_null(self):
        self.assertIsNone(calcular_metricas([10, 10], [11, 12])['r2'])

    def test_holdout_no_influye_en_imputacion_ni_cv(self):
        X = pd.DataFrame({'valor': np.arange(40, dtype=float)})
        y = pd.Series(np.arange(40, dtype=float) + 100)
        train, test = train_test_split(np.arange(40), test_size=.2, random_state=42)
        X.loc[test, 'valor'] = 1e10
        modelo, informe, detalle = evaluar_modelo(make_pipeline(SimpleImputer(strategy='median'), LinearRegression()), X, y)
        self.assertAlmostEqual(modelo.named_steps['simpleimputer'].statistics_[0], np.median(X.iloc[train].valor))
        self.assertEqual(set(detalle.indice_fila), set(test))
        y2 = y.copy(); y2.iloc[test] = 1e12
        _, informe2, _ = evaluar_modelo(make_pipeline(SimpleImputer(strategy='median'), LinearRegression()), X, y2)
        self.assertEqual(informe['cross_validation'], informe2['cross_validation'])
        self.assertEqual(len(informe['cross_validation']['folds']), 5)


class SegmentosTest(unittest.TestCase):
    def test_metricas_sesgo_cobertura_y_entradas_sin_mutar(self):
        X = pd.DataFrame({'tipo_propiedad':['Casa']*11,'barrio_zona':['Palermo']*11})
        y = np.full(11,100000.)
        pred = np.array([110000,90000,120000,80000,100000,130000.])
        antes_X,antes_y,antes_pred = X.copy(deep=True),y.copy(),pred.copy()
        informe = evaluar_segmentos(X,y,pred,np.arange(5),np.arange(5,11),grupos=np.arange(11))
        r = informe['por_tipo']['casa']
        self.assertEqual((r['n_entrenamiento'],r['n_prueba'],r['grupos_prueba']),(5,6,6))
        self.assertAlmostEqual(r['metricas']['mape_porcentaje'],15)
        self.assertAlmostEqual(r['metricas']['percentiles_error_porcentual']['p50'],15)
        self.assertAlmostEqual(r['metricas']['sesgo_porcentual_medio'],5)
        self.assertAlmostEqual(r['metricas']['dentro_del_error_porcentual']['hasta_10'],50)
        self.assertAlmostEqual(r['metricas']['dentro_del_error_porcentual']['hasta_20'],100*5/6)
        self.assertAlmostEqual(r['metricas']['dentro_del_error_porcentual']['hasta_30'],100)
        self.assertIsNone(r['metricas']['r2'])
        pd.testing.assert_frame_equal(X,antes_X)
        np.testing.assert_array_equal(y,antes_y)
        np.testing.assert_array_equal(pred,antes_pred)

    def test_limites_de_precios_y_segmentos_sin_cobertura(self):
        X = pd.DataFrame({'tipo_propiedad':['PH']*5+['Casa']*7,
                          'barrio_zona':['Solo entrenamiento']*5+['Solo prueba']*7})
        y = np.array([90000]*5+[1,100000,100000.01,250000,500000,1000000,1000000.01])
        informe = evaluar_segmentos(X,y,y[5:],np.arange(5),np.arange(5,12),grupos=np.arange(12))
        self.assertEqual([v['n_prueba'] for v in informe['por_precio'].values()],[2,2,1,1,1])
        self.assertEqual(sum(v['n_prueba'] for v in informe['por_precio'].values()),7)
        self.assertIsNone(informe['por_tipo']['ph']['metricas'])
        self.assertEqual(informe['por_tipo']['ph']['n_prueba'],0)
        self.assertEqual(informe['por_tipo']['casa']['n_entrenamiento'],0)
        self.assertTrue(any('Sin ejemplos' in a for a in informe['por_tipo']['casa']['advertencias']))
        self.assertIsNone(informe['por_precio']['250k_500k']['metricas'])
        self.assertEqual(informe['por_barrio']['solo entrenamiento']['n_prueba'],0)
        self.assertEqual(informe['por_barrio']['solo prueba']['n_entrenamiento'],0)
        self.assertEqual(informe['por_tipo_y_precio']['casa']['hasta_100k']['n_prueba'],2)

    def test_muchas_publicaciones_no_son_muchos_grupos_y_rechaza_fuga(self):
        X = pd.DataFrame({'tipo_propiedad':['Casa']*35})
        y = 100000+np.arange(35)*1000
        grupos = np.r_[np.arange(5),np.repeat([5,6],15)]
        r = evaluar_segmentos(X,y,y[5:],np.arange(5),np.arange(5,35),grupos=grupos)['por_tipo']['casa']
        self.assertEqual(r['n_prueba'],30)
        self.assertEqual(r['grupos_prueba'],2)
        self.assertTrue(r['muestra_pequena'])
        grupos[-1] = 0
        with self.assertRaisesRegex(ValueError,'grupos'):
            evaluar_segmentos(X,y,y[5:],np.arange(5),np.arange(5,35),grupos=grupos)

    def test_rechaza_desalineacion_y_particiones_solapadas(self):
        X = pd.DataFrame({'tipo_propiedad':['Casa']*10})
        y = np.arange(10)+100000
        with self.assertRaises(ValueError):
            evaluar_segmentos(X,y,y[4:],np.arange(5),np.arange(5,10))
        with self.assertRaises(ValueError):
            evaluar_segmentos(X,y,y[4:],np.arange(5),np.arange(4,10))


class DatasetCSVTest(unittest.TestCase):
    def test_booleanos_precio_observado_y_ceros(self):
        with tempfile.TemporaryDirectory() as carpeta:
            ruta = Path(carpeta) / 'propiedades.csv'
            ruta.write_text('id_propiedad,url,tipo_operacion,tipo_propiedad,barrio_zona,precio_real_usd,precio_estimado_ia_usd,superficie_total_m2,superficie_cubierta_m2,cochera,balcon,anios_de_antiguedad\n1,https://ejemplo.com/venta,venta,Casa,Palermo,200000,999999,80,70,false,true,0\n', encoding='utf-8')
            antes = ruta.read_bytes()
            df = cargar_dataset_csv(ruta)
            self.assertEqual(df.iloc[0].cochera, 0)
            self.assertEqual(df.iloc[0].balcon, 1)
            self.assertEqual(df.iloc[0].precio_usd, 200000)
            self.assertEqual(df.iloc[0].anios_de_antiguedad, 0)
            self.assertTrue(pd.isna(df.iloc[0].piso))
            self.assertEqual(ruta.read_bytes(), antes)

    def test_rechaza_csv_sin_columnas_requeridas(self):
        with tempfile.TemporaryDirectory() as carpeta:
            ruta = Path(carpeta) / 'incompleto.csv'
            ruta.write_text('precio\n100\n')
            with self.assertRaisesRegex(ValueError, 'columnas requeridas'):
                cargar_dataset_csv(ruta)


class CatBoostTest(unittest.TestCase):
    def test_shap_reconstruye_log_y_dolares_con_categorias_y_faltantes(self):
        X = _preparar_features(pd.DataFrame([
            {'tipo_propiedad':'Casa' if i%2 else 'PH','barrio_zona':'Palermo',
             'superficie_total_m2':50+i,'superficie_cubierta_m2':40+i,
             'anios_de_antiguedad':None if i%3 else 0} for i in range(25)]))[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]
        consulta = X.iloc[-4:].copy()
        consulta['barrio_zona'] = 'categoria nueva'
        for centrado in (False,True):
            with self.subTest(centrado=centrado), tempfile.TemporaryDirectory() as carpeta:
                config = {'transformacion_objetivo':'log','centrar_log':centrado,
                          'parametros':{'iterations':10,'depth':3,'loss_function':'RMSE'}}
                modelo = crear_modelo(config).fit(X,np.arange(25)*1000+100000)
                antes = modelo.predict(consulta)
                resumen = graficar_shap(modelo,consulta,carpeta,config)
                self.assertLess(resumen['error_maximo_aditividad'],1e-9)
                self.assertLess(resumen['error_maximo_reconstruccion_usd'],1e-6)
                self.assertEqual(resumen['n_propiedades_prueba'],4)
                self.assertEqual(set(resumen['importancia_media_absoluta']),set(X.columns))
                self.assertTrue(all(v>=0 for v in resumen['importancia_media_absoluta'].values()))
                np.testing.assert_array_equal(modelo.predict(consulta),antes)
                self.assertTrue((Path(carpeta)/'08_shap.png').exists())

    def test_catboost_categorias_nuevas_faltantes_y_clone(self):
        filas = [{'tipo_propiedad': 'Casa', 'barrio_zona': 'Palermo',
                  'superficie_total_m2': 50 + i, 'superficie_cubierta_m2': 40 + i,
                  'anios_de_antiguedad': None if i % 2 else 0,
                  'cochera': bool(i % 2)} for i in range(25)]
        X = _preparar_features(pd.DataFrame(filas))[COLUMNAS_TEXTO + COLUMNAS_NUMERICAS]
        original = crear_modelo(CONFIGURACION_BASE)
        self.assertIsInstance(original, CatBoostRegressor)
        self.assertFalse(original.get_params()['allow_writing_files'])
        modelo = clone(original).set_params(iterations=10).fit(X, np.arange(25) * 1000 + 100000)
        nuevo = X.iloc[:1].copy()
        nuevo['barrio_zona'] = 'categoria nunca vista'
        self.assertTrue(np.isfinite(modelo.predict(nuevo)).all())
        self.assertEqual(modelo.get_cat_feature_indices(), list(range(len(COLUMNAS_TEXTO))))
        self.assertEqual(X.iloc[0].anios_de_antiguedad, 0)
        self.assertTrue(pd.isna(X.iloc[1].anios_de_antiguedad))

    def test_logaritmo_devuelve_dolares(self):
        config = {'transformacion_objetivo':'log','parametros':{'iterations':10,'depth':3}}
        X = _preparar_features(pd.DataFrame([
            {'tipo_propiedad':'Casa','superficie_total_m2':50+i,'superficie_cubierta_m2':40+i}
            for i in range(25)]))[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]
        modelo = clone(crear_modelo(config)).fit(X, np.arange(25)*1000+100000)
        np.testing.assert_allclose(modelo.predict(X),np.exp(modelo.regressor_.predict(X)))
        self.assertTrue((modelo.predict(X)>1000).all())

    def test_huber_log_admite_precio_extremo_y_sigue_prediciendo_usd(self):
        configuracion = next(c for c in candidatos_tratamiento_precio() if 'Huber' in c['parametros']['loss_function'])
        configuracion = {**configuracion, 'parametros': {**configuracion['parametros'], 'iterations': 15, 'depth': 3}}
        X = _preparar_features(pd.DataFrame([
            {'tipo_propiedad':'Casa', 'superficie_total_m2':50+i, 'superficie_cubierta_m2':40+i}
            for i in range(30)]))[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]
        y = np.r_[100000+np.arange(29)*1000, 15000000]
        modelo = crear_modelo(configuracion).fit(X, y)
        pred = modelo.predict(X)
        self.assertTrue(np.isfinite(pred).all())
        self.assertTrue((pred>1000).all())
        inversa = modelo.transformer_.inverse_transform(modelo.regressor_.predict(X).reshape(-1,1)).ravel()
        np.testing.assert_allclose(pred, inversa)
        self.assertAlmostEqual(modelo.transformer_.named_steps['standardscaler'].mean_[0], np.log(y).mean())


class IntegridadDatosTest(unittest.TestCase):
    def test_no_entrena_emprendimientos_ni_bloques(self):
        base = LimpiezaTest().registro()
        for url in ('https://ejemplo.com/propiedades/emprendimiento/venta.html',
                    'https://ejemplo.com/venta-en-block.html'):
            filas, informe = limpiar_registros([{**base,'url':url}])
            self.assertEqual(filas,[])
        filas,_=limpiar_registros([{**base,'precio_usd':5000000}])
        self.assertEqual(len(filas),1,'No excluir por ser caro')

    def test_categoria_anuncio_corrige_copia(self):
        base=LimpiezaTest().registro(tipo_propiedad='Casa',url='https://www.zonaprop.com.ar/propiedades/clasificado/veclapin-departamento.html')
        filas,informe=limpiar_registros([base])
        self.assertEqual(filas[0]['tipo_propiedad'],'Departamento')
        self.assertEqual(base['tipo_propiedad'],'Casa')

    def test_republicaciones_juntas_sin_usar_precio(self):
        df=pd.DataFrame([
            {'id_propiedad':'a','tipo_propiedad':'Casa','direccion':'Superí al 1600','precio_usd':100},
            {'id_propiedad':'b','tipo_propiedad':'Casa','direccion':'Superi 1600','precio_usd':999999},
        ]+[{'id_propiedad':str(i),'tipo_propiedad':'Casa','direccion':f'Otra {i*100}'} for i in range(1,20)])
        grupos=agrupar_inmuebles(df)
        self.assertEqual(grupos[0],grupos[1])
        train,test=dividir_datos(len(df),grupos)
        self.assertFalse(set(grupos[train]) & set(grupos[test]))

    def test_evaluacion_respeta_grupos(self):
        grupos=np.repeat(np.arange(20),2)
        X=pd.DataFrame({'valor':np.arange(40,dtype=float)})
        y=pd.Series(100000+np.arange(40)*1000)
        _,informe,detalle=evaluar_modelo(make_pipeline(SimpleImputer(),LinearRegression()),X,y,grupos=grupos,random_state=20261028)
        self.assertEqual(informe['grupos']['compartidos'],0)
        train,test=dividir_datos(len(X),grupos,20261028)
        self.assertEqual(set(detalle.indice_fila),set(test))


class RepublicacionesTest(unittest.TestCase):
    def registro(self, identificador, **cambios):
        """Dos avisos pueden compartir estos datos y pertenecer a distintas UF."""
        return dict({
            'id_propiedad': identificador,
            'url': ('https://www.zonaprop.com.ar/propiedades/clasificado/'
                    f'veclapin-departamento-venta-vilela-{identificador[3:]}.html'),
            'direccion': 'Vilela 2630, Saavedra',
            'barrio_zona': 'Saavedra',
            'tipo_propiedad': 'Departamento',
            'coordenadas_gps': '{"lat":-34.5501,"lng":-58.4752}',
            'superficie_total_m2': 50,
            'superficie_cubierta_m2': 43,
            'ambientes': 2,
            'dormitorios': 1,
            'banos': 1,
            'piso': None,
            'fecha_publicacion': '2026-10-01',
            'precio_usd': 146000,
        }, **cambios)

    def caso(self, *filas):
        return {
            'decision': 'mismo_inmueble',
            'ids': [f['id_propiedad'] for f in filas],
            'firma': firma_republicacion(filas[0]),
            'huellas': {f['id_propiedad']: huella_identidad_republicacion(f) for f in filas},
            'evidencia': 'Fixture: identidad contrastada mediante descripción de la unidad.',
        }

    def test_candidato_vilela_sin_revision_no_elimina_unidades(self):
        # Regresión del caso real: el CSV omitía que eran pisos distintos.
        filas = [self.registro('zp-100'), self.registro('zp-200')]
        candidatos = detectar_republicaciones(filas)
        self.assertEqual(len(candidatos), 1)
        conservadas, eliminadas = eliminar_republicaciones(filas, {'casos': []})
        self.assertEqual(conservadas, filas)
        self.assertEqual(eliminadas, [])

    def test_confirmacion_conserva_fecha_reciente_sin_elegir_por_id_o_precio(self):
        for id_reciente, id_anterior in [('zp-100', 'zp-900'), ('zp-900', 'zp-100')]:
            with self.subTest(id_reciente=id_reciente):
                reciente = self.registro(id_reciente, fecha_publicacion='2026-10-20', precio_usd=140000)
                anterior = self.registro(id_anterior, fecha_publicacion='2026-09-01', precio_usd=190000)
                revision = {'casos': [self.caso(reciente, anterior)]}
                for filas in ([anterior, reciente], [reciente, anterior]):
                    conservadas, eliminadas = eliminar_republicaciones(filas, revision)
                    self.assertEqual(conservadas, [reciente])
                    self.assertEqual(eliminadas[0]['id_eliminado'], id_anterior)
                    self.assertEqual(eliminadas[0]['id_conservado'], id_reciente)
                    self.assertEqual(eliminadas[0]['precio_conservado_usd'], 140000)
                    self.assertEqual(eliminadas[0]['precio_eliminado_usd'], 190000)

    def test_misma_fecha_prioriza_completitud_y_luego_id_estable(self):
        incompleta = self.registro('zp-100', estado=None)
        completa = self.registro('zp-900', estado='Usado')
        revision = {'casos': [self.caso(incompleta, completa)]}
        for filas in ([incompleta, completa], [completa, incompleta]):
            self.assertEqual(eliminar_republicaciones(filas, revision)[0], [completa])
        igual_completitud = self.registro('zp-100', estado='Usado')
        revision = {'casos': [self.caso(igual_completitud, completa)]}
        for filas in ([igual_completitud, completa], [completa, igual_completitud]):
            self.assertEqual(eliminar_republicaciones(filas, revision)[0], [igual_completitud])

    def test_cambio_unidad_tras_coma_o_gps_invalida_revision(self):
        original = [self.registro('zp-100', direccion='Vilela 2630, 6 B'),
                    self.registro('zp-200', direccion='Vilela 2630, 6 B')]
        revision = {'casos': [self.caso(*original)]}
        for cambio in ({'direccion': 'Vilela 2630, 8 B'},
                       {'coordenadas_gps': '{"lat":-34.5701,"lng":-58.4752}'}):
            with self.subTest(cambio=cambio):
                modificadas = deepcopy(original)
                modificadas[1].update(cambio)
                self.assertEqual(firma_republicacion(modificadas[1]), firma_republicacion(original[1]))
                self.assertNotEqual(huella_identidad_republicacion(modificadas[1]),
                                    huella_identidad_republicacion(original[1]))
                conservadas, eliminadas = eliminar_republicaciones(modificadas, revision)
                self.assertEqual(conservadas, modificadas)
                self.assertEqual(eliminadas, [])

    def test_rechaza_catalogo_con_grupos_confirmados_solapados(self):
        a, b, c = [self.registro(f'zp-{i}') for i in (100, 200, 300)]
        revision = {'casos': [self.caso(a, b), self.caso(b, c)]}
        with self.assertRaisesRegex(ValueError, 'solapados'):
            eliminar_republicaciones([a, b, c], revision)

    def test_fecha_2500_y_fechas_ausentes_no_producen_overflow(self):
        futura = self.registro('zp-100', fecha_publicacion='2500-01-01')
        for fecha in (None, float('nan'), 'fecha inválida', '2026-10-01'):
            with self.subTest(fecha=fecha):
                otra = self.registro('zp-200', fecha_publicacion=fecha)
                revision = {'casos': [self.caso(futura, otra)]}
                conservadas, eliminadas = eliminar_republicaciones([otra, futura], revision)
                self.assertEqual(conservadas, [futura])
                self.assertEqual(len(eliminadas), 1)

    def test_eliminacion_es_idempotente_y_no_modifica_entradas_ni_revision(self):
        filas = [self.registro('zp-100'), self.registro('zp-200')]
        revision = {'casos': [self.caso(*filas)]}
        antes_filas, antes_revision = deepcopy(filas), deepcopy(revision)
        conservadas, eliminadas = eliminar_republicaciones(filas, revision)
        repetidas, nuevas_eliminadas = eliminar_republicaciones(conservadas, revision)
        self.assertEqual(len(eliminadas), 1)
        self.assertEqual(repetidas, conservadas)
        self.assertEqual(nuevas_eliminadas, [])
        self.assertEqual(filas, antes_filas)
        self.assertEqual(revision, antes_revision)

    def test_depuracion_fisica_respalda_y_preserva_celdas(self):
        filas = [self.registro('zp-100', fecha_publicacion='2026-09-01'),
                 self.registro('zp-200', fecha_publicacion='2026-10-01')]
        for fila in filas:
            fila.update(tipo_operacion='venta', precio_real_usd='146000')
        filas[1]['direccion'] = 'Vilela 2630, Saavedra'  # Se debe conservar texto con coma.
        with tempfile.TemporaryDirectory() as carpeta:
            carpeta = Path(carpeta)
            ruta, revision = carpeta/'propiedades.csv', carpeta/'revision.json'
            with ruta.open('w', encoding='utf-8', newline='') as archivo:
                escritor = csv.DictWriter(archivo, fieldnames=list(filas[0]), lineterminator='\r\n')
                escritor.writeheader()
                escritor.writerows(filas)
            antes = ruta.read_bytes()
            cargadas = cargar_dataset_csv(ruta).to_dict('records')
            revision.write_text(json.dumps({'casos':[self.caso(*cargadas)]}))
            with patch('modelo_ia.modelo.REVISION_REPUBLICACIONES', revision):
                informe = depurar_csv_republicaciones(ruta, salida=carpeta/'auditoria')
                despues = ruta.read_bytes()
                segunda = depurar_csv_republicaciones(ruta, salida=carpeta/'auditoria')
                # Una copia nueva sin precio válido no debe desplazar a la antigua.
                filas[1]['precio_real_usd'] = '0'
                invalida = carpeta/'precio_invalido.csv'
                with invalida.open('w', encoding='utf-8', newline='') as archivo:
                    escritor = csv.DictWriter(archivo, fieldnames=list(filas[0]))
                    escritor.writeheader()
                    escritor.writerows(filas)
                sin_cambios = invalida.read_bytes()
                resultado_invalida = depurar_csv_republicaciones(invalida, salida=carpeta/'auditoria')
                self.assertEqual(resultado_invalida['eliminadas'], 0)
                self.assertEqual(invalida.read_bytes(), sin_cambios)
            self.assertEqual(informe['eliminadas'], 1)
            self.assertEqual(informe['estado'], 'aplicada')
            self.assertEqual((carpeta/informe['respaldo']).read_bytes(), antes)
            with (carpeta/informe['respaldo']).open(newline='') as archivo:
                original_conservada = list(csv.DictReader(archivo))[1]
            with ruta.open(newline='') as archivo:
                self.assertEqual(list(csv.DictReader(archivo)), [original_conservada])
            self.assertEqual(ruta.read_bytes(), despues)
            self.assertEqual(segunda['eliminadas'], 0)
            self.assertEqual(len(list(carpeta.glob('*antes_republicaciones*.csv'))), 1)


class TratamientoPrecioTest(unittest.TestCase):
    def test_centrado_log_se_aprende_solo_con_entrenamiento(self):
        filas = [{'tipo_propiedad':'Casa','superficie_total_m2':50+i,'superficie_cubierta_m2':40+i}
                 for i in range(40)]
        X = _preparar_features(pd.DataFrame(filas))[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]
        y = pd.Series(100000+np.arange(40)*1000, dtype=float)
        grupos = np.repeat(np.arange(20),2)
        train,test = dividir_datos(len(X),grupos,20261028)
        config = {'transformacion_objetivo':'log','centrar_log':True,
                  'parametros':{'iterations':10,'depth':3,'loss_function':'Huber:delta=0.2'}}
        ajustado,informe,_ = evaluar_modelo(crear_modelo(config),X,y,grupos=grupos,random_state=20261028)
        self.assertAlmostEqual(ajustado.transformer_.named_steps['standardscaler'].mean_[0], np.log(y.iloc[train]).mean())
        y.iloc[test] = 1e12
        segundo,informe2,_ = evaluar_modelo(crear_modelo(config),X,y,grupos=grupos,random_state=20261028)
        self.assertEqual(informe['cross_validation'],informe2['cross_validation'])
        np.testing.assert_allclose(ajustado.predict(X),segundo.predict(X))

    def test_comparacion_mantiene_los_mismos_arboles(self):
        candidatos = candidatos_tratamiento_precio()
        parametros = [{k:v for k,v in c['parametros'].items() if k != 'loss_function'} for c in candidatos]
        self.assertTrue(all(p == parametros[0] for p in parametros))
        self.assertEqual(len(candidatos), 5)

    def test_precios_del_test_no_cambian_la_seleccion(self):
        X = pd.DataFrame({'id':np.arange(60)})
        y = pd.Series(100000+np.arange(60)*1000, dtype=float)
        grupos = np.repeat(np.arange(30),2)
        train,test = dividir_datos(len(X),grupos,20261028)
        aprendidos = []
        class Capturador(DummyRegressor):
            def fit(self, X, y):
                aprendidos.append(set(X.id))
                return super().fit(X,y)
        with patch('modelo_ia.evaluar_dataset.crear_modelo', side_effect=lambda _:Capturador(strategy='median')):
            config1, seleccion1 = seleccionar_configuracion(X,y,grupos,solo_precio=True)
            y2 = y.copy()
            y2.iloc[test] = 1e12
            config2, seleccion2 = seleccionar_configuracion(X,y2,grupos,solo_precio=True)
        self.assertEqual(config1,config2)
        self.assertEqual(seleccion1,seleccion2)
        self.assertTrue(all(ids <= set(train) and not ids.intersection(test) for ids in aprendidos))
        self.assertTrue(all(len(r['folds']) == 5 for r in seleccion1['resultados']))


class AjusteCatBoostTest(unittest.TestCase):
    def test_busqueda_reproducible_conserva_objetivo_y_no_muta_configuracion(self):
        actual = {'nombre':'vigente','transformacion_objetivo':'log','parametros':{
            'iterations':600,'depth':6,'learning_rate':.05,'loss_function':'RMSE','l2_leaf_reg':3}}
        copia = deepcopy(actual)
        candidatos = candidatos_ajuste_catboost(actual)
        self.assertEqual(candidatos,candidatos_ajuste_catboost(actual))
        self.assertEqual(actual,copia)
        self.assertEqual(candidatos[0],actual)
        self.assertEqual(len(candidatos),25)
        self.assertEqual(len({json.dumps(c['parametros'],sort_keys=True) for c in candidatos}),25)
        self.assertTrue(all(c['transformacion_objetivo']=='log' and c['parametros']['loss_function']=='RMSE' for c in candidatos))
        self.assertEqual({c['parametros']['depth'] for c in candidatos},{4,5,6,7,8})

    def test_rechaza_mejor_mape_si_empeora_demasiado_errores_usd(self):
        def resultado(nombre,mape,mae,rmse):
            return {'configuracion':{'nombre':nombre},'validacion':{
                'mape_porcentaje':{'media':mape},'mae_usd':{'media':mae},'rmse_usd':{'media':rmse}}}
        resultados = [resultado('vigente',22,100,200),resultado('rmse_malo',18,99,220),
                      resultado('mae_malo',17,106,190),resultado('mejora',21,99,199)]
        mejor,limite_mae,limite_rmse = elegir_candidato(resultados)
        self.assertEqual(mejor['configuracion']['nombre'],'mejora')
        self.assertEqual(limite_mae,105)
        self.assertEqual(limite_rmse,210)
        self.assertFalse(resultados[1]['cumple_limite_rmse'])
        self.assertFalse(resultados[2]['cumple_limite_mae'])

    def test_ajuste_no_accede_al_holdout_para_elegir_parametros(self):
        X = pd.DataFrame({'id':np.arange(60)})
        y = pd.Series(100000+np.arange(60)*1000,dtype=float)
        grupos = np.repeat(np.arange(30),2)
        train,test = dividir_datos(len(X),grupos,20261028)
        aprendidos = []
        class Capturador(DummyRegressor):
            def fit(self,X,y):
                aprendidos.append(set(X.id))
                return super().fit(X,y)
        actual = {'nombre':'vigente','transformacion_objetivo':'log','parametros':{
            'iterations':600,'depth':6,'learning_rate':.05,'loss_function':'RMSE','l2_leaf_reg':3}}
        with patch('modelo_ia.evaluar_dataset.crear_modelo',side_effect=lambda _:Capturador(strategy='median')):
            config1,seleccion1 = seleccionar_configuracion(X,y,grupos,configuracion_actual=actual)
            y.iloc[test] = 1e12
            config2,seleccion2 = seleccionar_configuracion(X,y,grupos,configuracion_actual=actual)
        self.assertEqual(config1,config2)
        self.assertEqual(seleccion1,seleccion2)
        self.assertTrue(all(ids <= set(train) and not ids.intersection(test) for ids in aprendidos))
        self.assertEqual(len(seleccion1['resultados']),25)


class MejorasSegmentosTest(unittest.TestCase):
    def datos(self,n=300):
        return _preparar_features(pd.DataFrame([
            {'tipo_propiedad':('Casa','Departamento','PH')[i%3],
             'barrio_zona':'Belgrano R','latitud':-34.5732856,'longitud':-58.4657543,
             'superficie_total_m2':100+i,'superficie_cubierta_m2':80+i,
             'ambientes':0 if i==0 else 3,'dormitorios':0 if i==0 else 2,
             'anios_de_antiguedad':None if i%2 else 0} for i in range(n)
        ]))[COLUMNAS_TEXTO+COLUMNAS_NUMERICAS]

    def test_geografia_oficial_generica_y_fuera_de_caba(self):
        from modelo_ia.mejoras_segmentos import barrio_por_gps,preparar_mejoras
        self.assertEqual(barrio_por_gps(-34.5732856,-58.4657543),'belgrano')
        self.assertIsNone(barrio_por_gps(-34.6037,-58.3816))
        self.assertIsNone(barrio_por_gps(0,0))
        X=self.datos(3);X.loc[1,['latitud','longitud']]=[-34.6037,-58.3816]
        X.loc[2,['latitud','longitud']]=[0,0];X.loc[2,'barrio_zona']='Entre Calle Falsa Y Otra'
        antes=X.copy(deep=True);d=preparar_mejoras(X,ubicacion=True)
        pd.testing.assert_frame_equal(X,antes)
        self.assertEqual(d.loc[0,'subzona_declarada'],'belgrano r')
        self.assertEqual(d.loc[1,'barrio_zona'],'belgrano')
        self.assertTrue(d.loc[1,['latitud','longitud']].isna().all())
        self.assertEqual(d.loc[2,'barrio_zona'],'no especificada')
        self.assertEqual(d.loc[2,'ubicacion_consistencia'],'sin barrio')

    def test_limite_geografico_no_se_asigna_arbitrariamente(self):
        from modelo_ia.mejoras_segmentos import _en_anillo
        cuadrado=np.array([[0,0],[1,0],[1,1],[0,1],[0,0]])
        self.assertIsNone(_en_anillo(0,.5,cuadrado))
        self.assertTrue(_en_anillo(.5,.5,cuadrado))
        self.assertFalse(_en_anillo(2,2,cuadrado))

    def test_superficies_sin_inf_y_ceros_sin_inventar_terreno(self):
        from modelo_ia.mejoras_segmentos import preparar_mejoras
        X=self.datos(3);antes=X.copy(deep=True)
        d=preparar_mejoras(X,superficies=True)
        pd.testing.assert_frame_equal(X,antes)
        self.assertTrue(np.isnan(d.loc[0,'cubierta_por_ambiente_m2']))
        self.assertTrue(np.isnan(d.loc[0,'cubierta_por_dormitorio_m2']))
        self.assertEqual(d.loc[0,'anios_de_antiguedad'],0)
        self.assertEqual(d.loc[1,'anios_de_antiguedad_faltante'],1)
        self.assertEqual(d.loc[0,'diferencia_total_cubierta_m2'],20)
        self.assertFalse(any('terreno' in c for c in d))
        self.assertFalse(np.isinf(d.select_dtypes(include='number').to_numpy()).any())

    def test_especialistas_respaldo_clonado_y_shap_real(self):
        conf={'transformacion_objetivo':'log','parametros':{'iterations':4,'depth':2},
              'mejoras_segmentos':{'ubicacion':True,'superficies':True,'por_tipo':True}}
        X=self.datos();y=np.arange(len(X))*1000+100000
        m=clone(crear_modelo(conf)).fit(X,y)
        self.assertEqual(set(m.especialistas_),{'casa','departamento','ph'})
        for tipo,especialista in m.especialistas_.items():
            mask=X.tipo_propiedad==tipo
            np.testing.assert_allclose(m.predict(X.loc[mask]),especialista.predict(m.preparar(X.loc[mask])))
        consulta=X.iloc[:3].copy();consulta.loc[consulta.index[0],'tipo_propiedad']='Otra'
        np.testing.assert_allclose(m.predict(consulta.iloc[:1]),m.general_.predict(m.preparar(consulta.iloc[:1])))
        _,shap=m.aportes_shap(consulta)
        np.testing.assert_allclose(np.exp(shap.sum(axis=1)),m.predict(consulta),rtol=1e-9)
        chico=clone(crear_modelo(conf)).fit(X.iloc[:20],y[:20])
        self.assertEqual(chico.especialistas_,{})

    def test_seleccion_ignora_prueba_y_rechaza_perjudicar_tipo(self):
        from modelo_ia.comparar_mejoras import elegir_mejora
        def resultado(mape):
            return {'resumen_cv':{'mape_porcentaje':{'media':mape},'mae_usd':{'media':100},'rmse_usd':{'media':150}},
                    'folds':[{'metricas':{'mape_porcentaje':mape}} for _ in range(5)],
                    'oof_por_tipo':{'casa':{'mape_porcentaje':mape}},'prueba':{'mape_porcentaje':99999}}
        r={'base_revisada':resultado(20),'mejora':resultado(19)}
        self.assertEqual(elegir_mejora(r),'mejora')
        r['mejora']['prueba']['mape_porcentaje']=0
        self.assertEqual(elegir_mejora(r),'mejora')
        r['mejora']['oof_por_tipo']['casa']['mape_porcentaje']=25
        self.assertEqual(elegir_mejora(r),'base_revisada')


if __name__ == "__main__":
    unittest.main()
